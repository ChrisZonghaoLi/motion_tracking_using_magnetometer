////////////////////////////////////////////////////////////////////////////////
// File: add_cvectors.c                                                       //
// Routine(s):                                                                //
//    Add_CVectors                                                            //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Add_CVectors(double complex *w, double complex *u,                   //
//                                                  double complex *v, int n) //
//                                                                            //
//  Description:                                                              //
//     Add the complex vectors u and v to form the complex vector w,          //
//     i.e. w = u + v, where w[i] = u[i] + v[i].  All vectors u,v,w should be //
//     declared as " double complex [n] " in the calling routine.             //
//                                                                            //
//  Arguments:                                                                //
//     double complex w[]   Resultant vector w = u + v.                       //
//     double complex u[]   A summand.                                        //
//     double complex v[]   The other summand.                                //
//     int    n             The number of components of u, v, and w.          //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double complex u[N], v[N], w[N];                                       //
//                                                                            //
//     (your code to initialize the vector u and v)                           //
//                                                                            //
//     Add_CVectors(w, u, v, N);                                              //
//     printf("The vector w = u + v is \n"); ...                              //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Add_CVectors(double complex w[], double complex u[], double complex v[],
                                                                         int n) 
{
   for (; n > 0; n--) *w++ = *u++ + *v++;
}
