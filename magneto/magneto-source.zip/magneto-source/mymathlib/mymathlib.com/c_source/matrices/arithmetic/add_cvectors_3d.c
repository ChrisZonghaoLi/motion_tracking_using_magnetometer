////////////////////////////////////////////////////////////////////////////////
// File: add_cvectors_3d.c                                                    //
// Routine(s):                                                                //
//    Add_CVectors_3d                                                         //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Add_CVectors_3d(double complex *w, double complex *u,                //
//                                                         double complex *v) //
//                                                                            //
//  Description:                                                              //
//     Add the 3-dimensional complex vectors u and v to form the 3-dimensional//
//     complex vector w, i.e. w = u + v, where w[i] = u[i] + v[i].            //
//     All vector u,v,w should be declared as " double complex [3] " in the   //
//     calling routine.                                                       //
//                                                                            //
//  Arguments:                                                                //
//     double complex w[]   Resultant vector w = u + v.                       //
//     double complex u[]   A summand.                                        //
//     double complex v[]   The other summand.                                //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double complex u[3], v[3], w[3];                                       //
//                                                                            //
//     (your code to initialize the vector u and v)                           //
//                                                                            //
//     Add_CVectors_3d(w, u, v);                                              //
//     printf("The vector w = u + v is \n"); ...                              //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Add_CVectors_3d(double complex w[], double complex u[],
                                                            double complex v[]) 
{
   w[0] = u[0] + v[0];
   w[1] = u[1] + v[1];
   w[2] = u[2] + v[2];
}
