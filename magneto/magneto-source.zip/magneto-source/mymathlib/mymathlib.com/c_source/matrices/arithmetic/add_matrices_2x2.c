////////////////////////////////////////////////////////////////////////////////
// File: add_matrices_2x2.c                                                   //
// Routine(s):                                                                //
//    Add_Matrices_2x2                                                        //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Add_Matrices_2x2(double *C, double *A, double *B)                    //
//                                                                            //
//  Description:                                                              //
//     This routine computes C = A + B where A, B, C are 2x2 real matrices.   //
//                                                                            //
//     All matrices should be declared as " double X[2][2] " in the calling   //
//     routine, where X = A, B, C.                                            //
//                                                                            //
//  Arguments:                                                                //
//     double *C    Address of the first element of the matrix C.             //
//     double *A    Address of the first element of the matrix A.             //
//     double *B    Address of the first element of the matrix B.             //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double A[2][2],  B[2][2], C[2][2];                                     //
//                                                                            //
//     (your code to initialize the matrices A and B)                         //
//                                                                            //
//     Add_Matrices_2x2((double *) C, &A[0][0], &B[0][0]);                    //
//     printf("The matrix C = A + B is \n"); ...                              //
////////////////////////////////////////////////////////////////////////////////
void Add_Matrices_2x2(double *C, double *A, double *B) 
{
   C[0] = A[0] + B[0];
   C[1] = A[1] + B[1];
   C[2] = A[2] + B[2];
   C[3] = A[3] + B[3];
}
