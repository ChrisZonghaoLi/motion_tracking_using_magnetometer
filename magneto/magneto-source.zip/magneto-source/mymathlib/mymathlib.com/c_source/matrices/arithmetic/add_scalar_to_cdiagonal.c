///////////////////////////////////////////////////////////////////////////////
//File: add_scalar_to_cdiagonal.c                                            //
//Routine(s):                                                                //
//   Add_Scalar_to_CDiagonal                                                 //
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// void Add_Scalar_to_CDiagonal(double complex *A, double complex x,         //
//                                                  int nrows, int ncols)    //
//                                                                           //
// Description:                                                              //
//    Add the complex scalar x to the each diagonal element of the complex   //
//    matrix A, i.e. A[i][i] <- A[i][i] + x, i = 0, ..., min(nrows, ncols).  //
//                                                                           //
// Arguments:                                                                //
//    double complex *A    Pointer to the first element of the matrix A.     //
//    double complex x     Scalar to be added to each diagonal element of    //
//                         the complex matrix A.                             //
//    int    nrows The number of rows of matrix A.                           //
//    int    ncols The number of columns of the matrix A.                    //
//                                                                           //
// Return Values:                                                            //
//    void                                                                   //
//                                                                           //
// Example:                                                                  //
//    #define N                                                              //
//    #define M                                                              //
//    double complex A[M][N],  x;                                            //
//                                                                           //
//    (your code to initialize the matrix A and scalar x)                    //
//                                                                           //
//    Add_Scalar_to_CDiagonal((double complex *) A, x, M, N);                //
//    printf("The matrix A is \n"); ... }                                    //
///////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Add_Scalar_to_CDiagonal(double complex *A, double complex x, int nrows,
                                                                      int ncols) 
{
   register int i, n;

   n = ( nrows < ncols ) ? nrows : ncols;

   for (i = 0; i < n; A += (ncols + 1), i++) *A += x; 
}
