///////////////////////////////////////////////////////////////////////////////
//File: add_scalar_to_diagonal.c                                             //
//Routine(s):                                                                //
//   Add_Scalar_to_Diagonal                                                  //
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// void Add_Scalar_to_Diagonal(double *A, double x, int nrows, int ncols)    //
//                                                                           //
// Description:                                                              //
//    Add the scalar x to the each diagonal element of the matrix A, i.e.    //
//    A[i][i] <- A[i][i] + x, i = 0, ..., min(nrows, ncols).                 //
//                                                                           //
// Arguments:                                                                //
//    double *A    Pointer to the first element of the matrix A.             //
//    double x     Scalar to be added to each diagonal element of the        //
//                 matrix A.                                                 //
//    int    nrows The number of rows of matrix A.                           //
//    int    ncols The number of columns of the matrix A.                    //
//                                                                           //
// Return Values:                                                            //
//    void                                                                   //
//                                                                           //
// Example:                                                                  //
//    #define N                                                              //
//    #define M                                                              //
//    double A[M][N],  x;                                                    //
//                                                                           //
//    (your code to initialize the matrix A and scalar x)                    //
//                                                                           //
//    Add_Scalar_to_Diagonal((double *) A, x, M, N);                         //
//    printf("The matrix A is \n"); ... }                                    //
///////////////////////////////////////////////////////////////////////////////
void Add_Scalar_to_Diagonal(double *A, double x, int nrows, int ncols) 
{
   register int i, n;

   n = ( nrows < ncols ) ? nrows : ncols;

   for (i = 0; i < n; A += (ncols + 1), i++) *A += x; 
}
