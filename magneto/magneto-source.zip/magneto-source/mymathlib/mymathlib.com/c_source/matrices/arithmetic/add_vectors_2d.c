////////////////////////////////////////////////////////////////////////////////
// File: add_vectors_2d.c                                                     //
// Routine(s):                                                                //
//    Add_Vectors_2d                                                          //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Add_Vectors_2d(double *w, double *u, double *v)                      //
//                                                                            //
//  Description:                                                              //
//     Add the 2-dimensional vectors u and v to form the 2-dimensional vector //
//     w, i.e. w = u + v, where w[i] = u[i] + v[i].                           //
//     All the vectors u,v,w should be declared as " double [2] " in the      //
//     calling routine.                                                       //
//                                                                            //
//  Arguments:                                                                //
//     double w[]   Resultant vector w = u + v.                               //
//     double u[]   A summand.                                                //
//     double v[]   The other summand.                                        //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double u[2],  v[2], w[2];                                              //
//                                                                            //
//     (your code to initialize the vector u and v)                           //
//                                                                            //
//     Add_Vectors_2d(w, u, v);                                               //
//     printf("The vector w = u + v is \n"); ...                              //
////////////////////////////////////////////////////////////////////////////////
void Add_Vectors_2d(double w[], double u[], double v[]) 
{
   w[0] = u[0] + v[0];
   w[1] = u[1] + v[1];
}
