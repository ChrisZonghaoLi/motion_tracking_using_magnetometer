////////////////////////////////////////////////////////////////////////////////
// File: add_vectors_2d.h                                                     //
// Routine(s):                                                                //
//    Add_Vectors_2d                                                          //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Add_Vectors_2d(X *w, Y* u, Z* v)                                     //
//                                                                            //
//  Description:                                                              //
//     This is a macro which adds the 2-dimensional vectors u and v to form   //
//     the 2-dimensional vector w, i.e. w = u + v, where w[j] = u[j] + v[j],  //
//     j = 0,1.                                                               //
//                                                                            //
//     The types X,Y,Z could be any type for which the expression w = u + v   //
//     makes sense. I.e X could be double complex, Y could be double and      //
//     Z could be complex double.                                             //
//                                                                            //
//  Arguments:                                                                //
//     X w[]   Resultant vector w = u + v.                                    //
//     Y u[]   A summand.                                                     //
//     Z v[]   The other summand.                                             //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double u[2], v[2], w[2];                                               //
//                                                                            //
//     (your code to initialize the vector u and v)                           //
//                                                                            //
//     Add_Vectors_2d(w, u, v);                                               //
//     printf("The vector w = u + v is \n"); ...                              //
////////////////////////////////////////////////////////////////////////////////

#define Add_Vectors_2d(w,u,v) {w[0]=u[0]+v[0];w[1]=u[1]+v[1];}
