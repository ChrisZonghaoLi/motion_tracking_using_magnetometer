////////////////////////////////////////////////////////////////////////////////
// File: canonical_basis_vector.c                                             //
// Routine(s):                                                                //
//    Canonical_Basis_Vector                                                  //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Canonical_Basis_Vector(double v[], int i, int n)                     //
//                                                                            //
//  Description:                                                              //
//     Set the n dimension vector v to the i_th canonical basis vector, i.e.  //
//     v[j] = 0 if j != i and v[i] = 1, j = 0,...,n-1, i = 0,...,n-1.         //
//     If n <= 1, v[0] is set to 1 regardless of i. If n > 1 and i >= n,      //
//     or i < 0, then v[i] is not set to 1, i.e. the vector v is set to the   //
//     zero vector.                                                           //
//                                                                            //
//  Arguments:                                                                //
//     double v[]   Vector of dimension n, upon return each component is 0.0  //
//                  except v[i] = 1.0.  If n <= 1, v[0] is set to 1.0.        //
//                  If i >= n or i < 0 then v[i] is not set.                  //
//     int    i     The component of v[] set to 1.0, other components are 0.0 //
//     int    n     The number of components of the vector v.                 //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double v[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Canonical_Basis_Vector(v, i, N);                                       //
//     printf("The ith canonical basis vector is \n"); ...                    //
////////////////////////////////////////////////////////////////////////////////

void Canonical_Basis_Vector(double v[], int i, int n)
{
   int j;

   if ( n <= 1) { v[0] = 1.0; return; }
   for (j = 0; j < n; j++) v[j] = 0.0;
   if ( (i >= 0) && (i < n) ) v[i] = 1.0;
}
