////////////////////////////////////////////////////////////////////////////////
// File: cbilinear_pairing.c                                                  //
// Routine(s):                                                                //
//    CBilinear_Pairing                                                       //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  double complex CBilinear_Pairing(double complex u[], double complex *A,   //
//                                  double complex v[], int nrows, int ncols) //
//                                                                            //
//  Description:                                                              //
//     Pre-multiply the nrows x ncols matrix A by the transpose of the column //
//     vector u and post-multiply by the column vector v, to form the scalar  //
//     u'Av.                                                                  //
//                                                                            //
//     The matrix A should be declared as "double complex A[nrows][ncols]" in //
//     the calling routine. The vector u and the vector v should be declared  //
//     as "double complex u[nrows]" and  "double complex v[ncols]"            //
//     respectively in calling routine.                                       //
//                                                                            //
//     The definition of a pairing between vector spaces V,W follows that     //
//     given by Warner in "Foundations of Differentiable Manifolds and        //
//     Lie Groups" published by Scott-Freeman and Company copywrited in 1971, //
//     Page 58, extended to complex vector spaces.                            //
//     Given complex vector spaces V, W a pairing of V and W is a bilinear    //
//     map B:VxW -> C.                                                        //
//                                                                            //
//  Arguments:                                                                //
//     double complex *u    Pointer to the first element of the vector u.     //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     double complex *v    Pointer to the first element of the vector v.     //
//     int            nrows The number of rows of the matrix A and the number //
//                          of components of the vector u.                    //
//     int            ncols The number of columns of the matrix A and the     //
//                           number of components of the vector v.            //
//                                                                            //
//  Return Values:                                                            //
//     Product of u' A v.                                                     //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double complex A[M][N], u[M], v[N];                                    //
//     double complex product;                                                //
//                                                                            //
//     (your code to initialize the matrix A, vector u and vector v)          //
//                                                                            //
//     product = CBilinear_Pairing(u, &A[0][0], v, M, N);                     //
//     printf("The product u'Av is \n"); ...                                  //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

double complex CBilinear_Pairing(double complex u[], double complex *A,
                                      double complex v[], int nrows, int ncols) 
{
   int i,j;
   double complex product = 0.0;
   double complex sum;

   for (i = 0; i < nrows; i++) {
      for (j = 0, sum = 0.0; j < ncols; j++, A++) sum += *A * v[j];
      product += sum * u[i];
   }
   return product;
}
