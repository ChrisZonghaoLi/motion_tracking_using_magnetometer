////////////////////////////////////////////////////////////////////////////////
// File: cdirect_sum.c                                                        //
// Routines:                                                                  //
//    CDirect_Sum                                                             //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// void CDirect_Sum(double complex *C, int nrows, int ncols,                  //
//   int number_of_summands, double complex *A1, int nrows1, int ncols1, ... ,//
//   double complex *Am, int nrowsm, int ncolsm, double complex *Alast)       //
//                                                                            //
//  Description:                                                              //
//     This routine initializes the nrows x ncols matrix C as the direct sum  //
//     of the number_of_summands matrices A1,...,Alast, where last =          //
//     number_of_summands.                                                    //
//                                                                            //
//     Def:  The direct sum of n matrices A1,...,An is the matrix C where     //
//                      -              -                                      //
//                      | A1  0 ...  0 |                                      //
//                 C =  |  0 A2 ...  0 |.                                     //
//                      | ............ |                                      //
//                      |  0  0 ... An |                                      //
//                      -              -                                      //
//                                                                            //
//     The number of rows of C, nrows, is equal to the sum of the number of   //
//     rows of the individual summands,                                       //
//                        nrows = nrows1 + ... + nrowsn,                      //
//     and the number of columns of C, ncols, is equal to the sum of the      //
//     number of columns of the individual summands:                          //
//                       ncols = ncols1 +  ... + ncolsn.                      //
//                                                                            //
//  Arguments:                                                                //
//     double complex *C                                                      //
//               Pointer to the first element of the matrix C, the direct sum //
//               of the remaining matrix arguments in the order they appear   //
//               in the argument list.                                        //
//     int    nrows                                                           //
//               The number of rows of C.                                     //
//     int    ncols                                                           //
//               The number of columns of C.                                  //
//     int    number_of_summands                                              //
//               The number of matrices forming the direct sum.               //
//     double complex *A1                                                     //
//                Pointer to the first matrix in the direct sum.              //
//     int    nrows1                                                          //
//                The number of rows of A1.                                   //
//     int    ncols1                                                          //
//                The number of columns of A1.                                //
//     double complex *A2                                                     //
//                Pointer to the second matrix in the direct sum.             //
//     int    nrows2                                                          //
//                The number of rows of A2.                                   //
//     int    ncols2                                                          //
//                The number of cols of A2.                                   //
//     ...    ...      ...                                                    //
//     double complex *An                                                     //
//                Pointer to the last matrix in the direct sum, where         //
//                n = number_of_summands.                                     //
//                                                                            //
//     Note that the number of rows, nrowsn,  and columns, ncolsn, of An, the //
//     last summand, are not passed as an argument, but rather they are       //
//     calculated in the called routine as                                    //
//             nrowsn = nrows - nrows1 - ... - nrows(n-1), and                //
//             ncolsn = ncols - ncols1 - ... - ncols(n-1).                    //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     (your code to create matrices A1, A2, ... , AN)                        //
//     Direct_Sum((double complex *)C, crows, ccols, N, (double complex *)A1, //
//     a1rows, a1cols, (double complex *)A2,a2rows,a2cols,...,                //
//     double complex *AN);                                                   //
//     printf(" The direct sum C =  \n");                                     //
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////

#include <stdarg.h>           // required for va_start(), va_arg() and va_end()
#include <complex.h>

void CDirect_Sum(double complex *C, int nrows, int ncols, 
                                                   int number_of_summands, ...)
{
   int i, j, p;
   int lrows, lcols;
   int mrows, mcols;
   double complex *pC = C;
   double complex *pA;
   va_list ap;

//         Initialize the nrows x ncols matrix C to 0.0
 
   for (i = 0; i < nrows; i++)
      for (p = 0; p < ncols; p++) *C++ = 0.0;

//         Insert all the summands except the last into the matrix C while
//         decrementing the number of remaining rows and columns to insert.
 
   lrows = nrows;
   lcols = ncols;
   va_start(ap, number_of_summands);
   for (p = 0; p < (number_of_summands - 1); p++) {
      pA = va_arg(ap, double complex *);
      mrows = va_arg(ap, int);
      mcols = va_arg(ap, int);
      for (i = 0; i < mrows; pC += ncols, pA += mcols, i++)
         for (j = 0; j < mcols; j++) pC[j] = pA[j];
      pC += mcols;
      lrows -= mrows;
      lcols -= mcols;
   }

//         Insert the final summand into the matrix C.
 
   pA = va_arg(ap, double complex *);
   for (i = 0; i < lrows; pC += ncols, pA += lcols, i++)
         for (j = 0; j < lcols; j++) pC[j] = pA[j];
   
   va_end(ap);
}
