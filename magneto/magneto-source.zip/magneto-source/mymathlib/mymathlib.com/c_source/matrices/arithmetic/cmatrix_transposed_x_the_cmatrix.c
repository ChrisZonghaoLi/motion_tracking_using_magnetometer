////////////////////////////////////////////////////////////////////////////////
// File: cmatrix_transposed_x_the_cmatrix.c                                   //
// Routine(s):                                                                //
//    CMatrix_Transposed_x_the_CMatrix()                                      //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void CMatrix_Transposed_x_the_CMatrix(double complex *C,                  //
//                                  double complex *A, int nrows, int ncols ) //
//                                                                            //
//  Description:                                                              //
//     Pre multiply an nrows x ncols complex matrix A by its transpose.  The  //
//     result is an ncols x ncols square symmetric complex matrix C, i.e.     //
//     C = A' A, where ' denotes the transpose.  I.e. C = (Cij),              //
//     where Cij = Sum (Aki Akj) where the sum extends from                   //
//     k = 0 to nrows - 1.                                                    //
//                                                                            //
//     The matrix C should be declared as double complex C[ncols][ncols] in   //
//     the calling routine.  The memory allocated to C should not include any //
//     memory allocated to A.                                                 //
//                                                                            //
//  Arguments:                                                                //
//     double complex *C    Pointer to the first element of the matrix C.     //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     int    nrows         The number of rows of matrix A.                   //
//     int    ncols         The number of columns of the matrices A.          //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double complex A[M][N], C[N][N];                                       //
//                                                                            //
//     (your code to initialize the matrix A)                                 //
//                                                                            //
//     CMatrix_Transposed_x_the_CMatrix(&C[0][0], &A[0][0], M, N);            //
//     printf("The matrix C = A'A is \n"); ...                                //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void CMatrix_Transposed_x_the_CMatrix(double complex *C, double complex *A, 
                                                          int nrows, int ncols)
{
   double complex *pAki;
   double complex *pAkj;
   double complex *pA0i;
   double complex *pCij;
   double complex *pCji;
   double complex *pCii = C;
   int i,j,k;

   for (i = 0; i < ncols; pCii += ncols + 1, i++) {
      pCji = pCii;
      pCij = pCii;
      pA0i = A + i;
      for (j = i; j < ncols; pCij++, pCji += ncols, j++) {
         pAki = pA0i;
         pAkj = A + j;
         *pCij = 0.0;
         for (k = 0; k < nrows; pAki += ncols, pAkj += ncols, k++) 
            *pCij += *pAki * *pAkj;
         *pCji = *pCij;
      }
   }
}
