////////////////////////////////////////////////////////////////////////////////
// File: cmatrix_x_an_rmatrix_transposed.c                                    //
// Routine(s):                                                                //
//    CMatrix_x_an_RMatrix_Transposed                                         //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void CMatrix_x_an_RMatrix_Transposed(double complex *C, double complex *A,//
//                               int nrows, int ncols, double *B, int mrows)  //
//                                                                            //
//  Description:                                                              //
//     Post multiply the nrows x ncols complex matrix A by the transpose of   //
//     the mrows x ncols real matrix B to form the nrows x mrows complex      //
//     matrix C, i.e. C = A B', where ' denotes the transpose.                //
//     I.e. C = (Cij), where Cij = Sum (Aik Bjk) where the sum extends from   //
//     k = 0 to ncols - 1.                                                    //
//                                                                            //
//     The matrix C should be declared as double complex C[nrows][mrows] in   //
//     the calling routine.  The memory allocated to C should not include any //
//     memory allocated to A or B.                                            //
//                                                                            //
//  Arguments:                                                                //
//     double complex *C    Pointer to the first element of the matrix C.     //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     int    nrows         The number of rows of matrices A and C.           //
//     int    ncols         The number of columns of the matrices A and B.    //
//     double         *B    Pointer to the first element of the matrix B.     //
//     int    mrows         The number of rows of the matrix B and columns    //
//                          of the matrix C.                                  //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     #define MB                                                             //
//     double complex A[M][N], C[M][MB];                                      //
//     double B[MB][N];                                                       //
//                                                                            //
//     (your code to initialize the matrices A and B)                         //
//                                                                            //
//     CMatrix_x_an_RMatrix_Transposed(&C[0][0], &A[0][0], M, N, &B[0][0],NB);//
//     printf("The matrix C = AB' is \n"); ...                                //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void CMatrix_x_an_RMatrix_Transposed(double complex *C, double complex *A,
                                   int nrows, int ncols, double *B, int mrows) 
{
   int i,j,k;
   double complex *pA;
   double *pB;

   for (i = 0; i < nrows; A += ncols, i++) 
      for (pB = B, j = 0; j < mrows; C++, j++) 
         for (pA = A, *C = 0.0, k  = 0; k < ncols; k++) *C += *pA++ * *pB++;
}
