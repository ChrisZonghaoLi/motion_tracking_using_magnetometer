////////////////////////////////////////////////////////////////////////////////
// File: cmatrix_x_its_dagger.c                                               //
// Routine(s):                                                                //
//    CMatrix_x_Its_Dagger                                                    //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void CMatrix_x_Its_Dagger(double complex *C, double complex *A,           //
//                                                    int nrows, int ncols )  //
//                                                                            //
//  Description:                                                              //
//     Post multiply an nrows x ncols complex matrix A by its complex         //
//     conjugate transposed.  The result is an  nrows x nrows square          //
//     Hermitian matrix C, i.e. C = A A', where ' denotes the conjugate       ////     transpose.                                                             //
//                                                                            //
//     The matrix C should be declared as double complex C[nrows][nrows] in   //
//     the calling routine.  The memory allocated to C should not include any //
//     memory allocated to A.                                                 //
//                                                                            //
//  Arguments:                                                                //
//     double complex *C    Pointer to the first element of the matrix C.     //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     int    nrows         The number of rows of matrix A.                   //
//     int    ncols         The number of columns of the matrices A.          //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double complex A[M][N], C[M][M];                                       //
//                                                                            //
//     (your code to initialize the matrix A)                                 //
//                                                                            //
//     CMatrix_x_Its_Transpose(&C[0][0], &A[0][0], M, N);                     //
//     printf("The matrix C = AA ' is \n"); ...                               //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void CMatrix_x_Its_Dagger(double complex *C, double complex *A, int nrows,
                                                                     int ncols)
{
   int i,j,k;
   double complex *pAi0 = A;
   double complex *pAj0;
   double complex *pCi0 = C;
   double complex *pCji;

   for (i = 0; i < nrows; pCi0 += nrows, pAi0 += ncols, i++) {
      pCji = pCi0 + i;
      pAj0 = pAi0; 
      for (j = i; j < nrows; pCji += nrows, j++) {
         *(pCi0 + j) = 0.0; 
         for (k = 0; k < ncols; k++)
            *(pCi0 + j) += *(pAi0 + k) * conj(*pAj0++);
         *pCji = conj(*(pCi0 + j));
      }
   }
}
