////////////////////////////////////////////////////////////////////////////////
// File: col_transformation.c                                                 //
// Routine(s):                                                                //
//    Column_Transformation                                                   //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Column_Transformation(double *A, double x, int col1, int col2,       //
//                                                      int nrows, int ncols) //
//                                                                            //
//  Description:                                                              //
//     Multiply the column 'col1' by x and add to 'col2' of the               //
//     nrows x ncols matrix A, i.e.                                           //
//           A[i][col2] <- A[i][col2] + x * A[i][col1], for all i.            //
//                                                                            //
//  Arguments:                                                                //
//     double *A    Pointer to the first element of the matrix A.             //
//     double x     Scalar used to multiply each element of column col1 of A. //
//     int    col1  The column of A which is multiplied by x and then added   //
//                  to col2 of A.                                             //
//     int    col2  The column of A which is changed to the sum of its old    //
//                  value and x times the corresponding element of col1.      //
//     int    nrows The number of rows matrix A.                              //
//     int    ncols The number of columns of the matrix A.                    //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double A[M][N], x;                                                     //
//     int i, j;                                                              //
//                                                                            //
//     (your code to create the matrix A, the scalar x, the column number i   //
//      and column number j)                                                  //
//                                                                            //
//     if ( ( i < N ) && ( j < N) ) {                                         //
//        Column_Transformation(&A[0][0], x, i, j, M, N);                     //
//         printf("The matrix A is \n"); ...                                  //
//     } else printf("Illegal column numbers.\n");                            //
////////////////////////////////////////////////////////////////////////////////
void Column_Transformation(double *A, double x, int col1, int col2,
                                                          int nrows, int ncols)
{
   double *pA1, *pA2;

   pA1 = A + col1;
   pA2 = A + col2;

   for (; nrows > 0; pA1 += ncols, pA2 += ncols, nrows--) *pA2 += x * *pA1;
}
