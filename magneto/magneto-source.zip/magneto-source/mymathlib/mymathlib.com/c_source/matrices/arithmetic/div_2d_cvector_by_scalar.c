////////////////////////////////////////////////////////////////////////////////
// File: div_2d_cvector_by_scalar.c                                           //
// Routine(s):                                                                //
//    Divide_2d_CVector_by_Scalar                                             //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Divide_2d_CVector_by_Scalar(double complex *v, double complex x)     //
//                                                                            //
//  Description:                                                              //
//     Divide the 2-dimensional complex vector v by the non-zero scalar x,    ////     i.e. divide each component of the vector v by the scalar x.            //
//                                                                            //
//  Arguments:                                                                //
//     double complex *v  Pointer to the first element of the vector v.       //
//     double complex x   Scalar which divides each element of the vector v.  //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double complex v[2], x;                                                //
//                                                                            //
//     (your code to initialize the vector v and scalar x)                    //
//                                                                            //
//     if (x != 0.0) Divide_2d_CVector_by_Scalar(v, x);                       //
//     printf("The vector v is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Divide_2d_CVector_by_Scalar(double complex *v, double complex x) 
{
   double complex z = 1.0 / x;

   v[0] *= z;
   v[1] *= z;
}
