////////////////////////////////////////////////////////////////////////////////
// File: div_2x2_matrix_by_scalar.c                                           //
// Routine(s):                                                                //
//    Divide_2x2_Matrix_by_Scalar                                             //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Divide_2x2_Matrix_by_Scalar(double *A, double x)                     //
//                                                                            //
//  Description:                                                              //
//     Divide each element of the matrix A by the scalar x.                   //
//     i.e.       A[i][j] <- A[i][j] / x for all i,j.                         //
//                                                                            //
//  Arguments:                                                                //
//     double *A    Pointer to the first element of the matrix A.             //
//     double x     The non-zero scalar used to divide each element of the    //
//                  matrix A.                                                 //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double A[2][2],  x;                                                    //
//                                                                            //
//     (your code to initialize the matrix A and scalar x)                    //
//                                                                            //
//     if (x != 0.0) Divide_2x2_Matrix_by_Scalar(&A[0][0], x);                //
//     printf("The matrix A is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////
void Divide_2x2_Matrix_by_Scalar(double *A, double x) 
{
   double z = 1.0 / x;

   A[0] *= z;
   A[1] *= z;
   A[2] *= z;
   A[3] *= z;
}
