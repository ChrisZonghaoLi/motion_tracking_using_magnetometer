////////////////////////////////////////////////////////////////////////////////
// File: div_2x2_matrix_by_scalar.h                                           //
// Routine(s):                                                                //
//    Divide_2x2_Matrix_by_Scalar                                             //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Divide_2x2_Matrix_by_Scalar(double *A, double x)                     //
//                                                                            //
//  Description:                                                              //
//     Divide each element of the matrix A by the scalar x.                   //
//     i.e.       A[i][j] <- A[i][j] / x for all i,j.                         //
//                                                                            //
//  Arguments:                                                                //
//     double *A    Pointer to the first element of the matrix A.             //
//     double x     The non-zero scalar used to divide each element of the    //
//                  matrix A.                                                 //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double A[2][2],  x;                                                    //
//                                                                            //
//     (your code to initialize the matrix A and scalar x)                    //
//                                                                            //
//     if (x != 0.0) Divide_2x2_Matrix_by_Scalar(&A[0][0], x);                //
//     printf("The matrix A is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#define Divide_2x2_Matrix_by_Scalar(A,x) {double z=1.0/x;double*pA=(double*)A;\
pA[0] *= z; pA[1] *= z; pA[2] *= z; pA[3] *= z;}
