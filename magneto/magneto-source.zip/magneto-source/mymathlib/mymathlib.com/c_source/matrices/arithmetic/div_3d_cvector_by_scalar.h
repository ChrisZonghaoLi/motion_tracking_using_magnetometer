////////////////////////////////////////////////////////////////////////////////
// File: div_3d_cvector_by_scalar.h                                           //
// Routine(s):                                                                //
//    Divide_3d_CVector_by_Scalar                                             //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Divide_3d_CVector_by_Scalar(double *v, double x)                     //
//                                                                            //
//  Description:                                                              //
//     Divide the 3-dimensional complex vector v by the scalar non-zero x,    //
//     i.e. divide each component of v by x.                                  //
//                                                                            //
//  Arguments:                                                                //
//     double complex *v  Pointer to the first element of the vector v.       //
//     double complex x   Scalar which divides each element of the vector v.  //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double complex v[3], x;                                                //
//                                                                            //
//     (your code to initialize the vector v and scalar x)                    //
//                                                                            //
//     if (x != 0.0) Divide_3d_CVector_by_Scalar(v, x);                       //
//     printf("The vector v is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#define Divide_3d_CVector_by_Scalar(v,x) ({double complex z=1.0/(x);\
v[0]*=z;v[1]*=z;v[2]*=z;})
