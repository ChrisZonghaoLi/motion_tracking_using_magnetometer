////////////////////////////////////////////////////////////////////////////////
// File: div_3d_vector_by_scalar.c                                            //
// Routine(s):                                                                //
//    Divide_3d_Vector_by_Scalar                                              //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Divide_3d_Vector_by_Scalar(double *v, double x)                      //
//                                                                            //
//  Description:                                                              //
//     Divide the 3-dimensional vector v by the non-zero scalar x, i.e        //
//     divide each component of v by x.                                       //
//                                                                            //
//  Arguments:                                                                //
//     double *v    Pointer to the first element of the vector v.             //
//     double x     Scalar which divides each element of the vector v.        //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double v[3],  x;                                                       //
//                                                                            //
//     (your code to initialize the vector v and scalar x)                    //
//                                                                            //
//     if (x != 0.0) Divide_3d_Vector_by_Scalar(v, x);                        //
//     printf("The vector v is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////
void Divide_3d_Vector_by_Scalar(double *v, double x) 
{
   double z = 1.0 / x;

   v[0] *= z;
   v[1] *= z;
   v[2] *= z;
}
