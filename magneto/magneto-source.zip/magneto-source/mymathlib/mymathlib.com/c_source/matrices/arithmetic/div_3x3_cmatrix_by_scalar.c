////////////////////////////////////////////////////////////////////////////////
// File: div_3x3_cmatrix_by_scalar.c                                          //
// Routine(s):                                                                //
//    Divide_3x3_CMatrix_by_Scalar                                            //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Divide_3x3_CMatrix_by_Scalar(double complex *A, double complex x)    //
//                                                                            //
//  Description:                                                              //
//     Divide each element of the complex matrix A by the scalar x.           //
//     i.e.       A[i][j] <- A[i][j] / x for all i,j.                         //
//                                                                            //
//  Arguments:                                                                //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     double complex x     The non-zero scalar used to divide each element   //
//                          of the matrix A.                                  //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double complex A[3][3],  x;                                            //
//                                                                            //
//     (your code to initialize the matrix A and scalar x)                    //
//                                                                            //
//     if (x != 0.0) Divide_3x3_CMatrix_by_Scalar(&A[0][0], x);               //
//     printf("The matrix A is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Divide_3x3_CMatrix_by_Scalar(double complex *A, double complex x) 
{
   double complex z = 1.0 / x;

   A[0] *= z;
   A[1] *= z;
   A[2] *= z;
   A[3] *= z;
   A[4] *= z;
   A[5] *= z;
   A[6] *= z;
   A[7] *= z;
   A[8] *= z;
}
