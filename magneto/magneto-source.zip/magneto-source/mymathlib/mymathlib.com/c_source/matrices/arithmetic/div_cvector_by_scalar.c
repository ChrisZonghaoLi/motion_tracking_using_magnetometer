////////////////////////////////////////////////////////////////////////////////
// File: div_cvector_by_scalar.c                                              //
// Routine(s):                                                                //
//    Divide_CVector_by_Scalar                                                //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Divide_CVector_by_Scalar(double complex *v, double complex x, int n) //
//                                                                            //
//  Description:                                                              //
//     Divide the complex vector v by the non-zero scalar x, i.e. divide each //
//     component of the vector v by the scalar x, v[i] <- v[i] / x for all i. //
//                                                                            //
//  Arguments:                                                                //
//     double complex *v  Pointer to the first element of the vector v.       //
//     double complex x   Scalar which divides each element of the vector v.  //
//     int    n           The number of components of the vector v.           //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double complex v[N], x;                                                //
//                                                                            //
//     (your code to initialize the vector v and scalar x)                    //
//                                                                            //
//     if ( x != 0.0)  Divide_Vector_by_Scalar(v, x,N);                       //
//      printf("The vector v is \n"); ...                                     //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Divide_CVector_by_Scalar(double complex v[], double complex x, int n) 
{
   double complex z = 1.0 / x;

   for (; n > 0; n--) *v++ *= z;
}
