////////////////////////////////////////////////////////////////////////////////
// File: identity_cmatrix_lt.c                                                //
// Routines:                                                                  //
//    Identity_CMatrix_lt                                                     //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Identity_CMatrix_lt( double complex *A, int n)                       //
//                                                                            //
//  Description:                                                              //
//     Set the square symmetric complex matrix A stored in lower triangular   //
//     form equal to the identity matrix.                                     //
//                                                                            //
//  Arguments:                                                                //
//     double complex *A                                                      //
//        On output A is set to the identity matrix where A is stored in      //
//        lower triangular form.  I.e  A[0] = 1, A[1] = 0, A[2] = 1,          //
//        A[3] = 0, A[4] = 0, A[5] = 1, ...,  A[n(n+1)/2] = 1.                //
//     int    n                                                               //
//        The dimension A, i.e. A is an n x n symmetric matrix.  It should    //
//        be declared as an array dimensioned at least a large as             //
//        n * (n + 1) / 2 in the calling routine.                             //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double complex A[(N * (N + 1)) >> 1];                                  //
//                                                                            //
//     Identity_CMatrix_lt(A, n);                                             //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Identity_CMatrix_lt(double complex *A, int n) 
{
   int i, j;

   for (i = 0; i < n; i++) {
      for (j = 0; j < i; j++) *A++ = 0.0;
      *A++ = 1.0;
   }
}
