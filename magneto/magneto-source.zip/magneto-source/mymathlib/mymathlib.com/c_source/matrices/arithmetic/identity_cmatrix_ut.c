////////////////////////////////////////////////////////////////////////////////
// File: identity_cmatrix_ut.c                                                //
// Routines:                                                                  //
//    Identity_CMatrix_ut                                                     //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Identity_CMatrix_ut( double complex *A, int n)                       //
//                                                                            //
//  Description:                                                              //
//     Set the square symmetric complex matrix A stored in upper triangular   //
//     form equal to the identity matrix.                                     //
//                                                                            //
//  Arguments:                                                                //
//     double complex *A                                                      //
//        On output A is set to the identity matrix where A is stored in      //
//        upper triangular form.  I.e  A[0] = 1, A[1] = 0, ,,,, A[n-1] = 0,   //
//        A[n] = 1, A[n+1] = 0,..., A[2n-2] = 0,..., A[n(n+1)/2] = 1.         //
//     int    n                                                               //
//        The dimension A, i.e. A is an n x n symmetric matrix.  It should    //
//        be declared as an array dimensioned at least a large as             //
//        n * (n + 1) / 2 in the calling routine.                             //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double complex A[(N * (N + 1)) >> 1];                                  //
//                                                                            //
//     Identity_CMatrix_ut(A, n);                                             //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Identity_CMatrix_ut(double complex *A, int n) 
{
   int i, j;

   for (i = 0; i < n; ) {
      *A++ = 1.0;
      for (j = ++i; j < n; j++) *A++ = 0.0;
   }
}
