////////////////////////////////////////////////////////////////////////////////
// File: identity_matrix_ut.c                                                 //
// Routines:                                                                  //
//    Identity_Matrix_ut                                                      //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Identity_Matrix_ut( double *A, int n)                                //
//                                                                            //
//  Description:                                                              //
//     Set the square symmetric matrix A stored in upper triangular form      //
//     equal to the identity matrix.                                          //
//                                                                            //
//  Arguments:                                                                //
//     double *A                                                              //
//        On output A is set to the identity matrix where A is stored in      //
//        upper triangular form.  I.e  A[0] = 1, A[1] = 0, ,,,, A[n-1] = 0,   //
//        A[n] = 1, A[n+1] = 0,..., A[2n-2] = 0,..., A[n(n+1)/2] = 1.         //
//     int    n                                                               //
//        The dimension A, i.e. A is an n x n symmetric matrix.  It should    //
//        be declared as an array dimensioned at least a large as             //
//        n * (n + 1) / 2 in the calling routine.                             //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[(N * (N + 1)) >>1];                                           //
//                                                                            //
//     Identity_Matrix_ut(A, n);                                              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

void Identity_Matrix_ut(double *A, int n) 
{
   int i, j;

   for (i = 0; i < n; ) {
      *A++ = 1.0;
      for (j = ++i; j < n; j++) *A++ = 0.0;
   }
}
