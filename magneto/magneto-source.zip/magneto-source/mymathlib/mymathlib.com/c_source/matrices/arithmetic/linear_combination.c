////////////////////////////////////////////////////////////////////////////////
// File: linear_combination.c                                                 //
// Routines:                                                                  //
//    Linear_Combination                                                      //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// void Linear_Combination(double v[], int n, int number_of_summands,         //
//                      double a1, double *v1, ... , double am, double *vm)   //
//                                                                            //
//  Description:                                                              //
//     This routine forms the sum v = a1 * v1 + ... + am * vm where m is the  //
//     number_of_summands, a1, ..., am are scalars and v1, ...., vm are       //
//     n-dimensional vectors.                                                 //
//                                                                            //
//  Arguments:                                                                //
//     double v[]                                                             //
//               Pointer to the first element of the vector v, the sum of the //
//               products of the m-th scalar with the m-th vector.            //
//     int    n                                                               //
//               The dimension of v, v1, v2, ... vm, where m is the number-of-//
//               summands.                                                    //
//     int    number_of_summands                                              //
//               The number of scalars and vectors which to sum.              //
//     double a1                                                              //
//               The first scalar which multiplies v1.                        //
//     double v1[]                                                            //
//               Pointer to the first n-dimensional vector in the summation.  //
//     ...    ...      ...                                                    //
//     double am                                                              //
//               The last scalar which multiplies vm.                         //
//     double vm[]                                                            //
//               Pointer to the last n-dimensional vector in the summation.   //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define n                                                              //
//     #define N                                                              //
//     double v[n], v1[n], v2[n], v3[n],...,vN[n];                            //
//     double s1, s2, s3,...,sN;                                              //
//                                                                            //
//     (your code to create vectors v1, v2, ... , vN)                         //
//                                                                            //
//     Linear_Combination(v,n,N,a1,v1,a2,v2,...,aN,vN);                       //
//     printf(" The sum is v = \n");                                          //
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////

#include <stdarg.h>           // required for va_start(), va_arg() and va_end()

void Linear_Combination(double v[], int n, int number_of_summands, ...)
{
   double x;
   double* vj;
   va_list ap;
   int i, p;

//         Initialize the n-dimensional vector v to 0.0
 
   for (i = 0; i < n; i++) v[i] = 0.0;

//         For each scalar and vector, for each component i, add the product
//         of the scalar times the i-th component of the summand to the    
//         i-th component of the target vector.    
 
   va_start(ap, number_of_summands);
   for (p = 0; p < number_of_summands; p++) {
      x = va_arg(ap, double);
      vj = va_arg(ap, double*);
      for (i = 0; i < n; i++) v[i] += x * vj[i];
   }

   va_end(ap);
}
