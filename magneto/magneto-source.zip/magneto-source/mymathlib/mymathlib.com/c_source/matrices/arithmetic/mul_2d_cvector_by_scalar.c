////////////////////////////////////////////////////////////////////////////////
// File: mul_2d_cvector_by_scalar.c                                           //
// Routine(s):                                                                //
//    Multiply_2d_CVector_by_Scalar                                           //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_2d_CVector_by_Scalar(double complex *v, double complex x)   //
//                                                                            //
//  Description:                                                              //
//     Multiply the 2-dimensional complex vector v by the scalar x, i.e.      //
//     multiply each component of the vector v by the scalar x.               //
//                                                                            //
//  Arguments:                                                                //
//     double complex *v    Pointer to the first element of the vector v.     //
//     double complex x     Scalar which multiplies each element of the       //
//                          vector v.                                         //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double complex v[2], x;                                                //
//                                                                            //
//     (your code to initialize the vector v and scalar x)                    //
//                                                                            //
//     Multiply_2d_CVector_by_Scalar(v, x);                                   //
//     printf("The vector v is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Multiply_2d_CVector_by_Scalar(double complex *v, double complex x) 
{
   v[0] *= x;
   v[1] *= x;
}
