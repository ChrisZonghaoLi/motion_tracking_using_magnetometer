////////////////////////////////////////////////////////////////////////////////
// File: mul_2d_vector_by_scalar.c                                            //
// Routine(s):                                                                //
//    Multiply_2d_Vector_by_Scalar                                            //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_2d_Vector_by_Scalar(double *v, double x)                    //
//                                                                            //
//  Description:                                                              //
//     Multiply the 2-dimensional vector v by the scalar x, i.e. multiply     //
//     each component of the vector v by the scalar x.                        //
//                                                                            //
//  Arguments:                                                                //
//     double *v    Pointer to the first element of the vector v.             //
//     double x     Scalar which multiplies each element of the vector v.     //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double v[2],  x;                                                       //
//                                                                            //
//     (your code to initialize the vector v and scalar x)                    //
//                                                                            //
//     Multiply_2d_Vector_by_Scalar(v, x);                                    //
//     printf("The vector v is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////
void Multiply_2d_Vector_by_Scalar(double *v, double x) 
{
   v[0] *= x;
   v[1] *= x;
}
