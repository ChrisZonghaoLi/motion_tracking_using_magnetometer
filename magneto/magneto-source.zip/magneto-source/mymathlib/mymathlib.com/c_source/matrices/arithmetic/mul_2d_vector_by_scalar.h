////////////////////////////////////////////////////////////////////////////////
// File: mul_2d_vector_by_scalar.h                                            //
// Routine(s):                                                                //
//    Multiply_2d_Vector_by_Scalar                                            //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_2d_Vector_by_Scalar(V *v, X* x)                             //
//                                                                            //
//  Description:                                                              //
//     This is a macro which multiplies the 2-dimensional vector v by the     //
//     scalar x, i.e. v[j] <- x*v[j], j = 0,1.                                //
//                                                                            //
//     The types V,X could be any type for which the expression x*v[i]        //
//     makes sense. I.e X could be double, V could be double complex.         //
//     If V is complex double, then X could be either complex double or       //
//     double, but if V is double, then X can only be a double.               //
//                                                                            //
//  Arguments:                                                                //
//     V v[]   On input the 2-d vector, on output x * the input values.       //
//     X x     The scalar.                                                    //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double v[2],  x;                                                       //
//                                                                            //
//     (your code to initialize the vector v and scalar x)                    //
//                                                                            //
//     Multiply_2d_Vector_by_Scalar(v, x);                                    //
//     printf("The vector v is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#define Multiply_2d_Vector_by_Scalar(v, x) ({v[0]*=(x);v[1]*=(x);}) 
