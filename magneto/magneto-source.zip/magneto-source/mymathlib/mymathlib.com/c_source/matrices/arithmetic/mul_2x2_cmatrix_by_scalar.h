////////////////////////////////////////////////////////////////////////////////
// File: mul_2x2_cmatrix_by_scalar.h                                          //
// Routine(s):                                                                //
//    Multiply_2x2_CMatrix_by_Scalar                                          //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_2x2_CMatrix_by_Scalar(double complex *A, double complex x)  //
//                                                                            //
//  Description:                                                              //
//     Multiply each element of the complex 2x2 matrix A by the scalar x.     //
//                                                                            //
//  Arguments:                                                                //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     double complex x     Scalar to multipy each element of the matrix A.   //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double complex A[2][2],  x;                                            //
//                                                                            //
//     (your code to initialize the matrix A and scalar x)                    //
//                                                                            //
//     Multiply_2x2_CMatrix_by_Scalar(&A[0][0], x);                           //
//     printf("The matrix A is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

#define Multiply_2x2_CMatrix_by_Scalar(A,x) {double complex *pA=\
(double complex*)A; pA[0] *= x; pA[1] *= x; pA[2] *= x; pA[3] *= x;}
