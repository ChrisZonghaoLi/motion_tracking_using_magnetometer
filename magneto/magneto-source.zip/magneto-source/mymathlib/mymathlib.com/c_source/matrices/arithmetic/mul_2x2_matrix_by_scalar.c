////////////////////////////////////////////////////////////////////////////////
// File: mul_2x2_matrix_by_scalar.c                                           //
// Routine(s):                                                                //
//    Multiply_2x2_Matrix_by_Scalar                                           //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_2x2_Matrix_by_Scalar(double *A, double x)                   //
//                                                                            //
//  Description:                                                              //
//     Multiply each element of the matrix A by the scalar x.                 //
//                                                                            //
//  Arguments:                                                                //
//     double *A    Pointer to the first element of the matrix A.             //
//     double x     Scalar to multipy each element of the matrix A.           //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double A[2][2],  x;                                                    //
//                                                                            //
//     (your code to initialize the matrix A and scalar x)                    //
//                                                                            //
//     Multiply_2x2_Matrix_by_Scalar(&A[0][0], x);                            //
//     printf("The matrix A is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////
void Multiply_2x2_Matrix_by_Scalar(double *A, double x) 
{
   A[0] *= x;
   A[1] *= x;
   A[2] *= x;
   A[3] *= x;
}
