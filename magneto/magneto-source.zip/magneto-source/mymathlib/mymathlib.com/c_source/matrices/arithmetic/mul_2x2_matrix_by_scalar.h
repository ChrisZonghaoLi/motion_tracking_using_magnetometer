////////////////////////////////////////////////////////////////////////////////
// File: mul_2x2_matrix_by_scalar.h                                           //
// Routine(s):                                                                //
//    Multiply_2x2_Matrix_by_Scalar                                           //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_2x2_Matrix_by_Scalar(double *A, double x)                   //
//                                                                            //
//  Description:                                                              //
//     Multiply each element of the matrix A by the scalar x.                 //
//                                                                            //
//  Arguments:                                                                //
//     double *A    Pointer to the first element of the matrix A.             //
//     double x     Scalar to multipy each element of the matrix A.           //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double A[2][2],  x;                                                    //
//                                                                            //
//     (your code to initialize the matrix A and scalar x)                    //
//                                                                            //
//     Multiply_2x2_Matrix_by_Scalar(&A[0][0], x);                            //
//     printf("The matrix A is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#define Multiply_2x2_Matrix_by_Scalar(A,x) {double*pA=(double*)A;\
pA[0] *= x; pA[1] *= x; pA[2] *= x; pA[3] *= x;}
