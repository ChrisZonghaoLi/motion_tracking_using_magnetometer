////////////////////////////////////////////////////////////////////////////////
// File: mul_3x3_cmatrix_by_scalar.c                                          //
// Routine(s):                                                                //
//    Multiply_3x3_CMatrix_by_Scalar                                          //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_3x3_CMatrix_by_Scalar(double complex *A, double complex x)  //
//                                                                            //
//  Description:                                                              //
//     Multiply each element of the complex matrix A by the scalar x.         //
//                                                                            //
//  Arguments:                                                                //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     double complex x     Scalar to multipy each element of the matrix A.   //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double complex A[3][3],  x;                                            //
//                                                                            //
//     (your code to initialize the matrix A and scalar x)                    //
//                                                                            //
//     Multiply_3x3_CMatrix_by_Scalar(&A[0][0], x);                           //
//     printf("The matrix A is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Multiply_3x3_CMatrix_by_Scalar(double complex *A, double complex x) 
{
   A[0] *= x;
   A[1] *= x;
   A[2] *= x;
   A[3] *= x;
   A[4] *= x;
   A[5] *= x;
   A[6] *= x;
   A[7] *= x;
   A[8] *= x;
}
