////////////////////////////////////////////////////////////////////////////////
// File: mul_cmatrix_by_scalar.c                                              //
// Routine(s):                                                                //
//    Multiply_CMatrix_by_Scalar                                              //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_CMatrix_by_Scalar(double complex *A, double complex x,      //
//                                                      int nrows, int ncols) //
//                                                                            //
//  Description:                                                              //
//     Multiply each element of the complex matrix A by the complex scalar x. //
//                                                                            //
//  Arguments:                                                                //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     double complex x     Scalar to multipy each element of the matrix A.   //
//     int            nrows The number of rows of matrix A.                   //
//     int            ncols The number of columns of the matrix A.            //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double complex A[M][N],  x;                                            //
//                                                                            //
//     (your code to initialize the matrix A and scalar x)                    //
//                                                                            //
//     Multiply_CMatrix_by_Scalar(&A[0][0], x, M, N);                         //
//     printf("The matrix A is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Multiply_CMatrix_by_Scalar(double complex *A, double complex x, int nrows,
                                                                    int ncols)
{
   register int n = nrows * ncols - 1;
   
   for (; n >= 0; n--) A[n] *= x;
}
