////////////////////////////////////////////////////////////////////////////////
// File: mul_cvector_by_scalar.c                                              //
// Routine(s):                                                                //
//    Multiply_CVector_by_Scalar                                              //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_CVector_by_Scalar(double complex *v, double complex x,      //
//                                                                     int n) //
//                                                                            //
//  Description:                                                              //
//     Multiply the complex vector v by the scalar x, i.e. multiply each      //
//     component of the vector v by the scalar x, v[i] <- v[i] * x for all i. //
//                                                                            //
//  Arguments:                                                                //
//     double complex *v    Pointer to the first element of the vector v.     //
//     double complex x     Scalar which multiplies each element of the       //
//                          vector v.                                         //
//     int    n             The number of components of the vector v.         //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double complex v[N], x;                                                //
//                                                                            //
//     (your code to initialize the vector v and scalar x)                    //
//                                                                            //
//     Multiply_CVector_by_Scalar(v, x, N);                                   //
//     printf("The vector v is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Multiply_CVector_by_Scalar(double complex v[], double complex x, int n) 
{
   for (; n > 0; n--) *v++ *= x;
}
