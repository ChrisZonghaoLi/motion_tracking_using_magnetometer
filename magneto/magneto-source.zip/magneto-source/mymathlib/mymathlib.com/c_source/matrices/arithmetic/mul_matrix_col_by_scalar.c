////////////////////////////////////////////////////////////////////////////////
// File: mul_matrix_col_by_scalar.c                                           //
// Routine(s):                                                                //
//    Multiply_Column_by_Scalar                                               //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_Column_by_Scalar(double *A, double x, int col, int nrows,   //
//                                                                 int ncols) //
//                                                                            //
//  Description:                                                              //
//     Multiply the column 'col' by x of the nrows x ncols matrix A, i.e.     //
//               A[i][col] <- x * A[i][col], for all i.                       //
//                                                                            //
//  Arguments:                                                                //
//     double *A    Pointer to the first element of the matrix A.             //
//     double x     Scalar used to multiply each element of column col of A.  //
//     int    col   The column of A which is multiplied by x.                 //
//     int    nrows The number of rows matrix A.                              //
//     int    ncols The number of columns of the matrix A.                    //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double A[M][N], x;                                                     //
//     int i;                                                                 //
//                                                                            //
//     (your code to create the matrix A, the scalar x, the column number i)  //
//                                                                            //
//     if ( i < N )  {                                                        //
//        Multiply_Column_by_Scalar(&A[0][0], x, i, M, N);                    //
//         printf("The matrix A is \n"); ...                                  //
//     } else printf("Illegal column number.\n");                             //
////////////////////////////////////////////////////////////////////////////////
void Multiply_Column_by_Scalar(double *A, double x, int col, int nrows, 
                                                                   int ncols) 
{
   A += col;
   for (; nrows > 0; A += ncols, nrows--) *A *= x;
}
