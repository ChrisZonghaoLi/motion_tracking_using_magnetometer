////////////////////////////////////////////////////////////////////////////////
// File: mul_matrix_row_by_scalar.c                                           //
// Routine(s):                                                                //
//    Multiply_Row_by_Scalar                                                  //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_Row_by_Scalar(double *A, double x, int row, int ncols)      //
//                                                                            //
//  Description:                                                              //
//     Multiply the row 'row' by x of the  nrows x ncols matrix A, i.e.       //
//                  A[row][j] <- x * A[row][j], for all j.                    //
//                                                                            //
//  Arguments:                                                                //
//     double *A    Pointer to the first element of the matrix A.             //
//     double x     Scalar used to multiply each element of row 'row' of A.   //
//     int    row   The row of A which is multiplied by x.                    //
//     int    ncols The number of columns of the matrix A.                    //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double A[M][N], x;                                                     //
//     int i;                                                                 //
//                                                                            //
//     (your code to create the matrix A, the scalar x, the row number i )    //
//                                                                            //
//     if ( i < M  ) {                                                        //
//        Multiply_Row_by_Scalar(&A[0][0], x, i, N);                          //
//         printf("The matrix A is \n"); ...                                  //
//     } else printf("Illegal row number.\n");                                //
////////////////////////////////////////////////////////////////////////////////
void Multiply_Row_by_Scalar(double *A, double x, int row, int ncols)
{
   A += row * ncols;
   for (; ncols > 0; ncols--) *A++ *= x;
}
