////////////////////////////////////////////////////////////////////////////////
// File: mul_vector_by_scalar.c                                               //
// Routine(s):                                                                //
//    Multiply_Vector_by_Scalar                                               //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_Vector_by_Scalar(double *v, double x, int n)                //
//                                                                            //
//  Description:                                                              //
//     Multiply the vector v by the scalar x, i.e. multiply each component    //
//     of the vector v by the scalar x, v[i] <- v[i] * x for all i.           //
//                                                                            //
//  Arguments:                                                                //
//     double *v    Pointer to the first element of the vector v.             //
//     double x     Scalar which multiplies each element of the vector v.     //
//     int    n     The number of components of the vector v.                 //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double v[N],  x;                                                       //
//                                                                            //
//     (your code to initialize the vector v and scalar x)                    //
//                                                                            //
//     Multiply_Vector_by_Scalar(v, x, N);                                    //
//     printf("The vector v is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////
void Multiply_Vector_by_Scalar(double v[], double x, int n) 
{
   for (; n > 0; n--) *v++ *= x;
}
