////////////////////////////////////////////////////////////////////////////////
// File: mult_cmatrix_col_by_scalar.c                                         //
// Routine(s):                                                                //
//    Mult_CMatrix_Column_by_Scalar                                           //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Mult_CMatrix_Column_by_Scalar(double complex *A, double complex x,   //
//                                             int col, int nrows, int ncols) //
//                                                                            //
//  Description:                                                              //
//     Multiply the column 'col' by x of the nrows x ncols complex matrix A,  //
//     i.e.      A[i][col] <- x * A[i][col], for all i.                       //
//                                                                            //
//  Arguments:                                                                //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     double complex x     Scalar used to multiply each element of column    //
//                          col of A.                                         //
//     int    col           The column of A which is multiplied by x.         //
//                          0 <= col < ncols.                                 //
//     int    nrows         The number of rows matrix A.                      //
//     int    ncols         The number of columns of the matrix A.            //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double complex A[M][N], x;                                             //
//     int i;                                                                 //
//                                                                            //
//     (your code to create the matrix A, the scalar x, the column number i)  //
//                                                                            //
//     if ( i < N )  {                                                        //
//        Mult_CMatrix_Column_by_Scalar(&A[0][0], x, i, M, N);                //
//        printf("The matrix A is \n"); ...                                   //
//     } else printf("Illegal column number.\n");                             //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Mult_CMatrix_Column_by_Scalar(double complex *A, double complex x,
                                                 int col, int nrows, int ncols) 
{
   A += col;
   for (; nrows > 0; A += ncols, nrows--) *A *= x;
}
