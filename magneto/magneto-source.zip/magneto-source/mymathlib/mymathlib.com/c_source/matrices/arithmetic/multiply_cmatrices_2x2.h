////////////////////////////////////////////////////////////////////////////////
// File: multiply_cmatrices_2x2.h                                             //
// Routine(s):                                                                //
//    Multiply_CMatrices_2x2                                                  //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_CMatrices_2x2(double complex *C, double complex *A,         //
//                                                         double complex *B) //
//                                                                            //
//  Description:                                                              //
//     Post multiply the 2 x 2 complex matrix A by the 2 x 2 complex matrix B //
//     to form the 2 x 2 complex matrix C, i.e. C = A B.                      //
//                                                                            //
//     All matrices should be declared as double complex X[2][2] in the       //
//     calling routine where X = A, B, C.                                     //
//                                                                            //
//  Arguments:                                                                //
//     double complex *C    Pointer to the first element of the matrix C.     //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     double complex *B    Pointer to the first element of the matrix B.     //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double complex A[2][2],  B[2][2], C[2][2];                             //
//                                                                            //
//     (your code to initialize the matrices A and B)                         //
//                                                                            //
//     Multiply_CMatrices_2x2(*C, *A, &B[0][0]);                              //
//     printf("The matrix C is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

#define Multiply_CMatrices_2x2(C,A,B) {double complex *pC=(double complex *)C;\
double complex *pA=(double complex *)A;double complex *pB=(double complex *)B;\
pC[0]=pA[0]*pB[0]+pA[1]*pB[2]; pC[1]=pA[0]*pB[1]+pA[1]*pB[3];\
pC[2]=pA[2]*pB[0]+pA[3]*pB[2]; pC[3]=pA[2]*pB[1]+pA[3]*pB[3];}
