////////////////////////////////////////////////////////////////////////////////
// File: multiply_cmatrices_3x3.c                                             //
// Routine(s):                                                                //
//    Multiply_CMatrices_3x3                                                  //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_CMatrices_3x3(double complex *C, double complex *A,         //
//                                                         double complex *B) //
//                                                                            //
//  Description:                                                              //
//     Post multiply the 3 x 3 complex matrix A by the 3 x 3 complex matrix B //
//     to form the 3 x 3 complex matrix C, i.e. C = A B.                      //
//                                                                            //
//     All matrices should be declared as double complex X[3][3] in the       //
//     calling routine where X = A, B, C.                                     //
//                                                                            //
//  Arguments:                                                                //
//     double complex *C    Pointer to the first element of the matrix C.     //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     double complex *B    Pointer to the first element of the matrix B.     //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double complex A[3][3], B[3][3], C[3][3];                              //
//                                                                            //
//     (your code to initialize the matrices A and B)                         //
//                                                                            //
//     Multiply_CMatrices_3x3( *C, *A, &B[0][0]);                             //
//     printf("The matrix C is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Multiply_CMatrices_3x3(double complex *C, double complex *A,
                                                             double complex *B) 
{
   C[0] = A[0] * B[0] + A[1] * B[3] + A[2]*B[6];
   C[1] = A[0] * B[1] + A[1] * B[4] + A[2]*B[7];
   C[2] = A[0] * B[2] + A[1] * B[5] + A[2]*B[8];
   C[3] = A[3] * B[0] + A[4] * B[3] + A[5]*B[6];
   C[4] = A[3] * B[1] + A[4] * B[4] + A[5]*B[7];
   C[5] = A[3] * B[2] + A[4] * B[5] + A[5]*B[8];
   C[6] = A[6] * B[0] + A[7] * B[3] + A[8]*B[6];
   C[7] = A[6] * B[1] + A[7] * B[4] + A[8]*B[7];
   C[8] = A[6] * B[2] + A[7] * B[5] + A[8]*B[8];
}
