////////////////////////////////////////////////////////////////////////////////
// File: multiply_cmatrices_3x3.h                                             //
// Routine(s):                                                                //
//    Multiply_CMatrices_3x3                                                  //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_CMatrices_3x3(double complex *C, double complex *A,         //
//                                                        double complex *B)  //
//                                                                            //
//  Description:                                                              //
//     Post multiply the 3 x 3 complex matrix A by the 3 x 3 complex matrix B //
//     to form the 3 x 3 complex matrix C, i.e. C = A B.                      //
//                                                                            //
//     All matrices should be declared as double complex X[3][3] in the       //
//     calling routine where X = A, B, C.                                     //
//                                                                            //
//  Arguments:                                                                //
//     double complex *C    Pointer to the first element of the matrix C.     //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     double complex *B    Pointer to the first element of the matrix B.     //
//                                                                            //
//  Return Values:                                                            //
//     Pointer to C.                                                          //
//                                                                            //
//  Example:                                                                  //
//     double complex A[3][3], B[3][3], C[3][3];                              //
//                                                                            //
//     (your code to initialize the matrices A and B)                         //
//                                                                            //
//     Multiply_CMatrices_3x3( *C, *A, &B[0][0]);                             //
//     printf("The matrix C is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

#define Multiply_CMatrices_3x3(C,A,B) {double complex *pC=(double complex *)C;\
double complex *pA=(double complex*)A;double complex *pB=(double complex*)B;\
pC[0]=pA[0]*pB[0]+pA[1]*pB[3]+pA[2]*pB[6];\
pC[1]=pA[0]*pB[1]+pA[1]*pB[4]+pA[2]*pB[7];\
pC[2]=pA[0]*pB[2]+pA[1]*pB[5]+pA[2]*pB[8];\
pC[3]=pA[3]*pB[0]+pA[4]*pB[3]+pA[5]*pB[6];\
pC[4]=pA[3]*pB[1]+pA[4]*pB[4]+pA[5]*pB[7];\
pC[5]=pA[3]*pB[2]+pA[4]*pB[5]+pA[5]*pB[8];\
pC[6]=pA[6]*pB[0]+pA[7]*pB[3]+pA[8]*pB[6];\
pC[7]=pA[6]*pB[1]+pA[7]*pB[4]+pA[8]*pB[7];\
pC[8]=pA[6]*pB[2]+pA[7]*pB[5]+pA[8]*pB[8];}
