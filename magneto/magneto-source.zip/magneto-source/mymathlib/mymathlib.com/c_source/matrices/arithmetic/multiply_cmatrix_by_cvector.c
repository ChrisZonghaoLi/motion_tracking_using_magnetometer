////////////////////////////////////////////////////////////////////////////////
// File: multiply_cmatrix_by_cvector.c                                        //
// Routine(s):                                                                //
//    Multiply_CMatrix_by_CVector()                                           //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_CMatrix_by_CVector(double complex u[], double complex *A,   //
//                                int nrows, int ncols, double complex v[])   //
//                                                                            //
//  Description:                                                              //
//     Post multiply the nrows x ncols complex matrix A by the complex column //
//     vector v to form the complex column vector u, i.e. u = A v.            //
//                                                                            //
//     The matrix A should be declared as "double complex A[nrows][ncols]" in //
//     the calling routine.  The vector v should be declared as               //
//     "double complex v[ncols]" and the vector u should be declared as       //
//     "double complex u[nrows]" in the calling routine.                      //
//                                                                            //
//  Arguments:                                                                //
//     double complex *u    Pointer to the first element of the vector u.     //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     int           nrows  The number of rows of the matrix A and the number //
//                          of components of the column vector u.             //
//     int           ncols  The number of columns of the matrices A and the   //
//                          number of components of the column vector v.      //
//     double complex *v    Pointer to the first element of the vector v.     //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double complex A[M][N], u[M], v[N];                                    //
//                                                                            //
//     (your code to initialize the matrix A and column vector v)             //
//                                                                            //
//     Multiply_CMatrix_by_CVector(u, A, M, N, v);                            //
//     printf("The vector u is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Multiply_CMatrix_by_CVector(double complex u[], double complex  *A,
                                      int nrows, int ncols, double complex v[]) 
{
   int i,j;

   for (i = 0; i < nrows; A += ncols, i++) 
      for (u[i] = 0.0, j = 0; j < ncols; j++) u[i] += A[j] * v[j];
}
