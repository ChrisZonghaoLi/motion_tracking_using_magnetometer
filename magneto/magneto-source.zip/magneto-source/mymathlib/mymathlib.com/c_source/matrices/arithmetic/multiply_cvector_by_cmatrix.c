////////////////////////////////////////////////////////////////////////////////
// File: multiply_cvector_by_cmatrix.c                                        //
// Routine(s):                                                                //
//    Multiply_CVector_by_CMatrix                                             //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_CVector_by_CMatrix(double complex u[], double complex v[],  //
//                                  double complex *A, int nrows, int ncols)  //
//                                                                            //
//  Description:                                                              //
//     Pre multiply the nrows x ncols complex matrix A by the complex row     //
//     vector v to form the complex row vector u, i.e. u = v A.               //
//                                                                            //
//     The matrix A should be declared as "double complex A[nrows][ncols]" in //
//     the calling routine. The vector v declared as "double complex v[nrows]"//
//     and the vector u declared as "double complex u[ncols]" in the calling  //
//     routine.                                                               //
//                                                                            //
//  Arguments:                                                                //
//     double complex *u    Pointer to the first element of the vector u.     //
//     double complex *v    Pointer to the first element of the vector v.     //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     int            nrows The number of rows of the matrix A and the number //
//                          of components of the row vector v.                //
//     int            ncols The number of columns of the matrices A and the   //
//                          number of components of the row vector u.         //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double complex A[M][N], u[N], v[M];                                    //
//                                                                            //
//     (your code to initialize the matrix A and row vector v)                //
//                                                                            //
//     Multiply_CVector_by_CMatrix(u, v, &A[0][0], M, N);                     //
//     printf("The vector u is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Multiply_CVector_by_CMatrix(double complex u[], double complex v[],
                                       double complex *A, int nrows, int ncols) 
{
   double complex *pA;
   int i,j;

   for (i = 0; i < ncols; A++, i++) {
      pA = A;
      u[i] = 0.0;
      for (j = 0; j < nrows; pA += ncols, j++) u[i] += *pA * v[j];
   }
}
