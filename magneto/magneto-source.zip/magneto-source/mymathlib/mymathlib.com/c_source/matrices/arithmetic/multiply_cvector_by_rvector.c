////////////////////////////////////////////////////////////////////////////////
// File: multiply_cvector_by_rvector.c                                        //
// Routine(s):                                                                //
//    Multiply_CVector_by_RVector                                             //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_CVector_by_RVector(double complex *A, int nrows, int ncols, //
//                                           double complex u[], double v[])  //
//                                                                            //
//  Description:                                                              //
//     Post multiply the complex column vector u by the real row vector v     //
//     to form the nrows x ncols complex matrix A.  Here u is an nrows x 1    //
//     complex  column vector and v is an 1 x ncols real row vector and       //
//     A[i][j] = u[i]v[j].                                                    //
//     The matrix A should be declared as "double complex A[nrows][ncols]" in //
//     the calling routine.  The real vector v is declared as                 //
//     "double v[ncols]" and the complex vector u is declared as              //
//     "double complex u[nrows]" in the calling routine.                      //
//                                                                            //
//  Arguments:                                                                //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     int    nrows         The number of rows of the matrix A and the number //
//                          of components of the column vector u.             //
//     int    ncols         The number of columns of the matrices A and the   //
//                          number of components of the row vector v.         //
//     double complex *u    Pointer to the first element of the vector u.     //
//     double  *v           Pointer to the first element of the vector v.     //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double complex A[M][N], u[M];                                          //
//     double v[N];                                                           //
//                                                                            //
//     (your code to initialize the column vector u and row vector v)         //
//                                                                            //
//     Multiply_CVector_by_RVector(&A[0][0], M, N, u, v);                     //
//     printf("The matrix A is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Multiply_CVector_by_RVector(double complex *A, int nrows, int ncols,
                                               double complex u[], double v[])
{
   int i,j;

   for (i = 0; i < nrows; i++) {
      for (j = 0; j < ncols; j++) *A++ = u[i] * v[j];
   }
}
