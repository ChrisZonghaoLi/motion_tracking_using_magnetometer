////////////////////////////////////////////////////////////////////////////////
// File: multiply_matrices_2x2.h                                              //
// Routine(s):                                                                //
//    Multiply_Matrices_2x2                                                   //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_Matrices_2x2(double *C, double *A, double *B)               //
//                                                                            //
//  Description:                                                              //
//     Post multiply the 2 x 2 matrix A by the 2 x 2 matrix B to form the     //
//     2 x 2 matrix C, i.e. C = A B.                                          //
//     All matrices should be declared as double X[2][2] in the calling       //
//     routine where X = A, B, C.                                             //
//                                                                            //
//  Arguments:                                                                //
//     double *C    Pointer to the first element of the matrix C.             //
//     double *A    Pointer to the first element of the matrix A.             //
//     double *B    Pointer to the first element of the matrix B.             //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double A[2][2],  B[2][2], C[2][2];                                     //
//                                                                            //
//     (your code to initialize the matrices A and B)                         //
//                                                                            //
//     Multiply_Matrices_2x2((double *)C, &A[0][0], &B[0][0]);                //
//     printf("The matrix C is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#define Multiply_Matrices_2x2(C,A,B) {double*pC=(double*)C;\
double*pA=(double*)A;double*pB=(double*)B; pC[0]=pA[0]*pB[0]+pA[1]*pB[2];\
pC[1]=pA[0]*pB[1]+pA[1]*pB[3]; pC[2]=pA[2]*pB[0]+pA[3]*pB[2];\
pC[3]=pA[2]*pB[1]+pA[3]*pB[3];}
