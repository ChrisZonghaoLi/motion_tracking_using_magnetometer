////////////////////////////////////////////////////////////////////////////////
// File: multiply_matrices_3x3.h                                              //
// Routine(s):                                                                //
//    Multiply_Matrices_3x3                                                   //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_Matrices_3x3(double *C, double *A, double *B)               //
//                                                                            //
//  Description:                                                              //
//     Post multiply the 3 x 3 matrix A by the 3 x 3 matrix B to form the     //
//     3 x 3 matrix C, i.e. C = A B.                                          //
//     All matrices should be declared as double X[3][3] in the calling       //
//     routine where X = A, B, C.                                             //
//                                                                            //
//  Arguments:                                                                //
//     double *C    Pointer to the first element of the matrix C.             //
//     double *A    Pointer to the first element of the matrix A.             //
//     double *B    Pointer to the first element of the matrix B.             //
//                                                                            //
//  Return Values:                                                            //
//     Pointer to C.                                                          //
//                                                                            //
//  Example:                                                                  //
//     double A[3][3],  B[3][3], C[3][3];                                     //
//                                                                            //
//     (your code to initialize the matrices A and B)                         //
//                                                                            //
//     Multiply_Matrices_3x3((double *)C, &A[0][0], &B[0][0]);                //
//     printf("The matrix C is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#define Multiply_Matrices_3x3(C,A,B) {double*pC=(double*)C;\
double*pA=(double*)A;double*pB=(double*)B;\
pC[0]=pA[0]*pB[0]+pA[1]*pB[3]+pA[2]*pB[6];\
pC[1]=pA[0]*pB[1]+pA[1]*pB[4]+pA[2]*pB[7];\
pC[2]=pA[0]*pB[2]+pA[1]*pB[5]+pA[2]*pB[8];\
pC[3]=pA[3]*pB[0]+pA[4]*pB[3]+pA[5]*pB[6];\
pC[4]=pA[3]*pB[1]+pA[4]*pB[4]+pA[5]*pB[7];\
pC[5]=pA[3]*pB[2]+pA[4]*pB[5]+pA[5]*pB[8];\
pC[6]=pA[6]*pB[0]+pA[7]*pB[3]+pA[8]*pB[6];\
pC[7]=pA[6]*pB[1]+pA[7]*pB[4]+pA[8]*pB[7];\
pC[8]=pA[6]*pB[2]+pA[7]*pB[5]+pA[8]*pB[8];}
