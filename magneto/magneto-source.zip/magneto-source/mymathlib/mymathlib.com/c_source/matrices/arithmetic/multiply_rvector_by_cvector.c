////////////////////////////////////////////////////////////////////////////////
// File: multiply_rvector_by_cvector.c                                        //
// Routine(s):                                                                //
//    Multiply_RVector_by_CVector                                             //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Multiply_RVector_by_CVector(double complex *A, int nrows, int ncols, //
//                                           double u[], double complex v[])  //
//                                                                            //
//  Description:                                                              //
//     Post multiply the real column vector u by the complex row vector v     //
//     to form the nrows x ncols complex matrix A.  Here u is an nrows x 1    //
//     real column vector, v is an 1 x ncols complex row vector and           //
//     A[i][j] = u[i]v[j].                                                    //
//     The matrix A should be declared as "double complex A[nrows][ncols]" in //
//     the calling routine.  The complex vector v is declared as              //
//     "double complex v[ncols]" and the real vector u is declared as         //
//     "double u[nrows]" in the calling routine.                              //
//                                                                            //
//  Arguments:                                                                //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     int    nrows         The number of rows of the matrix A and the number //
//                          of components of the column vector u.             //
//     int    ncols         The number of columns of the matrices A and the   //
//                          number of components of the row vector v.         //
//     double *u            Pointer to the first element of the vector u.     //
//     double complex *v    Pointer to the first element of the vector v.     //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double complex A[M][N], v[N];                                          //
//     double u[M];                                                           //
//                                                                            //
//     (your code to initialize the column vector u and row vector v)         //
//                                                                            //
//     Multiply_RVector_by_CVector(&A[0][0], M, N, u, v);                     //
//     printf("The matrix A is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Multiply_RVector_by_CVector(double complex *A, int nrows, int ncols,
                                               double u[], double complex v[])
{
   int i,j;

   for (i = 0; i < nrows; i++) {
      for (j = 0; j < ncols; j++) *A++ = u[i] * v[j];
   }
}
