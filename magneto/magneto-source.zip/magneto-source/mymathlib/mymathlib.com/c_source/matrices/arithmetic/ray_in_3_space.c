////////////////////////////////////////////////////////////////////////////////
// File: ray_in_3_space.c                                                     //
// Routines:                                                                  //
//    Ray_in_3_Space                                                          //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  double* Ray_in_3_Space(double v[], double initial_pt[], double direction[]//
//                                                          ,double distance) //
//                                                                            //
//  Description:                                                              //
//     Calculates the vector v = initial_pt + distance * direction.           //
//     If direction has unit norm, the v lies at a distance |distance| from   //
//     the initial_pt, i.e. || v - initial_pt || = | distance |.              //
//     In general, || v - initial_pt || = |distance| || direction ||.         //
//     The argument distance can be positive or negative.  The argument       //
//     direction need not have unit norm.                                     //
//                                                                            //
//  Arguments:                                                                //
//     double v[]                                                             //
//            Pointer to the first element of the resultant vector v[3].      //
//     double initial_pt[]                                                    //
//            Pointer to the first element of the vector initial_pt[3].       //
//     double direction[]                                                     //
//            Pointer to the first element of the vector direction[3].        //
//     double distance[]                                                      //
//            Distance to travel from the initial point, initial_pt, along    //
//            a line with direction 'direction', assuming that 'direction'    //
//            has unit norm.                                                  //
//                                                                            //
//  Return Values:                                                            //
//     address of v.                                                          //
//                                                                            //
//  Example:                                                                  //
//     double v[3], init_pt[3], d[3], distance;                               //
//                                                                            //
//     (your code to intialize the vectors init_pt and d, and the scalar)     //
//     (distance.                                                       )     //
//                                                                            //
//     Ray_in_3_Space(v, init_pt, d, distance);                               //
//     printf(" (v[0],v[1],v[2]) = (%12.6f,%12.6f,%12.6f)\n", v[0],v[1],v[2]);//
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //

double* Ray_in_3_Space(double v[], double initial_pt[], double direction[],
                                                             double distance )
{
   v[0]  = initial_pt[0] + distance * direction[0];
   v[1]  = initial_pt[1] + distance * direction[1];
   v[2]  = initial_pt[2] + distance * direction[2];

   return v;
}

