////////////////////////////////////////////////////////////////////////////////
// File: reflect_thru_corigin.c                                               //
// Routines:                                                                  //
//    Reflect_through_the_cOrigin                                             //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Reflect_through_the_cOrigin(double complex v[], int n)               //
//                                                                            //
//  Description:                                                              //
//     The n-dim complex vector v is set to -v.                               //
//                                                                            //
//  Arguments:                                                                //
//     double complex v[]                                                     //
//            Pointer to the first element of the vector v.                   //
//     int    n                                                               //
//            The dimension of the vector v[].                                //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double complex v[5];                                                   //
//                                                                            //
//     (your code to intialize the vector v)                                  //
//                                                                            //
//     Reflect_through_the_cOrigin(v, 5);                                     //
//     printf(" (v[0],v[1],v[2],v[3],v[4]) = (%12.6f,%12.6f,%12.6f,%12.6f,    //
//                                   %12.6f)\n", v[0],v[1],v[2],v[3],v[4]);   //
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Reflect_through_the_cOrigin(double complex v[], int n)                     
{
   for (; n > 0; n--) *v++ = -*v;
}
