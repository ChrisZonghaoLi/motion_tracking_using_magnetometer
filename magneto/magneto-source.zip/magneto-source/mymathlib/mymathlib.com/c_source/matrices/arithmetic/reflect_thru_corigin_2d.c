////////////////////////////////////////////////////////////////////////////////
// File: reflect_thru_corigin_2d.c                                            //
// Routines:                                                                  //
//    Reflect_through_the_cOrigin_2d                                          //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Reflect_through_the_cOrigin_2d(double complex v[])                   //
//                                                                            //
//  Description:                                                              //
//     The 2-dim complex vector v is set to -v.                               //
//                                                                            //
//  Arguments:                                                                //
//     double complex v[]                                                     //
//            Pointer to the first element of the vector v[2].                //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double complex v[2];                                                   //
//                                                                            //
//     (your code to intialize the vector v)                                  //
//                                                                            //
//     Reflect_through_the_cOrigin_2d(v);                                     //
//     printf(" (v[0],v[1]) = (%12.6f+%12.6fi,%12.6f+%12.6fi,\n", v[0],v[1]); //
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Reflect_through_the_cOrigin_2d(double complex v[]) 
{
   v[0]  = -v[0];
   v[1]  = -v[1];
}

