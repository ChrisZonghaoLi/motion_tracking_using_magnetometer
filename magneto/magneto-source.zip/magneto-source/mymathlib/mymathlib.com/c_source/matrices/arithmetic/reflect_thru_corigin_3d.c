////////////////////////////////////////////////////////////////////////////////
// File: reflect_thru_corigin_3d.c                                            //
// Routines:                                                                  //
//    Reflect_through_the_cOrigin_3d                                          //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Reflect_through_the_cOrigin_3d(double complex v[])                   //
//                                                                            //
//  Description:                                                              //
//     The 3-dim vector v is set to -v.                                       //
//                                                                            //
//  Arguments:                                                                //
//     double complex v[]                                                     //
//            Pointer to the first element of the vector v[3].                //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double complex v[3];                                                   //
//                                                                            //
//     (your code to intialize the vector v)                                  //
//                                                                            //
//     Reflect_through_the_cOrigin_3d(v);                                     //
//     printf(" (v[0],v[1],v[2]) = (%12.6f+%12.6fi,%12.6f+%12.6fi,%12.6f+     //
//                                               %12.6fi)\n", v[0],v[1],v[2]);//
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Reflect_through_the_cOrigin_3d(double complex v[])                             
{
   v[0]  = -v[0];
   v[1]  = -v[1];
   v[2]  = -v[2];
}
