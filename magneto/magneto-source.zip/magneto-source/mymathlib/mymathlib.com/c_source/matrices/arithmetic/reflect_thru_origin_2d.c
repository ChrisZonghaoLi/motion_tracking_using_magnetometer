////////////////////////////////////////////////////////////////////////////////
// File: reflect_thru_origin_2d.c                                             //
// Routines:                                                                  //
//    Reflect_through_the_Origin_2d                                           //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Reflect_through_the_Origin_2d(double v[])                            //
//                                                                            //
//  Description:                                                              //
//     The 2-dim vector v is set to -v.                                       //
//                                                                            //
//  Arguments:                                                                //
//     double v[]                                                             //
//            Pointer to the first element of the resultant vector v[2].      //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double v[2];                                                           //
//                                                                            //
//     (your code to intialize the vector v)                                  //
//                                                                            //
//     Reflect_through_the_Origin_2d(v);                                      //
//     printf(" (v[0],v[1]) = (%12.6f,%12.6f)\n", v[0],v[1]);                 //
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //

void Reflect_through_the_Origin_2d(double v[])                             
{
   v[0]  = -v[0];
   v[1]  = -v[1];
}

