////////////////////////////////////////////////////////////////////////////////
// File: reflect_thru_origin_2d.h                                             //
// Routines:                                                                  //
//    Reflect_through_the_Origin_2d                                           //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Reflect_through_the_Origin_2d(V *v)                                  //
//                                                                            //
//  Description:                                                              //
//     This is a macro which multiplies the 2-dimensional vector v by the     //
//     scalar -1, i.e. v[j] <- -v[j], j = 0,1.                                //
//                                                                            //
//     The type V could be any type for which the expression -v[i]            //
//     makes sense.                                                           //
//                                                                            //
//  Arguments:                                                                //
//     V v[]   On input the 2-d vector, on output -(the input values).        //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double v[2];                                                           //
//                                                                            //
//     (your code to intialize the vector v)                                  //
//                                                                            //
//     Reflect_through_the_Origin_2d(v);                                      //
//     printf(" (v[0],v[1]) = (%12.6f,%12.6f)\n", v[0],v[1]);                 //
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////

#define Reflect_through_the_Origin_2d(v) ({v[0]=-v[0];v[1]=-v[1];}) 
