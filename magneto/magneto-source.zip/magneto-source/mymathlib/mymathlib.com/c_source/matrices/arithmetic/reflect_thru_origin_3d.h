////////////////////////////////////////////////////////////////////////////////
// File: reflect_thru_origin_3d.h                                             //
// Routines:                                                                  //
//    Reflect_through_the_Origin_3d                                           //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Reflect_through_the_Origin_3d(V *v)                                  //
//                                                                            //
//  Description:                                                              //
//     This is a macro which multiplies the 3-dimensional vector v by the     //
//     scalar -1, i.e. v[j] <- -v[j], j = 0,1,2.                              //
//                                                                            //
//     The type V could be any type for which the expression -v[i]            //
//     makes sense.                                                           //
//                                                                            //
//  Arguments:                                                                //
//     V v[]   On input the 3-d vector, on output -(the input values).        //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double v[3];                                                           //
//                                                                            //
//     (your code to intialize the vector v)                                  //
//                                                                            //
//     Reflect_through_the_Origin_3d(v);                                      //
//     printf(" (v[0],v[1],v[2]) = (%12.6f,%12.6f,%12.6f)\n", v[0],v[1],v[2]);//
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////

#define Reflect_through_the_Origin_3d(v) ({v[0]=-v[0];v[1]=-v[1];v[2]=-v[2];}) 
