////////////////////////////////////////////////////////////////////////////////
// File: row_transformation.c                                                 //
// Routine(s):                                                                //
//    Row_Transformation                                                      //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Row_Transformation(double *A, double x, int row1, int row2,          //
//                                                                 int ncols) //
//                                                                            //
//  Description:                                                              //
//     Multiply the row 'row1' by x and add to 'row2' of the  nrows x ncols   //
//     matrix A, i.e. A[row2][j] <- A[row2][j] + x * A[row1][j], for all j.   //
//                                                                            //
//  Arguments:                                                                //
//     double *A    Pointer to the first element of the matrix A.             //
//     double x     Scalar used to multiply each element of row1 of A.        //
//     int    row1  The row of A which is multiplied by x and then added to   //
//                  row2 of A.                                                //
//     int    row2  The row of A which is changed to the sum of its old value //
//                  and x times the corresponding element of row1.            //
//     int    ncols The number of columns of the matrix A.                    //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double A[M][N], x;                                                     //
//     int i, j;                                                              //
//                                                                            //
//     (your code to create the matrix A, the scalar x, the row number i and  //
//      row number j)                                                         //
//                                                                            //
//     if ( ( i < M ) && ( j < M) ) {                                         //
//        Row_Transformation(&A[0][0], i, j, N);                              //
//         printf("The matrix A is \n"); ...                                  //
//     } else printf("Illegal row numbers.\n");                               //
////////////////////////////////////////////////////////////////////////////////
void Row_Transformation(double *A, double x, int row1, int row2, int ncols)
{
   double *pA1, *pA2;

   pA1 = A + row1 * ncols;
   pA2 = A + row2 * ncols;
   for (; ncols > 0; ncols--) *pA2++ += x * *pA1++;
}
