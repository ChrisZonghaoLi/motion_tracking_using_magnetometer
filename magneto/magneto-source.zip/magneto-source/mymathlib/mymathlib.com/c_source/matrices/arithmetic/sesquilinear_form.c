////////////////////////////////////////////////////////////////////////////////
// File: sesquilinear_form.c                                                  //
// Routine(s):                                                                //
//    Sesquilinear_Form                                                       //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  double complex Sesquilinear_Form(double complex u[], double complex *A,   //
//                                                 double complex v[], int n) //
//                                                                            //
//  Description:                                                              //
//     Pre-multiply the n x n complex matrix A by the complex conjugate of    //
//     the transpose of the complex column vector u and post-multiply by the  //
//     complex column vector v, to form the complex scalar u^(dagger)Av.      //
//     The matrix A should be declared as "double complex A[n][n]" in the     //
//     calling routine.  The vector u declared as "double complex u[n]" and   //
//     the vector v declared as "double complex v[n]" in the calling routine. //
//                                                                            //
//  Arguments:                                                                //
//     double complex *u    Pointer to the first element of the vector u.     //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     double complex *v    Pointer to the first element of the vector v.     //
//     int            n     The number of rows and columns of the matrix A and//
//                          the number of components of the vectors u and v.  //
//                                                                            //
//  Return Values:                                                            //
//     Product of u^(dagger) A v.                                             //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double complex A[N][N], u[N], v[N];                                    //
//     double product;                                                        //
//                                                                            //
//     (your code to initialize the matrix A, column vector u and             //
//                                                         column vector v)   //
//                                                                            //
//     product = Sesquilinear_Form(u, &A[0][0], v, N);                        //
//     printf("The product u'Av is \n"); ...                                  //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

double complex Sesquilinear_Form(double complex u[], double complex *A,
                                                     double complex v[], int n) 
{
   int i,j;
   double complex sum_of_products = 0.0;
   double complex sum;

   for (i = 0; i < n; i++) {
      for (j = 0, sum = 0.0; j < n; j++, A++) sum += *A * v[j];
      sum_of_products += sum * conj(u[i]);
   }
   return sum_of_products;
}
