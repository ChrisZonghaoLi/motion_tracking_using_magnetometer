////////////////////////////////////////////////////////////////////////////////
// File: sub_scalar_from_cdiagonal.c                                          //
// Routine(s):                                                                //
//    Subtract_Scalar_from_CDiagonal                                          //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Subtract_Scalar_from_CDiagonal(double complex *A, double complex x,  //
//                                                    int nrows, int ncols)   //
//                                                                            //
//  Description:                                                              //
//     Subtract the complex scalar x from the each element of the diagonal of //
//     the complex matrix A.                                                  //
//                                                                            //
//  Arguments:                                                                //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     double complex x     Scalar to be subtracted from each diagonal element//
//                          of the matrix A.                                  //
//     int    nrows         The number of rows of matrix A.                   //
//     int    ncols         The number of columns of the matrix A.            //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double complex A[M][N], x;                                             //
//                                                                            //
//     (your code to initialize the matrix A and scalar x)                    //
//                                                                            //
//     Subtract_Scalar_from_CDiagonal(&A[0][0], x, M, N);                     //
//     printf("The matrix A is \n"); ... }                                    //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Subtract_Scalar_from_CDiagonal(double complex *A, double complex x,
                                                          int nrows, int ncols) 
{
   register int i, n;

   n = ( nrows < ncols ) ? nrows : ncols;

   for (i = 0; i < n; A += (ncols + 1), i++) *A -= x; 
}
