////////////////////////////////////////////////////////////////////////////////
// File: sub_scalar_from_diagonal.c                                           //
// Routine(s):                                                                //
//    Subtract_Scalar_from_Diagonal                                           //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Subtract_Scalar_from_Diagonal(double *A, double x, int nrows,        //
//                                                               int ncols)   //
//                                                                            //
//  Description:                                                              //
//     Subtract the scalar x from the each element of the diagonal of the     //
//     matrix A.                                                              //
//                                                                            //
//  Arguments:                                                                //
//     double *A    Pointer to the first element of the matrix A.             //
//     double x     Scalar to be subtracted from each diagonal element of the //
//                  matrix A.                                                 //
//     int    nrows The number of rows of matrix A.                           //
//     int    ncols The number of columns of the matrix A.                    //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double A[M][N],  x;                                                    //
//                                                                            //
//     (your code to initialize the matrix A and scalar x)                    //
//                                                                            //
//     Subtract_Scalar_from_Diagonal(&A[0][0], x, M, N);                      //
//     printf("The matrix A is \n"); ... }                                    //
////////////////////////////////////////////////////////////////////////////////
void Subtract_Scalar_from_Diagonal(double *A, double x, int nrows, int ncols) 
{
   register int i, n;

   n = ( nrows < ncols ) ? nrows : ncols;

   for (i = 0; i < n; A += (ncols + 1), i++) *A -= x; 
}
