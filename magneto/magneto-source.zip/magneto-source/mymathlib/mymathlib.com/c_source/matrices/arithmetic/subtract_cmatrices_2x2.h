////////////////////////////////////////////////////////////////////////////////
// File: subtract_cmatrices_2x2.h                                             //
// Routine(s):                                                                //
//    Subtract_Matrices_2x2                                                   //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Subtract_CMatrices_2x2(double complex *C, double complex *A,         //
//                                                         double complex *B) //
//                                                                            //
//  Description:                                                              //
//     This routine computes C = A - B where A, B, C are 2x2 complex matrices.//
//                                                                            //
//     All matrices should be declared as "double complex X[2][2]" in the     //
//     calling routine where X = A, B, C.                                     //
//                                                                            //
//  Arguments:                                                                //
//     double *C    Address of the first element of the matrix C.             //
//     double *A    Address of the first element of the matrix A.             //
//     double *B    Address of the first element of the matrix B.             //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double complex A[2][2],  B[2][2], C[2][2];                             //
//                                                                            //
//     (your code to initialize the matrices A and B)                         //
//                                                                            //
//     Subtract_CMatrices_2x2((double complex *) C, &A[0][0], &B[0][0]);      //
//     printf("The matrix C = A - B is \n"); ...                              //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

#define Subtract_CMatrices_2x2(C,A,B) {double complex *pC=(double complex *)C;\
double complex *pA=(double complex *)A;\
double complex *pB=(double complex *)B;\
pC[0]=pA[0]-pB[0]; pC[1]=pA[1]-pB[1]; pC[2]=pA[2]-pB[2]; pC[3]=pA[3]-pB[3];}
