////////////////////////////////////////////////////////////////////////////////
// File: subtract_cvectors.c                                                  //
// Routine(s):                                                                //
//    Subtract_CVectors                                                       //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Subtract_CVectors(double complex *w, double complex *u,              //
//                                                  double complex *v, int n) //
//                                                                            //
//  Description:                                                              //
//     Subtract the complex vector v from the complex vector u to form the    //
//     complex vector w, i.e. w[i] = u[i] - v[i].                             //
//     All vectors should be declared as "double complex [n]" in the calling  //
//     routine.                                                               //
//                                                                            //
//  Arguments:                                                                //
//     double complex w[]   Resultant vector w = u - v.                       //
//     double complex u[]   The minuend.                                      //
//     double complex v[]   The subtrahend.                                   //
//     int    n             The number of components of u, v, and w.          //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double complex u[N], v[N], w[N];                                       //
//                                                                            //
//     (your code to initialize the vector u and v)                           //
//                                                                            //
//     Subtract_CVectors(w, u, v, N);                                         //
//     printf("The vector w = u - v is \n"); ...                              //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Subtract_CVectors(double complex w[], double complex u[], 
                                                     double complex v[], int n) 
{
   for (; n > 0; n--) *w++ = *u++ - *v++;
}
