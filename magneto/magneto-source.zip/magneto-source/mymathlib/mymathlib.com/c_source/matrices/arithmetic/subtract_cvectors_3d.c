////////////////////////////////////////////////////////////////////////////////
// File: subtract_cvectors_3d.c                                               //
// Routine(s):                                                                //
//    Subtract_CVectors_3d                                                    //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Subtract_CVectors_3d(double complex *w, double complex *u,           //
//                                                         double complex *v) //
//                                                                            //
//  Description:                                                              //
//     Subtract the 3-dimensional complex vector v from the 3-dimensional     //
//     complex vector u to form the 3-dimensional complex vector w, i.e.      //
//     w[i] = u[i] - v[i].                                                    //
//     All vectors should be declared as "double complex [3] " in the calling //
//     routine.                                                               //
//                                                                            //
//  Arguments:                                                                //
//     double complex w[]   Resultant vector w = u - v.                       //
//     double complex u[]   The minuend.                                      //
//     double complex v[]   The subtrahend.                                   //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double complex u[3], v[3], w[3];                                       //
//                                                                            //
//     (your code to initialize the vector u and v)                           //
//                                                                            //
//     Subtract_CVectors_3d(w, u, v);                                         //
//     printf("The vector w = u - v is \n"); ...                              //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Subtract_CVectors_3d(double complex w[], double complex u[],
                                                            double complex v[]) 
{
   w[0] = u[0] - v[0];
   w[1] = u[1] - v[1];
   w[2] = u[2] - v[2];
}
