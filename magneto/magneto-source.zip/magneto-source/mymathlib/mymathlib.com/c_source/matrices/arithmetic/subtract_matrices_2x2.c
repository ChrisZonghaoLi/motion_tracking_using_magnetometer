////////////////////////////////////////////////////////////////////////////////
// File: subtract_matrices_2x2.c                                              //
// Routine(s):                                                                //
//    Subtract_Matrices_2x2                                                   //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Subtract_Matrices_2x2(double *C, double *A, double *B)               //
//                                                                            //
//  Description:                                                              //
//     This routine computes C = A - B where A, B, C are 2x2 real matrices.   //
//                                                                            //
//     The matrices A,B,C should be declared as "double X[2][2]", for         //
//     X = A, B, C in the calling routine.                                    //
//                                                                            //
//  Arguments:                                                                //
//     double *C    Pointer to the first element of the matrix C.             //
//     double *A    Pointer to the first element of the matrix A.             //
//     double *B    Pointer to the first element of the matrix B.             //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double A[2][2],  B[2][2], C[2][2];                                     //
//                                                                            //
//     (your code to initialize the matrices A and B)                         //
//                                                                            //
//     Subtract_Matrices_2x2(&C[0][0], &A[0][0], &B[0][0]);                   //
//     printf("The matrix C = A - B  is \n"); ...                             //
////////////////////////////////////////////////////////////////////////////////
void Subtract_Matrices_2x2(double *C, double *A, double *B) 
{
   C[0] = A[0] - B[0];
   C[1] = A[1] - B[1];
   C[2] = A[2] - B[2];
   C[3] = A[3] - B[3];
}
