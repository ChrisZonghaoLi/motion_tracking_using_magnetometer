////////////////////////////////////////////////////////////////////////////////
// File: subtract_vectors_2d.c                                                //
// Routine(s):                                                                //
//    Subtract_Vectors_2d                                                     //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Subtract_Vectors_2d(double *w, double *u, double *v)                 //
//                                                                            //
//  Description:                                                              //
//     Subtract the 2-dimensional vector v from the 2-dimensional vector u to //
//     form the 2-dimensional vector w, i.e. w[i] = u[i] - v[i].              //
//     All vectors should be declared as "double [2] " in the calling routine.//
//                                                                            //
//  Arguments:                                                                //
//     double w[]   Resultant vector w = u - v.                               //
//     double u[]   The minuend.                                              //
//     double v[]   The subtrahend.                                           //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double u[2],  v[2], w[2];                                              //
//                                                                            //
//     (your code to initialize the vector u and v)                           //
//                                                                            //
//     Subtract_Vectors_2d(w, u, v);                                          //
//     printf("The vector w = u - v is \n"); ...                              //
////////////////////////////////////////////////////////////////////////////////
void Subtract_Vectors_2d(double w[], double u[], double v[]) 
{
   w[0] = u[0] - v[0];
   w[1] = u[1] - v[1];
}
