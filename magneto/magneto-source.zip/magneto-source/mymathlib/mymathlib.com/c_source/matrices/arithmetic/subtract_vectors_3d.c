////////////////////////////////////////////////////////////////////////////////
// File: subtract_vectors_3d.c                                                //
// Routine(s):                                                                //
//    Subtract_Vectors_3d                                                     //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Subtract_Vectors_3d(double *w, double *u, double *v)                 //
//                                                                            //
//  Description:                                                              //
//     Subtract the 3-dimensional vector v from the 3-dimensional vector u to //
//     form the 3-dimensional vector w, i.e.  w[i] = u[i] - v[i].             //
//     All vectors should be declared as "double [3]" in the calling routine. //
//                                                                            //
//  Arguments:                                                                //
//     double w[]   Resultant vector w = u - v.                               //
//     double u[]   The minuend.                                              //
//     double v[]   The subtrahend.                                           //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double u[3],  v[3], w[3];                                              //
//                                                                            //
//     (your code to initialize the vector u and v)                           //
//                                                                            //
//     Subtract_Vectors_3d(w, u, v);                                          //
//     printf("The vector w = u - v is \n"); ...                              //
////////////////////////////////////////////////////////////////////////////////
void Subtract_Vectors_3d(double w[], double u[], double v[]) 
{
   w[0] = u[0] - v[0];
   w[1] = u[1] - v[1];
   w[2] = u[2] - v[2];
}
