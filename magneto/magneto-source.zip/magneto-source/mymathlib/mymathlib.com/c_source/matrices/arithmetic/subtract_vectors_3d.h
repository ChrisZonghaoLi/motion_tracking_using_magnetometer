////////////////////////////////////////////////////////////////////////////////
// File: subtract_vectors_3d.h                                                //
// Routine(s):                                                                //
//    Subtract_Vectors_3d                                                     //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Subtract_Vectors_3d(X *w, Y* u, Z* v)                                //
//                                                                            //
//  Description:                                                              //
//     This is a macro which subtracts the 3-dimensional vector v from the    //
//     3-dimensional vector u to form the 3-dimensional vector w,             //
//     i.e. w = u - v, where w[j] = u[j] - v[j], j = 0,1,2.                   //
//                                                                            //
//     The types X,Y,Z could be any type for which the expression w = u - v   //
//     makes sense. I.e X could be double complex, Y could be double and      //
//     Z could be complex double.                                             //
//                                                                            //
//  Arguments:                                                                //
//     X w[]   Resultant vector w = u - v.                                    //
//     Y u[]   The minuend.                                                   //
//     Z v[]   The subtrahend.                                                //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double u[3], v[3], w[3];                                               //
//                                                                            //
//     (your code to initialize the vector u and v)                           //
//                                                                            //
//     Subtract_Vectors_3d(w, u, v);                                          //
//     printf("The vector w = u - v is \n"); ...                              //
////////////////////////////////////////////////////////////////////////////////

#define Subtract_Vectors_3d(w,u,v) {\
w[0]=u[0]-v[0];\
w[1]=u[1]-v[1];\
w[2]=u[2]-v[2];}
