////////////////////////////////////////////////////////////////////////////////
// File: sum_over_cmatrix_cols.c                                              //
// Routine(s):                                                                //
//    Sum_over_CMatirx_Columns                                                //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Sum_over_CMatrix_Columns(double complex v[], double complex *A,      //
//                                                      int nrows, int ncols) //
//                                                                            //
//  Description:                                                              //
//     The ith component of the vector v[] is set to the sum of the ith       //
//     column of the complex matrix A.  This is the same as premultiplying A  //
//     by the vector all of whose components are 1.                           //
//                                                                            //
//  Arguments:                                                                //
//     double complex v[]   Pointer to the first element of the vector v the  //
//                          ith component of which is the sum over the ith    //
//                          column of A.                                      //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     int    nrows         The number of rows of matrix A.                   //
//     int    ncols         The number of columns of the matrix A or the      //
//                          dimension of the vector v[].                      //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double complex A[M][N], v[N];                                          //
//                                                                            //
//     (your code to initialize the matrix A)                                 //
//                                                                            //
//     Sum_over_CMatrix_Columns(v, &A[0][0], M, N);                           //
//     printf("The column sums are v \n"); ...                                //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Sum_over_CMatrix_Columns(double complex v[], double complex *A,
                                                          int nrows, int ncols) 
{
   int i,j;

   for (i = 0; i < ncols; i++) v[i] = *A++;

   for (j = 1; j < nrows; j++)
      for (i = 0; i < ncols; i++) v[i] += *A++;
}
