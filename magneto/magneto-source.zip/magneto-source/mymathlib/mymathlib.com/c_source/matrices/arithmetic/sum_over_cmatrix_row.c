////////////////////////////////////////////////////////////////////////////////
// File: sum_over_cmatrix_row.c                                               //
// Routine(s):                                                                //
//    Sum_over_CMatrix_Row                                                    //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  double complex Sum_over_CMatrix_Row(double complex*A, int ncols, int row) //
//                                                                            //
//  Description:                                                              //
//     Sums over the row 'row' of the nrows x ncols complex matrix A.         //
//                                                                            //
//  Arguments:                                                                //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     int    ncols         The number of columns of the matrix A.            //
//     int    row           The row number which is summed.                   //
//                          Note that the sum is over A[row][*]               //
//                                                                            //
//  Return Values:                                                            //
//     double complex sum   The sum of the row 'row' of the matrix A.         //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double complex A[M][N],  sum;                                          //
//                                                                            //
//     (your code to initialize the matrix A and the row number row)          //
//                                                                            //
//     if ( row < M )                                                         //
//        sum = Sum_over_CMatrix_Row(&A[0][0], N, row);                       //
//     printf("The row sum is \n"); ...                                       //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

double complex Sum_over_CMatrix_Row(double complex *A, int ncols, int row) 
{
   double complex sum = 0.0;

   for (A += ncols * row; ncols > 0; ncols--) sum += *A++; 

   return sum;
}
