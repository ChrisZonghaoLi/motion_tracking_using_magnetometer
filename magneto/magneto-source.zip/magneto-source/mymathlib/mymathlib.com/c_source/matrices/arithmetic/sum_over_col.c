////////////////////////////////////////////////////////////////////////////////
// File: sum_over_col.c                                                       //
// Routine(s):                                                                //
//    Sum_over_Column                                                         //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  double Sum_over_Column(double *A, int nrows, int ncols, int col)          //
//                                                                            //
//  Description:                                                              //
//     Sum over column 'col' of the nrows x ncols matrix A.                   //
//                                                                            //
//  Arguments:                                                                //
//     double *A    Pointer to the first element of the matrix A.             //
//     int    nrows The number of rows of matrix A.                           //
//     int    ncols The number of columns of the matrix A.                    //
//     int    col   The column which is summed.                               //
//                  Note that the sum is over A[*][col]                       //
//                                                                            //
//  Return Values:                                                            //
//     double sum   The sum of the column 'col'.                              //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double A[M][N],  sum;                                                  //
//     int col;                                                               //
//                                                                            //
//     (your code to initialize the matrix A)                                 //
//                                                                            //
//     if ( (col > 0) && (col < N) )                                          //
//        sum = Sum_over_Column(&A[0][0], M, N, col);                         //
//     printf("The column sum is \n"); ...                                    //
////////////////////////////////////////////////////////////////////////////////
double Sum_over_Column(double *A, int nrows, int ncols, int col) 
{
   int i;
   double sum = 0.0;

   for (A += col, i = 0; i < nrows; A += ncols, i++) sum += *A;

   return sum;
}
