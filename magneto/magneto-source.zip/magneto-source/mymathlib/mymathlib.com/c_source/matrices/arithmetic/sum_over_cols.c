////////////////////////////////////////////////////////////////////////////////
// File: sum_over_cols.c                                                      //
// Routine(s):                                                                //
//    Sum_over_Columns                                                        //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Sum_over_Columns(double v[], double *A, int nrows, int ncols)        //
//                                                                            //
//  Description:                                                              //
//     The ith component of the vector v[] is set to the sum of the ith       //
//     column of the matrix A.  This is the same as premultiplying A by the   //
//     vector all of whose components are 1.                                  //
//                                                                            //
//  Arguments:                                                                //
//     double v[]   Pointer to the first element of the vector v the ith      //
//                  component of which is the sum over the ith column of A.   //
//     double *A    Pointer to the first element of the matrix A.             //
//                  matrix A.                                                 //
//     int    nrows The number of rows of matrix A.                           //
//     int    ncols The number of columns of the matrix A or the dimension of //
//                  the vector v[].                                           //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double A[M][N],  v[N];                                                 //
//                                                                            //
//     (your code to initialize the matrix A)                                 //
//                                                                            //
//     Sum_over_Columns(v, &A[0][0], M, N);                                   //
//     printf("The column sums are v \n"); ...                                //
////////////////////////////////////////////////////////////////////////////////
void Sum_over_Columns(double v[], double *A, int nrows, int ncols) 
{
   int i,j;
   double *pA;

   for (i = 0; i < ncols; i++)
      for (pA = A + i, v[i] = 0.0, j = 0; j < nrows; pA += ncols, j++)
         v[i] += *pA; 
}
