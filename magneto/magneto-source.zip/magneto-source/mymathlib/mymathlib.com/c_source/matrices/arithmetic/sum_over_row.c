////////////////////////////////////////////////////////////////////////////////
// File: sum_over_row.c                                                       //
// Routine(s):                                                                //
//    Sum_over_Row                                                            //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  double Sum_over_Row(double *A, int ncols, int row)                        //
//                                                                            //
//  Description:                                                              //
//     Sums over the row 'row' of the nrows x ncols matrix A.                 //
//                                                                            //
//  Arguments:                                                                //
//     double *A    Pointer to the first element of the matrix A.             //
//     int    ncols The number of columns of the matrix A.                    //
//     int    row   The row number which is summed.                           //
//                                                                            //
//  Return Values:                                                            //
//     double sum   The sum of the row 'row' of the matrix A.                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double A[M][N],  sum;                                                  //
//                                                                            //
//     (your code to initialize the matrix A and the row number row)          //
//                                                                            //
//     if ( row < M )                                                         //
//        sum = Sum_over_Row(&A[0][0], N, row);                               //
//     printf("The row sum is \n"); ...                                       //
////////////////////////////////////////////////////////////////////////////////
double Sum_over_Row(double *A, int ncols, int row) 
{
   double sum = 0.0;
   int i;

   for (A += ncols * row, i = 0; i < ncols; i++) sum += *A++; 

   return sum;
}
