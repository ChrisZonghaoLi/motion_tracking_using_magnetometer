////////////////////////////////////////////////////////////////////////////////
// File: sum_over_rows.c                                                      //
// Routine(s):                                                                //
//    Sum_over_Rows                                                           //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Sum_over_Rows(double v[], double *A, int nrows, int ncols)           //
//                                                                            //
//  Description:                                                              //
//     The ith component of the vector v[] is set to the sum of the ith row   //
//     of the matrix A.  This is the same as postmultiplying A by the vector  //
//     all of whose components are 1.                                         //
//                                                                            //
//  Arguments:                                                                //
//     double v[]   Pointer to the first element of the vector v the ith      //
//                  component of which is the sum over the ith row of A.      //
//     double *A    Pointer to the first element of the matrix A.             //
//                  matrix A.                                                 //
//     int    nrows The number of rows of matrix A or dimension of v[].       //
//     int    ncols The number of columns of the matrix A.                    //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double A[M][N],  v[M];                                                 //
//                                                                            //
//     (your code to initialize the matrix A)                                 //
//                                                                            //
//     Sum_over_Rows(v, &A[0][0], M, N);                                      //
//     printf("The row sums v are \n"); ... }                                 //
////////////////////////////////////////////////////////////////////////////////
void Sum_over_Rows(double v[], double *A, int nrows, int ncols) 
{
   int i,j;

   for (i = 0; i < nrows; i++)
      for (v[i] = 0.0, j = 0; j < ncols; j++)
         v[i] += *A++; 
}
