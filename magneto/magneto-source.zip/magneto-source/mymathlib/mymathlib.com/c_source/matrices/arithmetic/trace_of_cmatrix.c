////////////////////////////////////////////////////////////////////////////////
// File: trace_of_cmatrix.c                                                   //
// Routine(s):                                                                //
//    Trace_of_CMatrix                                                        //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  double complex Trace_of_CMatrix(double complex *A, int n)                 //
//                                                                            //
//  Description:                                                              //
//     The trace of a square matrix is the sum of the diagonal elements of    //
//     that matrix.  This routines calculates the trace of the square n x n   //
//     complex matrix A.                                                      //
//                                                                            //
//  Arguments:                                                                //
//     double complex *A      Pointer to the first element of the matrix A.   //
//     int    n               The number of rows and columns of the square    //
//                            complex matrix A.                               //
//                                                                            //
//  Return Values:                                                            //
//     double complex trace;                                                  //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double complex A[N][N], trace;                                         //
//                                                                            //
//     (your code to initialize the matrix A)                                 //
//                                                                            //
//     trace = Trace_of_CMatrix(&A[0][0], N);                                 //
//     printf("The trace of A is \n"); ...                                    //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

double complex Trace_of_CMatrix(double complex *A, int n) 
{
   double complex trace = 0.0;
   int i;

   for (i = 0; i < n; A += (n+1), i++) trace += *A;

   return trace;
}
