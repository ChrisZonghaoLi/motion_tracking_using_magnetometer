////////////////////////////////////////////////////////////////////////////////
// File: trace_of_cmatrix_3x3.c                                               //
// Routine(s):                                                                //
//    Trace_of_CMatrix_3x3                                                    //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  double complex Trace_of_CMatrix_3x3(double complex *A)                    //
//                                                                            //
//  Description:                                                              //
//     The trace of a square matrix is the sum of the diagonal elements of    //
//     that matrix.  This routines calculates the trace of the square 3 x 3   //
//     complex matrix A.                                                      //
//                                                                            //
//  Arguments:                                                                //
//     double complex *A      Pointer to the first element of the matrix A.   //
//                                                                            //
//  Return Values:                                                            //
//     double complex trace;                                                  //
//                                                                            //
//  Example:                                                                  //
//     double complex A[3][3], trace;                                         //
//                                                                            //
//     (your code to initialize the matrix A)                                 //
//                                                                            //
//     trace = Trace_of_Matrix_3x3(&A[0][0]);                                 //
//     printf("The trace of A is \n"); ...                                    //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

double complex Trace_of_CMatrix_3x3(double complex *A) 
{
   return A[0] + A[4] + A[8];
}
