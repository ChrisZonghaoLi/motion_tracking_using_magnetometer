////////////////////////////////////////////////////////////////////////////////
// File: trace_of_matrix_2x2.c                                                //
// Routine(s):                                                                //
//    Trace_of_Matrix_2x2                                                     //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  double Trace_of_Matrix_2x2(double *A)                                     //
//                                                                            //
//  Description:                                                              //
//     The trace of a square matrix is the sum of the diagonal elements of    //
//     that matrix.  This routines calculates the trace of the square 2 x 2   //
//     matrix A.                                                              //
//                                                                            //
//  Arguments:                                                                //
//     double *A      Pointer to the first element of the matrix A.           //
//                                                                            //
//  Return Values:                                                            //
//     double trace;                                                          //
//                                                                            //
//  Example:                                                                  //
//     double A[2][2], trace;                                                 //
//                                                                            //
//     (your code to initialize the matrix A)                                 //
//                                                                            //
//     trace = Trace_of_Matrix_2x2(&A[0][0]);                                 //
//     printf("The trace of A is \n"); ...                                    //
////////////////////////////////////////////////////////////////////////////////
double Trace_of_Matrix_2x2(double *A) 
{
   return A[0] + A[3];
}
