////////////////////////////////////////////////////////////////////////////////
// File: trace_of_matrix_3x3.c                                                //
// Routine(s):                                                                //
//    Trace_of_Matrix_3x3                                                     //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  double Trace_of_Matrix_3x3(double *A)                                     //
//                                                                            //
//  Description:                                                              //
//     The trace of a square matrix is the sum of the diagonal elements of    //
//     that matrix.  This routines calculates the trace of the square 3 x 3   //
//     matrix A.                                                              //
//                                                                            //
//  Arguments:                                                                //
//     double *A      Pointer to the first element of the matrix A.           //
//                                                                            //
//  Return Values:                                                            //
//     double trace;                                                          //
//                                                                            //
//  Example:                                                                  //
//     double A[3][3], trace;                                                 //
//                                                                            //
//     (your code to initialize the matrix A)                                 //
//                                                                            //
//     trace = Trace_of_Matrix_3x3(&A[0][0]);                                 //
//     printf("The trace of A is \n"); ...                                    //
////////////////////////////////////////////////////////////////////////////////
double Trace_of_Matrix_3x3(double *A) 
{
   return A[0] + A[4] + A[8];
}
