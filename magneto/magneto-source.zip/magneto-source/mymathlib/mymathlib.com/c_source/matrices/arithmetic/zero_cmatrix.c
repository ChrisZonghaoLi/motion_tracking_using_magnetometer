////////////////////////////////////////////////////////////////////////////////
// File: zero_cmatrix.c                                                       //
// Routine(s):                                                                //
//    Zero_CMatrix                                                            //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Zero_CMatrix(double complex *A, int nrows, int ncols)                //
//                                                                            //
//  Description:                                                              //
//     Set the nrows x ncols complex matrix A equal to the zero matrix, i.e.  //
//     A[i][j] = 0 for all i, j.                                              //
//                                                                            //
//  Arguments:                                                                //
//     double complex *A    Pointer to the first element of the matrix A.     //
//     int    nrows         The number of rows of the matrix A.               //
//     int    ncols         The number of columns of the matrix A.            //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     #define M                                                              //
//     double complex A[N][M];                                                //
//                                                                            //
//     Zero_CMatrix(&A[0][0], N, M);                                          //
//     printf("The matrix A is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Zero_CMatrix(double complex *A, int nrows, int ncols)
{
   int n = nrows * ncols;

   for (; n > 0; n--) *A++ = 0.0;
}
