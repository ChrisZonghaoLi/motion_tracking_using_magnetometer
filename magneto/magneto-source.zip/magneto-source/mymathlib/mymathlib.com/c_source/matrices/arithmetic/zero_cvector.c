////////////////////////////////////////////////////////////////////////////////
// File: zero_cvector.c                                                       //
// Routine(s):                                                                //
//    Zero_CVector                                                            //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Zero_CVector(double complex *v, int n)                               //
//                                                                            //
//  Description:                                                              //
//     Set the complex vector v equal to the zero vector, i.e. v[i] = 0       //
//     for all i.                                                             //
//                                                                            //
//  Arguments:                                                                //
//     double complex *v  Pointer to the first element of the vector v.       //
//     int    n           The number of components of the vector v.           //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double v[N];                                                           //
//                                                                            //
//     Zero_CVector(v, N);                                                    //
//     printf("The vector v is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

#include <complex.h>

void Zero_CVector(double complex *v, int n)
{
   for (; n > 0; n--) *v++ = 0.0;
}
