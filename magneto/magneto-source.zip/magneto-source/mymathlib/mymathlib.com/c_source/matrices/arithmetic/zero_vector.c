////////////////////////////////////////////////////////////////////////////////
// File: zero_vector.c                                                        //
// Routine(s):                                                                //
//    Zero_Vector                                                             //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Zero_Vector(double *A, int n)                                        //
//                                                                            //
//  Description:                                                              //
//     Set the vector A equal to the zero vector, i.e. A[i] = 0 for all i.    //
//                                                                            //
//  Arguments:                                                                //
//     double *A    Pointer to the first element of the vector A.             //
//     int    n     The number of components of the vector A.                 //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N];                                                           //
//                                                                            //
//     Zero_Vector(A, N);                                                     //
//     printf("The vector A is \n"); ...                                      //
////////////////////////////////////////////////////////////////////////////////

void Zero_Vector(double *A, int n)
{
   for (; n > 0; n--) *A++ = 0.0;
}
