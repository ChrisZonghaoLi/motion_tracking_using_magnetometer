////////////////////////////////////////////////////////////////////////////////
// File: cgauss_elimination.c                                                 //
// Routines:                                                                  //
//    cGaussian_Elimination                                                   //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  int cGaussian_Elimination(double complex *A, int n, double complex *B)    //
//                                                                            //
//     Solve the linear system of equations AX=B where A is an n x n complex  //
//     matrix, B is an n-dimensional complex column vector (n x 1 matrix) for //
//     the n-dimensional column vector (n x 1 matrix) X.                      //
//                                                                            //
//     This routine performs partial pivoting and the elements of A are       //
//     modified during computation.  The result X is returned in B.           //
//     If the matrix A is singular, the return value of the function call is  //
//     -1. If the solution was found, the function return value is 0.         //
//                                                                            //
//  Arguments:                                                                //
//     double complex *A                                                      //
//       On input, the pointer to the first element of the complex matrix     //
//       A[n][n].  On output, the matrix A is destroyed.                      //
//     int     n                                                              //
//       The number of rows and columns of the complex matrix A and the       //
//                    dimension of B.                                         //
//     double complex *B                                                      //
//        On input, the pointer to the first element of the vector B[n].      //
//        On output, the vector B is replaced by the vector X, the solution   //
//        of AX = B.                                                          //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix A is singular.                                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double complex A[N][N], B[N];                                          //
//                                                                            //
//     (your code to create the matrix A and vector B )                       //
//     err = cGaussian_Elimination(&A[0][0], NROWS, B);                       //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else { printf(" The Solution is: \n"); ...                             //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
#include <complex.h>
#include <math.h>   

int cGaussian_Elimination(double complex *A, int n, double complex *B)
{
   int row, i, j, pivot_row;
   double max, dum;
   double complex *pa, *pA, *A_pivot_row, cdum;

      // for each variable find pivot row and perform forward substitution

   pa = A;
   for (row = 0; row < (n - 1); row++, pa += n) {

                       //  find the pivot row

      A_pivot_row = pa;
      max = cabs(*(pa + row));
      pA = pa + n;
      pivot_row = row;
      for (i = row + 1; i < n; pA += n, i++)
         if ((dum = cabs(*(pA + row))) > max) { 
            max = dum; A_pivot_row = pA; pivot_row = i; 
         }
      if (max == 0.0) return -1;                // the matrix A is singular

        // and if it differs from the current row, interchange the two rows.
             
      if (pivot_row != row) {
         for (i = row; i < n; i++) {
            cdum = *(pa + i);
            *(pa + i) = *(A_pivot_row + i);
            *(A_pivot_row + i) = cdum;
         }
         cdum = B[row];
         B[row] = B[pivot_row];
         B[pivot_row] = cdum;
      }

                      // Perform forward substitution

      for (i = row + 1; i < n; i++) {
         pA = A + i * n;
         cdum = - *(pA + row) / *(pa + row);
         *(pA + row) = 0.0;
         for (j = row + 1; j < n; j++) *(pA + j) += cdum * *(pa + j);
         B[i] += cdum * B[row];
      }
   }

                    // Perform backward substitution
  
   pa = A + (n - 1) * n;
   for (row = n - 1; row >= 0; pa -= n, row--) {
      if ( cabs(*(pa + row)) == 0.0 ) return -1;         // matrix is singular
      cdum = 1.0 / *(pa + row);
      for ( i = row + 1; i < n; i++) *(pa + i) *= cdum; 
      B[row] *= cdum; 
      for ( i = 0, pA = A; i < row; pA += n, i++) {
         cdum = *(pA + row);
         for ( j = row + 1; j < n; j++) *(pA + j) -= cdum * *(pa + j);
         B[i] -= cdum * B[row];
      }
   }
   return 0;
}
