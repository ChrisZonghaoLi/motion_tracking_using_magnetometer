////////////////////////////////////////////////////////////////////////////////
// File: choleski_band.c                                                      //
// Contents:                                                                  //
//    Choleski_LU_Decomposition_Band                                          //
//    Choleski_LU_Solve_Band                                                  //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LU_Decomposition_Band(double *A, int n, int bandwidth)       //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to decompose the n x n positive    //
//     definite symmetric band matrix A into the product of a lower triangular//
//     band matrix L and an upper triangular band matrix U equal to the trans-//
//     pose of L.                                                             //
//     The original matrix A is replaced by L and U with L stored in the      //
//     lower triangular part of A and its transpose U in the upper triangular //
//     part of A. The original matrix A is therefore destroyed.               //
//                                                                            //
//     Choleski's decomposition is performed by evaluating, in order, the     //
//     following pair of expressions for k = 0, ... ,n-1 :                    //
//       L[k][k] = sqrt( A[k][k] - ( L[k][0] ^ 2 + ... + L[k][k-1] ^ 2 ) )    //
//       L[i][k] = (A[i][k] - (L[i][0]*L[k][0] + ... + L[i][k-1]*L[k][k-1]))  //
//                          / L[k][k]                                         //
//     and subsequently setting                                               //
//       U[k][i] = L[i][k], for i = k+1, ... , min(n-1, k+bandwidth)          //
//                                                                            //
//     After performing the LU decomposition for A, in order to solve the     //
//     equation Ax = B call Choleski_LU_Solve_Band.                           //
//     Note that the inverse of a band matrix need not be a band matrix.      //
//                                                                            //
//  Arguments:                                                                //
//     double *A                                                              //
//        On input, the pointer to the first element of the matrix A[n][n].   //
//        On output, the matrix A is replaced by the lower and upper triang-  //
//        ular Choleski factorizations of A.                                  //
//     int     n                                                              //
//        The number of rows and/or columns of the matrix A.                  //
//     int     bandwidth                                                      //
//        The bandwidth of a band matrix A is defined as the number m such    //
//        that for all i,j if |i-j| > (m-1)/2, then A[i][j]=0.  A diagonal    //
//        matrix has a bandwidth of 1 while a tridiagonal matrix has a        //
//        bandwidth of 3.                                                     //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix A is not positive definite symmetric (within   //
//                  working accuracy).                                        //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N][N];                                                        //
//     int bandwidth;                                                         //
//                                                                            //
//     (your code to initialize the matrix A and the bandwidth)               //
//     err = Choleski_LU_Decomposition_Band((double *) A, N, bandwidth);      //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else { printf(" The LLt decomposition of A is \n");                    //
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //

#include <math.h>                                       // required for sqrt()

int Choleski_LU_Decomposition_Band(double *A, int n, int bandwidth)
{
   int i, k, p, nz;
   double *p_Lk0;                   // pointer to L[k][0]
   double *p_Lkp;                   // pointer to L[k][p]  
   double *p_Lkk;                   // pointer to diagonal element on row k.
   double *p_Li0;                   // pointer to L[i][0]
   double reciprocal;

   for (k = 0, p_Lk0 = A; k < n; p_Lk0 += n, k++) {
           
//            Update pointer to row k diagonal element.   

      p_Lkk = p_Lk0 + k;

//            Calculate the difference of the diagonal element in row k
//            from the sum of squares of elements row k from column 0 to 
//            column k-1.

      p = ( k < bandwidth ) ? 0 : k - bandwidth;
      for (p_Lkp = p_Lk0 + p; p < k; p_Lkp += 1,  p++)
         *p_Lkk -= *p_Lkp * *p_Lkp;

//            If diagonal element is not positive, return the error code,
//            the matrix is not positive definite symmetric.

      if ( *p_Lkk <= 0.0 ) return -1;

//            Otherwise take the square root of the diagonal element.

      *p_Lkk = sqrt( *p_Lkk );
      reciprocal = 1.0 / *p_Lkk;

//            For rows i = k+1 to n-1, column k, calculate the difference
//            between the i,k th element and the inner product of the first
//            k-1 columns of row i and row k, then divide the difference by
//            the diagonal element in row k.
//            Store the transposed element in the upper triangular matrix.

      p_Li0 = p_Lk0 + n;
      nz = ( (k + bandwidth + 1) < n ) ? k + bandwidth + 1 : n;
      for (i = k + 1; i < nz; p_Li0 += n, i++) {
         for (p = 0; p < k; p++)
            *(p_Li0 + k) -= *(p_Li0 + p) * *(p_Lk0 + p);
         *(p_Li0 + k) *= reciprocal;
         *(p_Lk0 + i) = *(p_Li0 + k);
      }  
   }
   return 0;
}


////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LU_Solve_Band(double *LU, double *B, double *x, int n,       //
//                                                            int bandwidth ) //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to solve the linear equation       //
//     Ax = B.  This routine is called after the matrix A has been decomposed //
//     into a product of a lower triangular band matrix L and an upper band   //
//     triangular matrix U which is the transpose of L. The matrix A is the   //
//     product LU.                                                            //
//     The solution proceeds by solving the linear equation Ly = B for y and  //
//     subsequently solving the linear equation Ux = y for x.                 //
//                                                                            //
//  Arguments:                                                                //
//     double *LU                                                             //
//        Pointer to the first element of the matrix whose elements form the  //
//        ower and upper triangular matrix factors of A.                      //
//     double *B                                                              //
//        Pointer to the column vector, (n x 1) matrix, B                     //
//     double *x                                                              //
//        Solution to the equation Ax = B.                                    //
//     int     n                                                              //
//        The number of rows and/or columns of the matrix A.                  //
//     int     bandwidth                                                      //
//        The bandwidth of a band matrix A is defined as the number m such    //
//        that for all i,j if |i-j| > (m-1)/2, then A[i][j]=0.  A diagonal    //
//        matrix has a bandwidth of 1 while a tridiagonal matrix has a        //
//        bandwidth of 3.                                                     //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix L is singular.                                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N][N], B[N], x[N];                                            //
//     int bandwidth;                                                         //
//                                                                            //
//     (your code to create matrix A, column vector B, and bandwidth)         //
//     err = Choleski_LU_Decomposition_Band(&A[0][0], N, bandwidth);          //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else {                                                                 //
//        err = Choleski_LU_Solve_Band(&A[0][0], B, x, n, bandwidth);         //
//        if (err < 0) printf(" Matrix A is singular\n");                     //
//        else printf(" The solution is \n");                                 //
//           ...                                                              //
//     }                                                                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LU_Solve_Band(double *LU, double B[], double x[], int n, 
                                                                int bandwidth)
{
   int i, k, nz ;
   double *p_k;

//         Solve the linear equation Ly = B for y, where L is a lower
//         triangular matrix.
   
   for (k = 0, p_k = LU; k < n; p_k += n, k++) {
      x[k] = B[k];
      nz = ( (k - bandwidth - 1) > 0 ) ? k - bandwidth - 1 : 0;
      for (i = nz; i < k; i++)  x[k] -= x[i] * *(p_k + i);
      if (*(p_k + k) == 0.0) return -1;
      x[k] /= *(p_k + k);
   }

//         Solve the linear equation Ux = y, where y is the solution
//         obtained above of Ly = B and U is an upper triangular matrix.

   for (k = n-1, p_k = LU + n*(n-1); k >= 0; k--, p_k -= n) {
      nz = ( (k + bandwidth + 1) < n ) ? k + bandwidth + 1 : n;
      for (i = k + 1; i < nz; i++) x[k] -= x[i] * *(p_k + i);
      x[k] /= *(p_k + k);
   }
  
   return 0;
}
