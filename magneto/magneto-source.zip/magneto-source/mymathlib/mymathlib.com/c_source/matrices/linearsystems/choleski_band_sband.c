////////////////////////////////////////////////////////////////////////////////
// File: choleski_band_sband.c                                                //
// Contents:                                                                  //
//    Choleski_LU_Decomposition_Band_sband                                    //
//    Choleski_LU_Solve_Band_sband                                            //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LU_Decomposition_Band_sband(double *A, int n, int bandwidth) //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to decompose the n x n positive    //
//     definite symmetric band matrix A into the product of a lower triangular//
//     band matrix L and an upper triangular band matrix U equal to the trans-//
//     pose of L.                                                             //
//                                                                            //
//     The symmetric band form storage of a symmetric band matrix is a method //
//     of storage in which for each row only the left half band is stored in  //
//     memory.  The elements are stored in the band in the same order as the  //
//     columns of the matrix from which they are culled with the right-most   //
//     element of the band corresponding to the diagonal element of the       //
//     matrix.  The right-most element of the band always corresponds to      //
//     a diagonal element, elements in a band which do not correspond to a    //
//     matrix element must be set to 0.0, e.g. the band which corresponds to  //
//     the first row is  (0.0, 0.0, ..., 0.0, d), where d is the diagonal     //
//     element.                                                               //
//                                                                            //
//     The original matrix A is replaced by L and therefore the matrix A is   //
//     destroyed.                                                             //
//                                                                            //
//     Choleski's decomposition is performed by evaluating, in order, the     //
//     following pair of expressions for k = 0, ... ,n-1 :                    //
//       L[k][k] = sqrt( A[k][k] - ( L[k][0] ^ 2 + ... + L[k][k-1] ^ 2 ) )    //
//       L[i][k] = (A[i][k] - (L[i][0]*L[k][0] + ... + L[i][k-1]*L[k][k-1]))  //
//                          / L[k][k]                                         //
//       for i = k+1, ... , min(n-1, k+bandwidth)                             //
//                                                                            //
//     After performing the LU decomposition for A, in order to solve the     //
//     equation Ax = B call Choleski_LU_Solve_Band_sband.                     //
//     Note that the inverse of a band matrix need not be a band matrix.      //
//                                                                            //
//  Arguments:                                                                //
//     double *A                                                              //
//        On input, the pointer to the first element of the band of the first //
//        row of the matrix A, note that A is declared as A[n][bandwidth] in  //
//        the calling routine.                                                //
//        On output, the matrix A is replaced by the lower triangular Choleski//
//        factor of A.                                                        //
//     int     n                                                              //
//        The number of rows and/or columns of the matrix A.                  //
//     int     bandwidth                                                      //
//        The bandwidth of the symmetric matrix A, for symmetric matrices     //
//        is defined as the number m such that for all i,j if |i-j| >= m,     //
//        then A[i][j]=0.  Therefore a symmetric tridiagonal matrix has       //
//        a bandwidth of 2.                                                   //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix A is not positive definite symmetric (within   //
//                  working accuracy).                                        //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N][N];                                                        //
//     int bandwidth;                                                         //
//                                                                            //
//     (your code to initialize the matrix A and the bandwidth)               //
//     err = Choleski_LU_Decomposition_Band_sband((double *) A, N, bandwidth);//
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else { printf(" The LLt decomposition of A is \n");                    //
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //

#include <math.h>                                       // required for sqrt()

int Choleski_LU_Decomposition_Band_sband(double *A, int n, int bandwidth)
{
   int i, k, p, nz;
   int center = bandwidth - 1;
   double *p_Lk0;                   // pointer to L[k][0]
   double *p_Lkp;                   // pointer to L[k][p]  
   double *p_Lkk;                   // pointer to diagonal element on row k.
   double *p_Li0;                   // pointer to L[i][0]
   double reciprocal;

   for (k = 0, p_Lkk = A + center; k < n; p_Lkk += bandwidth, k++) {
           
//            Calculate the difference of the diagonal element in row k
//            from the sum of squares of elements row k from column 0 to 
//            column k-1.

      for (p_Lkp = p_Lkk - center; p_Lkp < p_Lkk; p_Lkp += 1)
         *p_Lkk -= *p_Lkp * *p_Lkp;

//            If diagonal element is not positive, return the error code,
//            the matrix is not positive definite symmetric.

      if ( *p_Lkk <= 0.0 ) return -1;

//            Otherwise take the square root of the diagonal element.

      *p_Lkk = sqrt( *p_Lkk );
      reciprocal = 1.0 / *p_Lkk;

//            For rows i = k+1 to n-1, column k, calculate the difference
//            between the i,k th element and the inner product of the first
//            k-1 columns of row i and row k, then divide the difference by
//            the diagonal element in row k.
//            Store the transposed element in the upper triangular matrix.

      p_Lk0 = p_Lkk - center;
      p_Li0 = p_Lk0 + bandwidth;
      nz = ( (k + center) < n ) ? center : n - k - 1;
      for (i = 1; i <= nz; p_Li0 += bandwidth, i++) {
         for (p = i; p < center; p++)
            *(p_Li0 + center - i) -= *(p_Li0 + p - i) * *(p_Lk0 + p);
         *(p_Li0 + center - i) *= reciprocal;
      }  
   }
   return 0;
}


////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LU_Solve_Band_sband(double *LU, double *B, double *x, int n, //
//                                                            int bandwidth ) //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to solve the linear equation       //
//     Ax = B.  This routine is called after the matrix A has been decomposed //
//     into a product of a lower triangular band matrix L and an upper band   //
//     triangular matrix U which is the transpose of L. The matrix A is the   //
//     product LU.                                                            //
//     The solution proceeds by solving the linear equation Ly = B for y and  //
//     subsequently solving the linear equation Ux = y for x.                 //
//                                                                            //
//  Arguments:                                                                //
//     double *LU  Pointer to the first element of the matrix whose elements  //
//                 form the lower and upper triangular matrix factors of A.   //
//     double *B   Pointer to the column vector, (n x 1) matrix, B            //
//     double *x   Solution to the equation Ax = B.                           //
//     int     n   The number of rows and/or columns of the matrix LU.        //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix L is singular.                                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N][N], B[N], x[N];                                            //
//     int bandwidth;                                                         //
//                                                                            //
//     (your code to create matrix A, column vector B, and bandwidth)         //
//     err = Choleski_LU_Decomposition_Band_sband(&A[0][0], N, bandwidth);    //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else {                                                                 //
//        err = Choleski_LU_Solve_Band_sband(&A[0][0], B, x, n, bandwidth);   //
//        if (err < 0) printf(" Matrix A is singular\n");                     //
//        else printf(" The solution is \n");                                 //
//           ...                                                              //
//     }                                                                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LU_Solve_Band_sband(double *LU, double B[], double x[], int n, 
                                                                int bandwidth)
{
   int i, k, nz ;
   int center = bandwidth - 1;
   double *p_k, *p_i;

//         Solve the linear equation Ly = B for y, where L is a lower
//         triangular matrix.

   for (k = 0, p_k = LU; k < n; p_k += bandwidth, k++) {
      x[k] = B[k];
      nz = ( k > center ) ? 0 : center - k;
      for (i = nz; i < center; i++)  x[k] -= x[k-center+i] * *(p_k + i);
      if (*(p_k + center) == 0.0) return -1;
      x[k] /= *(p_k + center);
   }

//         Solve the linear equation Ux = y, where y is the solution
//         obtained above of Ly = B and U is an upper triangular matrix.

   for (k = n-1, p_k = LU + (n - 1) * bandwidth; k >= 0; k--, p_k -= bandwidth){
      nz = ( (n - k) > center ) ? center + bandwidth : center + (n - k);
      p_i = p_k + center + bandwidth - 1;
      for (i = center + 1; i < nz; p_i += bandwidth - 1, i++)
         x[k] -= x[k + i - center] * *p_i;
      x[k] /= *(p_k + center);
   }
  
   return 0;
}
