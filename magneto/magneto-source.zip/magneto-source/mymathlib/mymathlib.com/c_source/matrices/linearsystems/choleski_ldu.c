////////////////////////////////////////////////////////////////////////////////
// File: choleski_ldu.c                                                       //
// Contents:                                                                  //
//    Choleski_LDU_Decomposition                                              //
//    Choleski_LDU_Solve                                                      //
//    Choleski_LDU_Inverse                                                    //
//                                                                            //
// Required Externally Defined Routines:                                      //
//    Unit_Lower_Triangular_Solve                                             //
//    Unit_Lower_Triangular_Inverse                                           //
//    Unit_Upper_Triangular_Solve                                             //
////////////////////////////////////////////////////////////////////////////////

//                    Required Externally Defined Routines
void Unit_Lower_Triangular_Solve(double *L, double B[], double x[], int n);
void Unit_Lower_Triangular_Inverse(double *L, int n);
void Unit_Upper_Triangular_Solve(double *U, double B[], double x[], int n);

////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LDU_Decomposition(double *A, int n)                          //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to decompose the n x n positive    //
//     definite symmetric matrix A into the product of a unit lower triangular//
//     matrix L, a diagonal matrix D, and a unit upper triangular matrix U    //
//     equal to the transpose of L.  A unit triangular matrix is a triangular //
//     matrix with ones along the diagonal.                                   //
//     The matrices L, D, and U replace the matrix A so that the original     //
//     matrix A is destroyed.  The matrix L replaces the lower triangular     //
//     part of A, U replaces the upper triangular part of A, and D replaces   //
//     the diagonal of A.                                                     //
//                                                                            //
//     Choleski's LDU decomposition is performed by evaluating, in order, the //
//     following of expressions for i = 0, ... ,n-1 :                         //
//       L[i][k]*D[k] = (A[i][k] - (L[i][0]*D[0]*L[k][0] + ... +              //
//                                            L[i][k-1]*D[k-1]*L[k][k-1]) )   //
//       D[i] = A[i][i] - ( L[i][0]*D[0]*L[i][0] + ... +                      //
//                                          L[k][k-1]*D[k-1]*L[i][k-1] ) )    //
//     and subsequently setting                                               //
//       U[k][i] = L[i][k], for k = 0, ... , i-1.                             //
//                                                                            //
//     After performing the LDU decomposition for A, call Choleski_LDU_Solve  //
//     to solve the equation Ax = B or call Choleski_LDU_Inverse to calculate //
//     the inverse of the matrix A.                                           //
//                                                                            //
//  Arguments:                                                                //
//     double *A   On input, the pointer to the first element of the matrix   //
//                 A[n][n].  On output, the matrix A is replaced by the lower //
//                 triangular, diagonal, and  upper triangular matrices of the//
//                 Choleski LDL' factorization of A.                          //
//     int     n   The number of rows and/or columns of the matrix A.         //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix A is not positive definite symmetric (within   //
//                  working accuracy).                                        //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N][N];                                                        //
//                                                                            //
//     (your code to initialize the matrix A)                                 //
//     err = Choleski_LDU_Decomposition((double *) A, N);                     //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else { printf(" The LDLt decomposition of A is \n");                   //
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LDU_Decomposition(double *A, int n)
{
   int i, j, k;
   double *p_i;                   // pointer to L[i][0]
   double *p_j;                   // pointer to L[j][0]
   double *p_k;                   // pointer to L[k][0]
   double ld;                     // dummy storage

   for (i = 1, p_i = A + n; i < n; p_i += n, i++) {
           
//            Calculate elements given by the product L[i][j]*D[j].   

      for (j = 0, p_j = A; j < i; j++, p_j += n) 
         for (k = 0; k < j; k++)
            *(p_i + j) -= *(p_i + k) * *(p_j + k);

//            Calculate the diagonal element D[i] and L[i][j].
//            Store the transpose L[k][i];
      
      for (k = 0, p_k = A; k < i; p_k += n, k++) {
            ld = *(p_i + k) / *(p_k + k);
            *(p_i + i) -= *(p_i + k) * ld;
            *(p_i + k) = ld;
            *(p_k + i) = ld;
      }
      if ( *(p_i + i) <= 0.0 ) return -1;
   }
   return 0;
}


////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LDU_Solve(double *LDU, double *B, double *x,  int n)         //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to solve the linear equation       //
//     Ax = B.  This routine is called after the matrix A has been decomposed //
//     into the product of a unit lower triangular matrix L, a diagonal matrix//
//     D, and a unit upper triangular matrix U which is the transpose of L.   //
//     The matrix A is the product LDU.                                       //
//     The solution proceeds by solving the linear equation Ly = B for y,     //
//     then solving Dz = y for z and finally solving Ux = z for x.            //
//                                                                            //
//  Arguments:                                                                //
//     double *LDU Pointer to the first element of the matrix whose elements  //
//                 form the unit lower triangular, diagonal, and unit upper   //
//                 triangular matrix factors of A.                            //
//     double *B   Pointer to the column vector, (n x 1) matrix, B            //
//     double *x   Solution to the equation Ax = B.                           //
//     int     n   The number of rows or columns of the matrix LU.            //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix D is singular.                                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N][N], B[N], x[N];                                            //
//                                                                            //
//     (your code to create matrix A and column vector B)                     //
//     err = Choleski_LDU_Decomposition(&A[0][0], N);                         //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else {                                                                 //
//        err = Choleski_LDU_Solve(&A[0][0], B, x, n);                        //
//        if (err < 0) printf(" Matrix A is singular\n");                     //
//        else printf(" The solution is \n");                                 //
//           ...                                                              //
//     }                                                                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LDU_Solve(double *LDU, double B[], double x[], int n)
{
   int k;
   double *p_k;

//         Solve the linear equation Ly = B for y, where L is a unit lower
//         triangular matrix.
   
   Unit_Lower_Triangular_Solve(LDU, B, x, n);

//         Solve the linear equation Dz = y for z, where D is the diagonal
//         matrix.

   for (k = 0, p_k = LDU; k < n; k++, p_k += n) { 
      if ( *(p_k + k) == 0.0 ) return -1;
      x[k] /= *(p_k + k);
   }

//         Solve the linear equation Ux = z, where z is the solution
//         obtained above of Ly = B and Dz = y.  
//         U is a unit upper triangular matrix.

   Unit_Upper_Triangular_Solve(LDU, x, x, n);

   return 0;
}


////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LDU_Inverse(double *LDU,  int n)                             //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to find the inverse of the matrix  //
//     A.  This routine is called after the matrix A has been decomposed      //
//     into a product of a unit lower triangular matrix L, a diagonal matrix  //
//     D and a unit upper triangular matrix U which is the transpose of L.    //
//     The matrix A is the product of L, D, and U.  Upon completion, the      //
//     inverse of A is stored in LDU so that the matrix LDU is destroyed.     //
//                                                                            //
//  Arguments:                                                                //
//     double *LDU Pointer to the first element of the matrix whose elements  //
//                 form the unit lower triangular matrix, the diagonal matrix,//
//                 and the unit upper triangular matrix factors of A.         //
//     int     n   The number of rows or columns of the matrix LDU.           //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix A is singular.                                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N][N], B[N], x[N];                                            //
//                                                                            //
//     (your code to create matrix A and column vector B)                     //
//     err = Choleski_LDU_Decomposition(&A[0][0], N);                         //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else {                                                                 //
//        err = Choleski_LDU_Inverse(&A[0][0], n);                            //
//        if (err < 0) printf(" Matrix A is singular\n");                     //
//        else printf(" The inverse is \n");                                  //
//           ...                                                              //
//     }                                                                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LDU_Inverse(double *LDU, int n)
{
   int i, j, k;
   double *p_i, *p_j, *p_k;

//         Invert the unit lower triangular matrix L.

   Unit_Lower_Triangular_Inverse(LDU, n);

//     Premultiply L inverse by the transpose of L inverse and D inverse.      

   for (j = 0, p_j = LDU; j < n; j++, p_j += n) {
      for (i = j, p_i = p_j; i < n; p_i += n, i++) {
         if (j == i) *(p_i + j) = 1.0 / *(p_i + i);
         else *(p_i + j) /= *(p_i + i);
         for (k = i + 1, p_k = p_i + n; k < n; k++, p_k += n)
            *(p_i + j) += *(p_k + i) * *(p_k + j) / *(p_k + k);
         *(p_j + i) = *(p_i + j);
      }
   }
  
   return 0;
}
