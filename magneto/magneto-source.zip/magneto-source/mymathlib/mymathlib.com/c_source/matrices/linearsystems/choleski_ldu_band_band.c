////////////////////////////////////////////////////////////////////////////////
// File: choleski_ldu_band_band.c                                             //
// Contents:                                                                  //
//    Choleski_LDU_Decomposition_Band_band                                    //
//    Choleski_LDU_Solve_Band_band                                            //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LDU_Decomposition_Band_band(double *A, int n, int bandwidth) //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to decompose the n x n positive    //
//     definite symmetric band matrix A stored in band form into the product  //
//     of a unit lower triangular band matrix L, a diagonal matrix D, and a   //
//     unit upper triangular band matrix U equal to the transpose of L.       //
//                                                                            //
//     A unit triangular matrix is a triangular matrix with ones along the    //
//     diagonal.                                                              //
//                                                                            //
//     Band form storage of a band matrix is a method of storage in which for //
//     each row only the band is stored in memory.  The elements are stored in//
//     the band in the same order as the columns of the matrix from which they//
//     are culled with the center of the band corresponding to the diagonal   //
//     element of the matrix.  The center of the band always corresponds to   //
//     a diagonal element, elements in a band which do not correspond to a    //
//     matrix element must be set to 0.0, e.g. the band which corresponds to  //
//     the first row is  (0.0, 0.0, ..., 0.0, d, a, b, ..., z), where d is    //
//     the diagonal element and similary the band which corresponds to the    //
//     last row is (z,...,b,a,d,0.0,...,0.0) where d is the diagonal element  //
//     in the last row.                                                       //
//                                                                            //
//     The original matrix A is replaced by L, D, and U with L stored in the  //
//     lower triangular part of A, D along the diagonal and U in the upper    //
//     triangular part of A. All three matrices L,D,U are band matrices.      //
//     The possible non-zero elements for row i of L are returned in the band //
//     for row i to the left of the center element, the diagonal element of   //
//     D in the center. Similarly, the possible non-zero elements for row i   //
//     of U are returned in the band for row i to the right of the center     //
//     element.  The diagonal elements of the matrices of L and U are 1's     //
//     and are not stored.                                                    //
//                                                                            //
//     Choleski's LDU decomposition is performed by evaluating, in order, the //
//     following of expressions for i = 0, ... ,n-1 :                         //
//       L[i][k]*D[k] = (A[i][k] - (L[i][0]*D[0]*L[k][0] + ... +              //
//                                            L[i][k-1]*D[k-1]*L[k][k-1]) )   //
//       D[i] = A[i][i] - ( L[i][0]*D[0]*L[i][0] + ... +                      //
//                                          L[k][k-1]*D[k-1]*L[i][k-1] ) )    //
//     and subsequently setting                                               //
//       U[k][i] = L[i][k], for i = k+1, ... , min(n-1, k+bandwidth)          //
//                                                                            //
//     After performing the LU decomposition for A, in order to solve the     //
//     equation Ax = B call Choleski_LDU_Solve_Band_band.                     //
//     Note that the inverse of a band matrix need not be a band matrix.      //
//                                                                            //
//  Arguments:                                                                //
//     double *A                                                              //
//        On input, the pointer to the first element of the band of the first //
//        row of the matrix A, note that A is declared as A[n][bandwidth] in  //
//        the calling routine.                                                //
//        On output, the matrix A is replaced by the unit lower, diagonal,    //
//        and unit upper triangular Choleski factorizations of A.             //
//     int     n                                                              //
//        The number of rows and/or columns of the matrix A.                  //
//     int     bandwidth                                                      //
//        The bandwidth of a band matrix A is defined as the number m such    //
//        that for all i,j if |i-j| > (m-1)/2, then A[i][j]=0.  A diagonal    //
//        matrix has a bandwidth of 1 while a tridiagonal matrix has a        //
//        bandwidth of 3.                                                     //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix A is not positive definite symmetric (within   //
//                  working accuracy).                                        //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N][N];                                                        //
//     int bandwidth;                                                         //
//                                                                            //
//     (your code to initialize the matrix A and the bandwidth)               //
//     err = Choleski_LDU_Decomposition_Band_band((double *) A, N, bandwidth);//
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else { printf(" The LDLt decomposition of A is \n");                   //
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //

#include <math.h>                                     // required for sqrt()

int Choleski_LDU_Decomposition_Band_band(double *A, int n, int bandwidth)
{
   int i, j, k;
   int center;
   int nz;
   double *p_i;                   // pointer to L[i][0]
   double *p_j;                   // pointer to L[j][0]
   double *p_k;                   // pointer to L[k][0]
   double ld;                     // dummy storage

   center = bandwidth >> 1;
   for (i = 1, p_i = A + bandwidth + center; i < n; p_i += bandwidth, i++) {
           
//            Calculate elements given by the product L[i][j]*D[j].   

      nz = ( ( i - center ) < 0) ? 0 : i - center;
      for (j = nz, p_j = A + bandwidth * nz + center; j < i; j++, p_j += bandwidth) 
         for (k = nz; k < j; k++)
            *(p_i + j - i) -= *(p_i + k - i) * *(p_j + k - j);

//            Calculate the diagonal element D[i] and L[i][j].
//            Store the transpose L[k][i];
      
      for (k = nz, p_k = A + nz * bandwidth + center; k < i; p_k += bandwidth, k++) {
            ld = *(p_i + k - i) / *p_k;
            *p_i -= *(p_i + k - i) * ld;
            *(p_i + k - i) = ld;
            *(p_k + i - k) = ld;
      }
      if ( *p_i <= 0.0 ) return -1;
   }
   return 0;
}


////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LDU_Solve_Band_band(double *LDU, double *B, double *x, int n,//
//                                                            int bandwidth ) //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to solve the linear equation       //
//     Ax = B.  This routine is called after the matrix A has been decomposed //
//     into the product of a unit lower triangular matrix L, a diagonal matrix//
//     D, and a unit upper triangular matrix U which is the transpose of L.   //
//     The matrix A is the product LDU.                                       //
//     The solution proceeds by solving the linear equation Ly = B for y,     //
//     then solving Dz = y for z and finally solving Ux = z for x.            //
//                                                                            //
//  Arguments:                                                                //
//     double *LU                                                             //
//        Pointer to the first element of the matrix whose elements form the  //
//        ower and upper triangular matrix factors of A.                      //
//     double *B                                                              //
//        Pointer to the column vector, (n x 1) matrix, B                     //
//     double *x                                                              //
//        Solution to the equation Ax = B.                                    //
//     int     n                                                              //
//        The number of rows and/or columns of the matrix A.                  //
//     int     bandwidth                                                      //
//        The bandwidth of a band matrix A is defined as the number m such    //
//        that for all i,j if |i-j| > (m-1)/2, then A[i][j]=0.  A diagonal    //
//        matrix has a bandwidth of 1 while a tridiagonal matrix has a        //
//        bandwidth of 3.                                                     //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix L is singular.                                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N][N], B[N], x[N];                                            //
//     int bandwidth;                                                         //
//                                                                            //
//     (your code to create matrix A, column vector B, and bandwidth)         //
//     err = Choleski_LDU_Decomposition_Band_band(&A[0][0], N, bandwidth);    //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else {                                                                 //
//        err = Choleski_LDU_Solve_Band_band(&A[0][0], B, x, n, bandwidth);   //
//        if (err < 0) printf(" Matrix A is singular\n");                     //
//        else printf(" The solution is \n");                                 //
//           ...                                                              //
//     }                                                                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LDU_Solve_Band_band(double *LDU, double B[], double x[], int n, 
                                                                int bandwidth)
{
   int i, k, nz ;
   int center;
   double *p_k;

//         Solve the linear equation Ly = B for y, where L is a lower
//         triangular matrix.
   
   center = bandwidth >> 1;
   for (k = 0, p_k = LDU; k < n; p_k += bandwidth, k++) {
      x[k] = B[k];
      nz = ( k > center ) ? 0 : center - k;
      for (i = nz; i < center; i++)  x[k] -= x[k-center+i] * *(p_k + i);
   }

//         Solve the linear equation Dz = y for z, where D is the diagonal
//         matrix.

   for (k = 0, p_k = LDU + center; k < n; k++, p_k += bandwidth) { 
      if ( *p_k == 0.0 ) return -1;
      x[k] /= *p_k;
   }

//         Solve the linear equation Ux = y, where y is the solution
//         obtained above of Ly = B and U is an upper triangular matrix.

   for (k = n-1, p_k = LDU + bandwidth*(n-1); k >= 0; k--, p_k -= bandwidth) {
      nz = ( (n - k) > center) ? bandwidth : center + (n - k);
      for (i = center + 1; i < nz; i++) x[k] -= x[k + i - center] * *(p_k + i);
   }
  
   return 0;
}
