////////////////////////////////////////////////////////////////////////////////
// File: choleski_ldu_lt.c                                                    //
// Contents:                                                                  //
//    Choleski_LDU_Decomposition_lt                                           //
//    Choleski_LDU_Solve_lt                                                   //
//    Choleski_LDU_Inverse_lt                                                 //
//                                                                            //
// Required Externally Defined Routines:                                      //
//    Unit_Lower_Triangular_Solve_lt                                          //
//    Unit_Lower_Triangular_Inverse_lt                                        //
////////////////////////////////////////////////////////////////////////////////

//                    Required Externally Defined Routines
void Unit_Lower_Triangular_Solve_lt(double *L, double B[], double x[], int n);
void Unit_Lower_Triangular_Inverse_lt(double *L, int n);

////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LDU_Decomposition_lt(double *A, int n)                       //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to decompose the n x n positive    //
//     definite symmetric matrix A into the product of a unit lower triangular//
//     matrix L and a diagonal matrix D such that A = LDL', where L' is the   //
//     transpose of L. A unit triangular matrix is a triangular matrix with   //
//     one's along the diagonal.                                              //
//                                                                            //
//     The matrices L and D replace the matrix A so that the original matrix  //
//     A is destroyed.  The matrix L replaces the lower triangular part of    //
//     A and D replaces the diagonal of A.                                    //
//                                                                            //
//     When the symmetric matrix A is stored as a lower triangular matrix,    //
//     then if j <= i then  A[i][j] = *(A + i*(i+1)/2 + j), and if i < j,     //
//     then since A[i][j] = A[j][i], A[i][j] = *(A + j*(j+1)/2 + i).          //
//                                                                            //
//     Choleski's LDU decomposition is performed by evaluating, in order, the //
//     following of expressions for i = 0, ... ,n-1 :                         //
//       L[i][k]*D[k] = (A[i][k] - (L[i][0]*D[0]*L[k][0] + ... +              //
//                                            L[i][k-1]*D[k-1]*L[k][k-1]) )   //
//       D[i] = A[i][i] - ( L[i][0]*D[0]*L[i][0] + ... +                      //
//                                          L[k][k-1]*D[k-1]*L[i][k-1] ) )    //
//     and subsequently setting                                               //
//       U[k][i] = L[i][k], for k = 1, ... , i-1.                             //
//                                                                            //
//     After performing the LDU decomposition for A,                          //
//     call Choleski_LDU_Solve_lt to solve the equation Ax = B or call        //
//     Choleski_LDU_Inverse_lt to calculate the inverse of the matrix A.      //
//                                                                            //
//  Arguments:                                                                //
//     double *A   On input, the pointer to the first element of the matrix   //
//                 A.  On output, the matrix A is replaced by the unit lower  //
//                 triangular and diagonal matrices of the Choleski LDL'      //
//                 factorization of A.                                        //
//     int     n   The number of rows and/or columns of the matrix A.         //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix A is not positive definite symmetric (within   //
//                  working accuracy).                                        //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N*(N+1)/2];                                                   //
//                                                                            //
//     (your code to initialize the matrix A)                                 //
//     err = Choleski_LDU_Decomposition_lt(A, N);                             //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else { printf(" The LDLt decomposition of A is \n");                   //
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LDU_Decomposition_lt(double *A, int n)
{
   int i, j, k;
   double *p_i;                   // pointer to L[i][0]
   double *p_j;                   // pointer to L[j][0]
   double *p_k;                   // pointer to L[k][0]
   double ld;                     // dummy storage

   for (i = 1, p_i = A + 1; i < n; i++, p_i += i) {
           
//            Calculate elements given by the product L[i][j]*D[j].   

      for (j = 0, p_j = A; j < i; j++, p_j += j) 
         for (k = 0; k < j; k++)
            *(p_i + j) -= *(p_i + k) * *(p_j + k);

//            Calculate the diagonal element D[i] and L[i][j].

      for (k = 0, p_k = A; k < i; k++, p_k += k) {
            ld = *(p_i + k) / *(p_k + k);
            *(p_i + i) -= *(p_i + k) * ld;
            *(p_i + k) = ld;
      }
      if ( *(p_i + i) <= 0.0 ) return -1;
   }
   return 0;
}


////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LDU_Solve_lt(double *LD, double *B, double *x,  int n)       //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to solve the linear equation       //
//     Ax = B.  This routine is called after the matrix A has been decomposed //
//     into the product of a unit lower triangular matrix L, a diagonal matrix//
//     D, and a unit upper triangular matrix U which is the transpose of L.   //
//     The matrix A is the product LDU.                                       //
//     The solution proceeds by solving the linear equation Ly = B for y,     //
//     then solving Dz = y for z and finally solving Ux = z for x.            //
//                                                                            //
//  Arguments:                                                                //
//     double *LD  Pointer to the first element of the matrix whose elements  //
//                 form the unit lower triangular matrix and the diagonal     //
//                 matrix factors of A.                                       //
//     double *B   Pointer to the column vector, (n x 1) matrix, B            //
//     double *x   Solution to the equation Ax = B.                           //
//     int     n   The number of rows or columns of the matrix LD.            //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix A is singular.                                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N*(N+1)/2], B[N], x[N];                                       //
//                                                                            //
//     (your code to create matrix A and column vector B)                     //
//     err = Choleski_LDU_Decomposition_lt(A, N);                             //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else {                                                                 //
//        err = Choleski_LDU_Solve_lt(A, B, x, n);                            //
//        if (err < 0) printf(" Matrix A is singular\n");                     //
//        else printf(" The solution is \n");                                 //
//           ...                                                              //
//     }                                                                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LDU_Solve_lt(double *LD, double B[], double x[], int n)
{
   int i, k;
   double *p_k, *p_i;

//         Solve the linear equation Ly = B for y, where L is a unit lower
//         triangular matrix.

   Unit_Lower_Triangular_Solve_lt(LD, B, x, n);

//         Solve the linear equation Dz = y for z, where D is the diagonal
//         matrix.

   for (k = 0, p_k = LD; k < n; k++, p_k += k) { 
      if ( *(p_k + k) == 0.0 ) return -1;
      x[k] /= *(p_k + k);
   }

//         Solve the linear equation L'x = y, where y is the solution
//         obtained above of Ly = B and L' is the transpose of L.

   for (k = n-2, p_k = LD + k * (k+1) / 2; k >= 0; p_k -= k, k--) 
      for (i = k + 1, p_i = LD + i*(i+1)/2; i < n; i++, p_i += i)
         x[k] -= x[i] * *(p_i + k);
    
   return 0;
}


////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LDU_Inverse_lt(double *LD,  int n)                           //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to find the inverse of the matrix  //
//     A.  This routine is called after the matrix A has been decomposed      //
//     into a product of a unit lower triangular matrix L, a diagonal matrix  //
//     D and a unit upper triangular matrix U which is the transpose of L.    //
//     The matrix A is the product of L, D, and U.  Upon completion, the      //
//     inverse of A is stored in LDU so that the matrix LDU is destroyed.     //
//                                                                            //
//  Arguments:                                                                //
//     double *LD  Pointer to the first element of the matrix whose elements  //
//                 form the unit lower triangular matrix, the diagonal matrix,//
//                 and the unit upper triangular matrix factors of A.         //
//     int     n   The number of rows or columns of the matrix LU.            //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix A is singular.                                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N*(N+1)/2], B[N], x[N];                                       //
//                                                                            //
//     (your code to create matrix A and column vector B)                     //
//     err = Choleski_LDU_Decomposition_lt(A, N);                             //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else {                                                                 //
//        err = Choleski_LDU_Inverse_lt(A, n);                                //
//        if (err < 0) printf(" Matrix A is singular\n");                     //
//        else printf(" The inverse is \n");                                  //
//           ...                                                              //
//     }                                                                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LDU_Inverse_lt(double *LD, int n)
{
   int i, j, k;
   double *p_i, *p_j, *p_k;

//         Invert the unit lower triangular matrix L.

   Unit_Lower_Triangular_Inverse_lt(LD, n);

//     Premultiply L inverse by the transpose of L inverse and D inverse.      
//         Invert the unit lower triangular matrix L.

   for (j = 0, p_j = LD; j < n; p_j += ++j) {
      for (i = j, p_i = p_j; i < n; p_i += ++i) {
         if (j == i) *(p_i + j) = 1.0 / *(p_i + i);
         else *(p_i + j) /= *(p_i + i);
         for (k = i + 1, p_k = p_i + i + 1; k < n; p_k += ++k)
            *(p_i + j) += *(p_k + i) * *(p_k + j) / *(p_k + k);
      }
   }
  
   return 0;
}
