////////////////////////////////////////////////////////////////////////////////
// File: choleski_ldu_ut.c                                                    //
// Contents:                                                                  //
//    Choleski_LDU_Decomposition_ut                                           //
//    Choleski_LDU_Solve_ut                                                   //
//    Choleski_LDU_Inverse_ut                                                 //
//                                                                            //
// Required Externally Defined Routines:                                      //
//    Unit_Upper_Triangular_Solve_ut                                          //
//    Unit_Upper_Triangular_Inverse_ut                                        //
////////////////////////////////////////////////////////////////////////////////

//                    Required Externally Defined Routines
void Unit_Upper_Triangular_Solve_ut(double *U, double B[], double x[], int n);
void Unit_Upper_Triangular_Inverse_ut(double *U, int n);

////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LDU_Decomposition_ut(double *A, int n)                       //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to decompose the n x n positive    //
//     definite symmetric matrix A into the product of a unit upper triangular//
//     matrix U and a diagonal matrix D such that A = U'DU, where U' is the   //
//     transpose of U. A unit triangular matrix is a triangular matrix with   //
//     one's along the diagonal.                                              //
//                                                                            //
//     The matrices U and D replace the matrix A so that the original matrix  //
//     A is destroyed.  The matrix U replaces the upper triangular part of    //
//     A and D replaces the diagonal of A.                                    //
//                                                                            //
//     When the symmetric matrix A is stored as an upper triangular matrix,   //
//     then if i <= j then  A[i][j] = *(A + i*(2n-i+1) + j-i), and if j < i,  //
//     then since A[i][j] = A[j][i], A[i][j] = *(A + j*(2n-j+1)/2 + i-j).     //
//                                                                            //
//     Choleski's LDU decomposition is performed by evaluating, in order, the //
//     following of expressions for k = 0, ... ,n-1 :                         //
//       U[k][i] = (A[k][i] - (U[0][i]*U[0][k] + ... + U[k-1][i]*U[k-1][k]))  //
//       D[k] = A[k][k] - ( U[0][k]*D[0]*U[0][k] + ... +                      //
//                                          U[k-1][k]*D[k-1]*U[k-1][k] ) )    //
//       for i = k+1, ... , n-1.                                              //
//                                                                            //
//     After performing the LDU decomposition for A,                          //
//     call Choleski_LDU_Solve_ut to solve the equation Ax = B or call        //
//     Choleski_LDU_Inverse_ut to calculate the inverse of the matrix A.      //
//                                                                            //
//  Arguments:                                                                //
//     double *A   On input, the pointer to the first element of the matrix   //
//                 A.  On output, the matrix A is replaced by the unit upper  //
//                 triangular and diagonal matrices of the Choleski U'DU      //
//                 factorization of A.                                        //
//     int     n   The number of rows and/or columns of the matrix A.         //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix A is not positive definite symmetric (within   //
//                  working accuracy).                                        //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N*(N+1)/2];                                                   //
//                                                                            //
//     (your code to initialize the matrix A)                                 //
//     err = Choleski_LDU_Decomposition_ut(A, N);                             //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else { printf(" The UtDU decomposition of A is \n");                   //
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LDU_Decomposition_ut(double *A, int n)
{
   int i, j, k, m;
   double *p_Uj;                 // pointer to U[j][j]
   double *p_Ui;                 // pointer to U[i][i]
   double *p_Uk;                 // pointer to U[k][k]
   double reciprocal;
   
   if ( *A <= 0.0 ) return -1;       // Not positive definite

   for (i = 1, p_Ui =  A + n; i < n; p_Ui += (n - i++)) {

//            Divide the elements in column i from row 0 to row i - 1 by
//            the diagonal element in row i.
     
      for (k = 0, p_Uk = A; k < i; p_Uk += (n - k++))
         *(p_Uk+i-k) /= *(p_Uk); 

//            For columns i+1 to n-1, row i, calculate U[i][j]*D[i]

      for (j = i+1, p_Uj = p_Ui + 1; j < n; j++, p_Uj++) 
         for (k = 0, p_Uk = A; k < i; p_Uk += (n - k++))
            *p_Uj -= *(p_Uk + i - k) * *(p_Uk + j - k);    

//            Calculate the diagonal element for row i.

      for (k = 0, p_Uk = A; k < i; p_Uk += (n - k++)) 
         *p_Ui -= *(p_Uk + i - k) * *(p_Uk + i - k) * *p_Uk;
      
//            If diagonal element is not positive, return the error code,
//            the matrix is not positive definite symmetric.

      if ( *p_Ui <= 0.0 ) return -1;

   }
   return 0;
}


////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LDU_Solve_ut(double *DU, double *B, double *x,  int n)       //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to solve the linear equation       //
//     Ax = B.  This routine is called after the matrix A has been decomposed //
//     into the product of the transpose of a unit upper triangular matrix U, //
//     a diagonal matrix D, and a unit upper triangular matrix U.             //
//     The matrix A is the product U'DU.                                      //
//     The solution proceeds by solving the linear equation U'y = B for y,    //
//     then solving Dz = y for z and finally solving Ux = z for x.            //
//                                                                            //
//  Arguments:                                                                //
//     double *DU  Pointer to the first element of the matrix whose elements  //
//                 form the unit lower triangular matrix and the diagonal     //
//                 matrix factors of A.                                       //
//     double *B   Pointer to the column vector, (n x 1) matrix, B            //
//     double *x   Solution to the equation Ax = B.                           //
//     int     n   The number of rows or columns of the matrix DU.            //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix A is singular.                                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N*(N+1)/2], B[N], x[N];                                       //
//                                                                            //
//     (your code to create matrix A and column vector B)                     //
//     err = Choleski_LDU_Decomposition_ut(A, N);                             //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else {                                                                 //
//        err = Choleski_LDU_Solve_ut(A, B, x, n);                            //
//        if (err < 0) printf(" Matrix A is singular\n");                     //
//        else printf(" The solution is \n");                                 //
//           ...                                                              //
//     }                                                                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LDU_Solve_ut(double *DU, double B[], double x[], int n)
{
   int i, k;
   double *p_k, *p_i;

//         Solve the linear equation U'y = B for y, where U' is the transpose
//         of the unit upper triangular matrix.

   for (k = 0; k < n; k++) {
      x[k] = B[k];
      for (i = 0, p_i = DU;  i < k; p_i += (n - i++)) {
         x[k] -= x[i] * *(p_i + k - i);
      }
   }

//         Solve the linear equation Dz = y for z, where D is the diagonal
//         matrix.

   for (k = 0, p_k = DU; k < n; p_k += (n - k++) ) { 
      if ( *p_k == 0.0 ) return -1;
      x[k] /= *p_k;
   }

//         Solve the linear equation Ux = z, where z is the solution
//         obtained above of Dz = y.

   Unit_Upper_Triangular_Solve_ut(DU, x, x, n);
    
   return 0;
}


////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LDU_Inverse_ut(double *DU,  int n)                           //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to find the inverse of the matrix  //
//     A.  This routine is called after the matrix A has been decomposed      //
//     into a product of the transpose of a unit upper triangular matrix U,   //
//     a diagonal matrix D and the unit upper triangular matrix U.            //
//     The matrix A is the product of U', D, and U.  Upon completion, the     //
//     inverse of A is stored in DU so that the matrix DU is destroyed.       //
//                                                                            //
//  Arguments:                                                                //
//     double *DU  On input, pointer to the first element of the matrix whose //
//                 elements form the diagonal and the upper triangular factors//
//                 of A.  The diagonal and upper triangular matrices are      //
//                 stored in upper triangular form.  On output, the matrix DU //
//                 is replaced by the inverse of the matrix A = U'DU, where   //
//                 the inverse is stored in upper triangular form.            //
//     int     n   The number of rows and/or columns of the matrix L.         //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix A is singular.                                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N*(N+1)/2], B[N], x[N];                                       //
//                                                                            //
//     (your code to create matrix A and column vector B)                     //
//     err = Choleski_LDU_Decomposition_ut(A, N);                             //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else {                                                                 //
//        err = Choleski_LDU_Inverse_ut(A, n);                                //
//        if (err < 0) printf(" Matrix A is singular\n");                     //
//        else printf(" The inverse is \n");                                  //
//           ...                                                              //
//     }                                                                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LDU_Inverse_ut(double *DU, int n)
{
   int i, j, k;
   double sum;
   double *p_i, *p_j, *p_k;

//         Invert the unit upper triangular matrix U.
   
   Unit_Upper_Triangular_Inverse_ut(DU, n);

//         Invert the diagonal matrix D.

   for (i = 0, p_i = DU; i < n; p_i += (n  - i++) ) 
      if ( *p_i <= 0.0 ) return -1;
      else *p_i = 1.0 / *p_i;
   
//         Form the product U inverse, D inverse, U transpose inverse.

   for (i = 0, p_i = DU; i < n; p_i += (n - i++) ) {
      for ( k = i + 1, p_k = p_i + n - i; k < n; p_k += (n - k++) ) 
         *p_i += * p_k * *(p_i + k - i) * *(p_i + k - i);
      for (j = i + 1, p_j = p_i + n - i; j < n; p_j += (n - j++) ) {
         *(p_i + j - i) *= *p_j;
         for (k = j + 1,  p_k = p_j + n - j; k < n; p_k += (n - k++) )
            *(p_i + j - i) += *(p_i + k - i) * *(p_j + k - j) * *p_k;
      }
   }
  
   return 0;
}
