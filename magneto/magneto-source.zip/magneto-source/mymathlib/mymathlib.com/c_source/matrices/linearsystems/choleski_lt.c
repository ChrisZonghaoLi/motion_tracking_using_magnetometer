////////////////////////////////////////////////////////////////////////////////
// File: choleski_lt.c                                                        //
// Contents:                                                                  //
//    Choleski_LU_Decomposition_lt                                            //
//    Choleski_LU_Solve_lt                                                    //
//    Choleski_LU_Inverse_lt                                                  //
//                                                                            //
// Required Externally Defined Routines:                                      //
//    Lower_Triangular_Solve_lt                                               //
//    Lower_Triangular_Inverse_lt                                             //
////////////////////////////////////////////////////////////////////////////////

#include <math.h>                                       // required for sqrt()

//                    Required Externally Defined Routines
int Lower_Triangular_Solve_lt(double *L, double B[], double x[], int n);
int Lower_Triangular_Inverse_lt(double *L, int n);

////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LU_Decomposition_lt(double *A, int n)                        //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to decompose the n x n positive    //
//     definite symmetric matrix A into the product of a lower triangular     //
//     matrix L such that A = LL' where L' is the transpose of L.             //
//     The matrix L replaces the matrix A so that the original matrix A is    //
//     destroyed.                                                             //
//                                                                            //
//     The input matrix A is stored in lower triangular form, i.e. the        //
//     elements of A are stored sequentially starting with the first row which//
//     contains one element, followed by the second row which consists of two //
//     elements, and so on until the last row which consists of n elements.   //
//                                                                            //
//     When the symmetric matrix A is stored as a lower triangular matrix,    //
//     then if j <= i then  A[i][j] = *(A + i*(i+1)/2 + j), and if i < j,     //
//     then since A[i][j] = A[j][i], A[i][j] = *(A + j*(j+1)/2 + i).          //
//                                                                            //
//     Choleski's decomposition is performed by evaluating, in order, the     //
//     following pair of expressions for k = 0, ... ,n-1 :                    //
//       L[k][k] = sqrt( A[k][k] - ( L[k][0] ^ 2 + ... + L[k][k-1] ^ 2 ) )    //
//       L[i][k] = (A[i][k] - (L[i][0]*L[k][0] + ... + L[i][k-1]*L[k][k-1]))  //
//                          / L[k][k]                                         //
//       for i = k+1, ... , n-1.                                              //
//                                                                            //
//     After performing the LU decomposition for A, call Choleski_LU_Solve_lt //
//     to solve the equation Ax = B or call Choleski_LU_Inverse_lt to calcu-  //
//     late the inverse of A.                                                 //
//                                                                            //
//  Arguments:                                                                //
//     double *A   On input, the pointer to the first element of the matrix   //
//                 A.  On output, the matrix A is replaced by the lower       //
//                 triangular Choleski factorization L of A, where A = LL'.   //
//     int     n   The number of rows and/or columns of the matrix A.         //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix A is not positive definite symmetric (within   //
//                  working accuracy).                                        //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[(N*(N+1))/2];                                                 //
//                                                                            //
//     (your code to initialize the matrix A)                                 //
//     err = Choleski_LU_Decomposition_lt(A, N);                              //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else { printf(" The LLt decomposition of A is \n");                    //
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LU_Decomposition_lt(double *A, int n)
{
   int i, k, p;
   double *p_Lk0;                   // pointer to L[k][0]
   double *p_Lkp;                   // pointer to L[k][p]  
   double *p_Lkk;                   // pointer to diagonal element on row k.
   double *p_Li0;                   // pointer to L[i][0]
   double reciprocal;

   for (k = 0, p_Lk0 = A; k < n; k++, p_Lk0 += k) {
           
//            Update pointer to row k diagonal element.   

      p_Lkk = p_Lk0 + k;

//            Calculate the difference of the diagonal element in row k
//            from the sum of squares of elements row k from column 0 to 
//            column k-1.

      for (p = 0, p_Lkp = p_Lk0; p < k; p_Lkp += 1,  p++)
         *p_Lkk -= *p_Lkp * *p_Lkp;

//            If diagonal element is not positive, return the error code,
//            the matrix is not positive definite symmetric.

      if ( *p_Lkk <= 0.0 ) return -1;

//            Otherwise take the square root of the diagonal element.

      *p_Lkk = sqrt( *p_Lkk );
      reciprocal = 1.0 / *p_Lkk;

//            For rows i = k+1 to n-1, column k, calculate the difference
//            between the i,k th element and the inner product of the first
//            k-1 columns of row i and row k, then divide the difference by
//            the diagonal element in row k.

      p_Li0 = p_Lkk + 1;
      for (i = k + 1; i < n; p_Li0 += ++i) {
         for (p = 0; p < k; p++)
            *(p_Li0 + k) -= *(p_Li0 + p) * *(p_Lk0 + p);
         *(p_Li0 + k) *= reciprocal;
      }  
   }
   return 0;
}


////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LU_Solve_lt(double *L, double *B, double *x,  int n)         //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to solve the linear equation       //
//     Ax = B.  This routine is called after the matrix A has been decomposed //
//     into a product of a lower triangular matrix L and its transpose.       //
//     The solution proceeds by solving the linear equation Ly = B for y and  //
//     subsequently solving the linear equation L'x = y for x, where L' is    //
//     the transpose of L.                                                    //
//                                                                            //
//  Arguments:                                                                //
//     double *L   Pointer to the first element of the matrix whose elements  //
//                 form the lower triangular matrix factor of A.  The matrix  //
//                 L is stored in lower triangular form.                      //
//     double *B   Pointer to the column vector, (n x 1) matrix, B            //
//     double *x   Solution to the equation Ax = B.                           //
//     int     n   The number of rows and/or columns of the matrix L.         //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix L is singular.                                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[(N*(N+1))/2], B[N], x[N];                                     //
//                                                                            //
//     (your code to create matrix A and column vector B)                     //
//     err = Choleski_LU_Decomposition_lt(A, N);                              //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else {                                                                 //
//        err = Choleski_LU_Solve_lt(A, B, x, n);                             //
//        if (err < 0) printf(" Matrix A is singular\n");                     //
//        else printf(" The solution is \n");                                 //
//           ...                                                              //
//     }                                                                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LU_Solve_lt(double *L, double B[], double x[], int n)
{
   int i, k;
   double *p_k, *p_i;

//         Solve the linear equation Ly = B for y, where L is a lower
//         triangular matrix.
   
   if ( Lower_Triangular_Solve_lt(L, B, x, n) < 0 ) return -1;

//         Solve the linear equation L'x = y, where y is the solution
//         obtained above of Ly = B.

   for (k = n-1, p_k = L + (k * (k+1)) / 2; k >= 0; p_k -= k--) {
      for (i = k + 1, p_i = L + i*(i+1)/2; i < n; i++, p_i += i)
         x[k] -= x[i] * *(p_i + k);
      x[k] /= *(p_k + k);
   }
  
   return 0;
}


////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LU_Inverse_lt(double *L,  int n)                             //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to find the inverse of the matrix  //
//     A = LL'.  This routine is called after the matrix A has been decomposed//
//     into a product of a lower triangular matrix L and its transpose.       //
//     Upon completion, the inverse is A is returned in L stored in lower     //
//     triangular form so that the matrix L is destroyed.                     //
//                                                                            //
//  Arguments:                                                                //
//     double *L   On input, pointer to the first element of the matrix whose //
//                 elements form the lower triangular matrix factor of A.     //
//                 The matrix L is stored in lower triangular form.  On       //
//                 output, the matrix L is replaced by the inverse of the     //
//                 matrix A equal to LL', where the inverse is stored in      //
//                 lower triangular form.                                     //
//     int     n   The number of rows and/or columns of the matrix L.         //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix L is singular.                                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[(N*(N+1))/2], B[N], x[N];                                     //
//                                                                            //
//     (your code to create matrix A and column vector B)                     //
//     err = Choleski_LU_Decomposition_lt(A, N);                              //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else {                                                                 //
//        err = Choleski_LU_Inverse_lt(A, n);                                 //
//        if (err < 0) printf(" Matrix A is singular\n");                     //
//        else printf(" The inverse is \n");                                  //
//           ...                                                              //
//     }                                                                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LU_Inverse_lt(double *L, int n)
{
   int i, j, k;
   double *p_i, *p_j, *p_k;
   double sum;

   if ( Lower_Triangular_Inverse_lt(L, n) < 0 ) return -1;

//         Premultiply L inverse by the transpose of L inverse.      

   for (i = 0, p_i = L; i < n; p_i += ++i) {
      for (j = 0, p_j = L; j <= i; p_j += ++j) {
         sum = 0.0;
         for (k = i, p_k = p_i; k < n; p_k += ++k)
            sum += *(p_k + i) * *(p_k + j);
         *(p_i + j) = sum;
      }
   }
  
   return 0;
}
