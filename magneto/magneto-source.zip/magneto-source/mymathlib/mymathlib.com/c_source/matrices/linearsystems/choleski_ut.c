////////////////////////////////////////////////////////////////////////////////
// File: choleski_ut.c                                                        //
// Contents:                                                                  //
//    Choleski_LU_Decomposition_ut                                            //
//    Choleski_LU_Solve_ut                                                    //
//    Choleski_LU_Inverse_ut                                                  //
//                                                                            //
// Required Externally Defined Routines:                                      //
//    Upper_Triangular_Solve_ut                                               //
//    Upper_Triangular_Inverse_ut                                             //
////////////////////////////////////////////////////////////////////////////////

#include <math.h>                                       // required for sqrt()

//                    Required Externally Defined Routines
int Upper_Triangular_Solve_ut(double *U, double B[], double x[], int n);
int Upper_Triangular_Inverse_ut(double *U, int n);

////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LU_Decomposition_ut(double *A, int n)                        //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to decompose the n x n positive    //
//     definite symmetric matrix A into the product of an upper triangular    //
//     matrix U such that A = U'U where U' is the transpose of U.             //
//     The matrix U replaces the matrix A so that the original matrix A is    //
//     destroyed.                                                             //
//                                                                            //
//     The matrix A is stored in upper triangular form, i.e. the elements of  //
//     are stored sequentially starting with the first row which contains n   //
//     elements, followed by the second row which consists of n-1 elements,   //
//     and so on until the last row which consists of 1 element.              //
//                                                                            //
//     When the symmetric matrix A is stored as an upper triangular matrix,   //
//     then if i <= j then  A[i][j] = *(A + i*(2n-i+1) + j-i), and if j < i,  //
//     then since A[i][j] = A[j][i], A[i][j] = *(A + j*(2n-j+1)/2 + i-j).     //
//                                                                            //
//     The Choleski method is given by evaluating, in order, the following    //
//     pair of expressions for k = 0, ... ,n-1 :                              //
//       U[k][k] = sqrt( A[k][k] - ( U[0][k] ^ 2 + ... + U[k-1][k] ^ 2 ) )    //
//       U[k][i] = (A[k][i] - (U[0][i]*U[0][k] + ... + U[k-1][i]*U[k-1][k]))  //
//                          / U[k][k]                                         //
//       for i = k+1, ... , n-1.                                              //
//                                                                            //
//     After performing the LU decomposition for A, call Choleski_LU_Solve_ut //
//     to solve the equation Ax = B or call Choleski_LU_Inverse_ut to calcu-  //
//     late the inverse of A.                                                 //
//                                                                            //
//  Arguments:                                                                //
//     double *A   On input, the pointer to the first element of the matrix   //
//                 A[n][n].  On output, the matrix A is replaced by the upper //
//                 triangular Choleski factorization U of A, where A = U'U.   //
//     int     n   The number of rows and/or columns of the matrix A.         //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix A is not positive definite symmetric (within   //
//                  working accuracy).                                        //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[(N*(N+1))/2];                                                 //
//                                                                            //
//     (your code to initialize the matrix A)                                 //
//     err = Choleski_LU_Decomposition_ut(A, N);                              //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else { printf(" The UtU decomposition of A is \n");                    //
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LU_Decomposition_ut(double *A, int n)
{
   int i, j, k, m;
   double *p_Ujj;                   // pointer to U[j][j]
   double *p_Uii;                   // pointer to U[i][i]
   double *p_Ukk;                   // pointer to U[k][k]  
   double reciprocal;

   for (j = 0, p_Ujj = A; j < n; p_Ujj += (n - j++))  {
           
//            For rows i = 0 to j-1, column j, calculate the difference
//            between the i,k th element and the inner product of the first
//            k-1 columns of row i and row k, and then divide by the
//            diagonal element.

      for (i = 0, p_Uii = A; i < j; p_Uii += (n - i++)) {
         for (k = 0, p_Ukk = A; k < i; p_Ukk += (n - k++) ) {
            *(p_Uii + j - i) -= *(p_Ukk + i - k) * *(p_Ukk + j - k);
         }
         *(p_Uii + j - i) /= *p_Uii;
      }
 
//            Calculate the difference of the diagonal element in column j
//            from the sum of squares of elements in column j from row 0 to 
//            row j-1.

      for (k = 0, p_Ukk = A; k < j; p_Ukk += (n - k++)) {
         *p_Ujj -= *(p_Ukk + j - k) * *(p_Ukk + j - k);
      }

//            If diagonal element is not positive, return the error code,
//            the matrix is not positive definite symmetric.

      if ( *p_Ujj <= 0.0 ) return -1;

//            Otherwise take the square root of the diagonal element.

      *p_Ujj = sqrt( *p_Ujj );
   }

   return 0;
}


////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LU_Solve_ut(double *U, double *B, double *x,  int n)         //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to solve the linear equation       //
//     Ax = B.  This routine is called after the matrix A has been decomposed //
//     into a product of an upper triangular matrix U premultiplied by its    //
//     transpose.                                                             //
//     The solution proceeds by solving the linear equation U'y = B for y     //
//     where U' is the transpose of U and subsequently solving the linear     //
//     equation Ux = y for x.                                                 //
//                                                                            //
//  Arguments:                                                                //
//     double *U   Pointer to the first element of the matrix whose elements  //
//                 form the upper triangular matrix factor of A.  The matrix  //
//                 U is stored in upper triangular form.                      //
//     double *B   Pointer to the column vector, (n x 1) matrix, B            //
//     double *x   Solution to the equation Ax = B.                           //
//     int     n   The number of rows and/or columns of the matrix L.         //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix U is singular.                                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[(N*(N+1))/2], B[N], x[N];                                     //
//                                                                            //
//     (your code to create matrix A and column vector B)                     //
//     err = Choleski_LU_Decomposition_ut(A, N);                              //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else {                                                                 //
//        err = Choleski_LU_Solve_ut(A, B, x, n);                             //
//        if (err < 0) printf(" Matrix A is singular\n");                     //
//        else printf(" The solution is \n");                                 //
//           ...                                                              //
//     }                                                                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LU_Solve_ut(double *U, double B[], double x[], int n)
{
   int i, k;
   double *p_k, *p_i;

//         Solve the linear equation U'y = B for y, where U' is the transpose
//         of the unit upper triangular matrix.
   
   for (k = 0; k < n; k++) {
      x[k] = B[k];
      for (i = 0, p_i = U;  i < k; p_i += (n - i++)) {
         x[k] -= x[i] * *(p_i + k - i);
      }
      if (*p_i == 0.0) return -1;
      x[k] /= *p_i;
   }

//         Solve the linear equation Ux = y, where y is the solution
//         obtained above of Ly = B and U is an upper triangular matrix.

   return Upper_Triangular_Solve_ut(U, x, x, n);
}


////////////////////////////////////////////////////////////////////////////////
//  int Choleski_LU_Inverse_ut(double *U,  int n)                             //
//                                                                            //
//  Description:                                                              //
//     This routine uses Choleski's method to find the inverse of the matrix  //
//     A = U'U.  This routine is called after the matrix A has been decomposed//
//     into a product U'U where U is an upper triangular matrix.              //
//     Upon completion, the inverse is A is returned in U stored in upper     //
//     triangular form so that the matrix U is destroyed.                     //
//                                                                            //
//  Arguments:                                                                //
//     double *U   On input, pointer to the first element of the matrix whose //
//                 elements form the upper triangular matrix factor of A.     //
//                 The matrix U is stored in upper triangular form.  On       //
//                 output, the matrix U is replaced by the inverse of the     //
//                 matrix A equal to U'U, where the inverse is stored in      //
//                 upper triangular form.                                     //
//     int     n   The number of rows and/or columns of the matrix L.         //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix U is singular.                                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[(N*(N+1))/2], B[N], x[N];                                     //
//                                                                            //
//     (your code to create matrix A and column vector B)                     //
//     err = Choleski_LU_Decomposition_ut(A, N);                              //
//     if (err < 0) printf(" Matrix A is singular\n");                        //
//     else {                                                                 //
//        err = Choleski_LU_Inverse_ut(A, n);                                 //
//        if (err < 0) printf(" Matrix A is singular\n");                     //
//        else printf(" The inverse is \n");                                  //
//           ...                                                              //
//     }                                                                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Choleski_LU_Inverse_ut(double *U, int n)
{
   int i, j, k;
   double *p_i, *p_j, *p_k;
   double sum;

   if ( Upper_Triangular_Inverse_ut(U, n) < 0 ) return -1;
  
//         Postmultiply U inverse by the transpose of U inverse.      

   for (i = 0, p_i = U; i < n; p_i += ( n - i++ ) ) 
      for (j = i, p_j = p_i; j < n; p_j += ( n - j++) ) {
         sum = 0.0;
         for (k = j; k < n; k++ )
            sum += *(p_j + (k - j)) * *(p_i + (k - i));
         *(p_i + (j - i)) = sum;
      }
  
   return 0;
}
