////////////////////////////////////////////////////////////////////////////////
// File: gauss_seidel.c                                                       //
// Contents:                                                                  //
//    Gauss_Seidel_Method                                                     //
////////////////////////////////////////////////////////////////////////////////
//  int Gauss_Seidel_Method(double (*iterate)(double*,int), double x[],       //
//                       double x0[], int n, double tolerance, int max_tries) //
//                                                                            //
//     Solve the linear system of equations Ax=B where A is an n x n matrix   //
//     B is an n x 1 matrix (or n dimensional column vector) for the          //
//     n-dimensional column vector x.                                         //
//                                                                            //
//     The Gauss-Seidel's method is an iterative method used for large sparse //
//     matrices in which the diagonal elements are not zero.  Gauss-Seidel's  //
//     method converges for positive definite and diagonally dominant         //
//     matrices.                                                              //
//                                                                            //
//     This iterative technique is implemented for use with large sparse      //
//     matrices in which it is assumed that the matrix itself may not be      //
//     stored in RAM memory.  The user needs to write a function which        //
//     evaluates {B[i] - (A[i][*]-D[i][*])x}(1/D[i][i]), where D is the       //
//     diagonal matrix of A.                                                  //
//                                                                            //
//  Arguments:                                                                //
//     double (*iterate)(double *, int)                                       //
//        Pointer the user supplied function to evaluate the i-th row of      //
//        [B-(A-D)x](1/D).  I.e. (*iterate)(x,i) returns                      //
//        {b[i]-(a[i][0]*x[0]+...+a[i][n-1]*x[n-1]-a[i][i]*x[i])} / a[i][i].  //
//     double x[]                                                             //
//        Solution of the linear system Ax = B.                               //
//     double x0[]                                                            //
//        On input, the initial estimate of the solution.  The initial        //
//        estimate can be zero.  During execution of the algorithm, during    //
//        the i-th iteration this array is set to estimate of the (i-1)st     //
//        iteration.                                                          //
//     int n                                                                  //
//        The dimension of x[] and x0[].                                      //
//     double tolerance                                                       //
//        When the max norm of the difference of two successive estimates of  //
//        the solution is less than this number, tolerance, the iteration     //
//        halts and the final estimate is returned in the array x[]. I.e. if  //
//        x[] and y[] are two successive estimates of the solution of Ax=B,   //
//        the iteration terminates if max{x[i]-y[i]: 0 <= i < n} < tolerance. //
//     int max_tries                                                          //
//        User supplied parameter which sets the maximum number of iterations //
//        to try to converge to the solution.                                 //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The algorithm did not converge within max_tries tries.    //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double x[N], x0[N];                                                    //
//     double tolerance = 1.e-6;                                              //
//     int max_tries = 40;                                                    //
//     extern double eval(double*, int);    // user supplied function.        //
//                                                                            //
//     (your code to initialize x0)                                           //
//     err = Gauss_Seidel_Method(eval, x, x0, N, tolerance, max_tries);       //
//     if (err < 0) printf(" The procedure failed to converge\n");            //
//     else { printf(" The Solution is: \n"); ...                             //
////////////////////////////////////////////////////////////////////////////////
#include <math.h>                               // required for fabs()
#include <string.h>                             // required for memcpy()

int Gauss_Seidel_Method(double (*iterate)(double*,int), double x[], double x0[],
                                        int n, double tolerance, int max_tries)
{
   int i, try;
   int length = sizeof(double) * n;
   double max, dum;

                   // Start the Gauss-Seidel Method

   memcpy( x, x0, length);
   for (try = 0; try < max_tries; try ++) {
      for (i = 0; i < n; i++)  x[i] = (*iterate)(x,i);                      
      max = fabs(x[0] - x0[0]);
      for ( i = 1; i < n; i++) 
         if ( max < (dum = fabs(x[i] - x0[i])) ) max = dum;   
      if (max < tolerance) break;
      memcpy( x0, x, length);
   }
   if (try >= max_tries) return -1; 
   return 0;
}
