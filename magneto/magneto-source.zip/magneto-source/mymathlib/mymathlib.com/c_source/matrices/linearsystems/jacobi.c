////////////////////////////////////////////////////////////////////////////////
// File: jacobi.c                                                             //
// Contents:                                                                  //
//    Jacobi_Method                                                           //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// int Jacobi_Method(void (*iterate)(double*,double*), double x[],            //
//                      double x0[], int n, double tolerance, int max_tries)  //
//                                                                            //
//  Description:                                                              //
//     Solve the linear system of equations Ax=B where A is an n x n matrix   //
//     B is an n x 1 matrix (or n dimensional column vector) for the          //
//     n-dimensional column vector x.                                         //
//                                                                            //
//     Jacobi's method is an iterative method used for large sparse matrices  //
//     in which the diagonal elements are not zero.  Jacobi's method converges//
//     for positive definite and diagonally dominant matrices.                //
//                                                                            //
//     This iterative technique is implemented for use with large sparse      //
//     matrices in which it is assumed that the matrix itself may not be      //
//     stored in RAM memory.  The user needs to write a function which        //
//     evaluates [B - (A-D)x](1/D), where D is the diagonal matrix of A and   //
//     (1/D) is                                                               //
//     the inverse of D.                                                      //
//                                                                            //
//  Arguments:                                                                //
//     void (*iterate)(double *, double *)                                    //
//        Pointer the user supplied function to evaluate [B-(A-D)x](1/D).     //
//        I.e. (*iterate)(x,x0) sets x = [B - (A-D) * x0](1/D).  The user     //
//        supplied function (*iterate)(x,x0) should not change x0.            //
//     double x[]                                                             //
//        Solution of the linear system Ax = B.                               //
//     double x0[]                                                            //
//        On input, the initial estimate of the solution.  The initial        //
//        estimate can be zero.  During execution of the algorithm, this      //
//        array is toggled with the array x[] to be either argument of the    //
//        the user supplied function (*iterate)(x,x0).                        //
//     int n                                                                  //
//        The dimension of x[] and x0[].                                      //
//     double tolerance                                                       //
//        When the max norm of the difference of two successive estimates of  //
//        the solution is less than this number, tolerance, the iteration     //
//        halts and the final estimate is returned in the array x[]. I.e. if  //
//        x[] and y[] are two successive estimates of the solution of Ax=B,   //
//        the iteration terminates if max{x[i]-y[i]: 0 <= i < n} < tolerance. //
//     int max_tries                                                          //
//        User supplied parameter which sets the maximum number of iterations //
//        to try to converge to the solution.                                 //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The algorithm did not converge within max_tries tries.    //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double x[N], x0[N];                                                    //
//     double tolerance = 1.e-6;                                              //
//     int max_tries = 40;                                                    //
//     extern void eval(double*, double*);  // user supplied function.        //
//                                                                            //
//     (your code to initialize x0)                                           //
//     err = Jacobi_Method(eval, x, x0, N, tolerance, max_tries);             //
//     if (err < 0) printf(" The procedure failed to converge.\n");           //
//     else { printf(" The Solution is: \n"); ...                             //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
#include <math.h>                                // required for fabs()

int Jacobi_Method(void (*iterate)(double*,double*), double x[], double x0[],
                                        int n, double tolerance, int max_tries)
{
   int i, try;
   double max, dum;
   double *px, *px0, *ptoggle;

                   // Start the Jacobi Method

   px = x;
   px0 = x0;
   for (try = 0; try < max_tries; try ++) {
      (*iterate)(px,px0);                      
      max = fabs(x[0] - x0[0]);
      for ( i = 1; i < n; i++) 
         if ( max < (dum = fabs(x[i] - x0[i])) ) max = dum;   
      if (max < tolerance) break;
      ptoggle = px;
      px = px0;
      px0 = ptoggle;
   }
   if (try >= max_tries) return -2;
   if (px != x) 
      for (i = 0; i < n; i++) x[i] = x0[i];
 
   return 0;
}
