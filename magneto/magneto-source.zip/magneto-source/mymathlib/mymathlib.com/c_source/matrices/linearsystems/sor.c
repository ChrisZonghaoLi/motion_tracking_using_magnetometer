////////////////////////////////////////////////////////////////////////////////
// File: sor.c                                                                //
// Contents:                                                                  //
//    Successive_Overrelaxation                                               //
////////////////////////////////////////////////////////////////////////////////
// int Successive_Overrelaxation(double (*residual)(double*,int), double x[], //
//        double x0[], int n, double omega,  double tolerance, int max_tries) //
//                                                                            //
//     Solve the linear system of equations Ax=B where A is an n x n matrix   //
//     B is an n x 1 matrix (or n dimensional column vector) for the          //
//     n-dimensional column vector x.                                         //
//                                                                            //
//     The succesive overrelaxation method is an iterative method generally   //
//     used for large sparse matrices in which the diagonal elements are not  //
//     zero.                                                                  //
//                                                                            //
//     This iterative technique is implemented for use with large sparse      //
//      matrices in which it is assumed that the matrix itself may not be     //
//      stored in RAM memory.  The user needs to write a function which       //
//      evaluates the i-th residual                                           //
//                   {B[i] - A[i][*] x[*]}(1/A[i][i])}.                       //
//     The next estimate of x[i] is the the sum of the old estimate of x[i]   //
//     plus omega times the residual returned above.  The SOR method only     //
//     converges for omega being strictly between 0 and 2.  If omega = 1,     //
//     the method is equivalent to the Gauss-Seidel method.                   //
//                                                                            //
//  Arguments:                                                                //
//     double (*residual)(double *, int)                                      //
//        Pointer the user supplied function to evaluate the i-th row of      //
//        [B-Ax](1/D).  I.e. (*residual)(x,i) returns                         //
//        {b[i]-(a[i][0]*x[0]+...+a[i][n-1]*x[n-1])} / a[i][i].               //
//     double x[]                                                             //
//        Solution of the linear system Ax = B.                               //
//     double x0[]                                                            //
//        On input, the initial estimate of the solution.  The initial        //
//        estimate can be zero.  During execution of the algorithm, during    //
//        the i-th iteration this array is set to estimate of the (i-1)st     //
//        iteration.                                                          //
//     int n                                                                  //
//        The dimension of x[] and x0[].                                      //
//     double omega                                                           //
//        The relaxation parameter, 0 < omega < 2. Note that for omega = 1,   //
//        this method is equivalent to the Gauss-Seidel procedure.            //
//     double tolerance                                                       //
//        When the max norm of the difference of two successive estimates of  //
//        the solution is less than this number, tolerance, the iteration     //
//        halts and the final estimate is returned in the array x[]. I.e. if  //
//        x[] and y[] are two successive estimates of the solution of Ax=B,   //
//        the iteration terminates if max{x[i]-y[i]: 0 <= i < n} < tolerance. //
//     int max_tries                                                          //
//        User supplied parameter which sets the maximum number of iterations //
//        to try to converge to the solution.                                 //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The algorithm did not converge within max_tries tries.    //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double x[N], x0[N], omega;                                             //
//     double tolerance = 1.e-6;                                              //
//     int max_tries = 40;                                                    //
//     extern double eval(double*, int);    // user supplied function.        //
//                                                                            //
//     (your code to initialize x0)                                           //
//     err = Successive_Overrelaxation(eval, x, x0, N, omega, tolerance,      //
//                                                                max_tries); //
//     if (err < 0) printf(" The procedure failed to converge\n");            //
//     else { printf(" The Solution is: \n"); ...                             //
////////////////////////////////////////////////////////////////////////////////
#include <math.h>                               // required for fabs()
#include <string.h>                             // required for memcpy()

int Successive_Overrelaxation(double (*residual)(double*,int), double x[],
           double x0[], int n, double omega,  double tolerance, int max_tries)
{
   int i, try;
   int length = sizeof(double) * n;
   double max, dum;

                    // The Successive Overrelaxation Method

   memcpy( x, x0, length);
   for (try = 0; try < max_tries; try ++) {
      for (i = 0; i < n; i++)  x[i] += omega * (*residual)(x,i);
      max = fabs(x[0] - x0[0]);
      for ( i = 1; i < n; i++) 
         if ( max < (dum = fabs(x[i] - x0[i])) ) max = dum;   
      if (max < tolerance) break;
      memcpy( x0, x, length);
   }
   if (try >= max_tries) return -1; 
   return 0;
}
