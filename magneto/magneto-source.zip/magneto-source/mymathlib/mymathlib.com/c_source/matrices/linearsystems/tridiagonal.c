////////////////////////////////////////////////////////////////////////////////
// File: tridiagonal.c                                                        //
// Contents:                                                                  //
//    Tridiagonal_LU_Decomposition                                            //
//    Tridiagonal_LU_Solve                                                    //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  Tridiagonal_LU_Decomposition(double *subdiagonal, double *diagonal,       //
//                                           double *superdiagonal, int n )   //
//                                                                            //
//  Description:                                                              //
//     This routine decomposes a tridiagonal matrix A into the product of     //
//     a unit lower triangular (bidiagonal) matrix L and an upper triangular  //
//     (bidiagonal) matrix U, A = LU.                                         //
//     The tridiagonal matrix A is defined by the three vectors, subdiagonal, //
//     diagonal, and superdiagonal, where the i-th component of subdiagonal is//
//     subdiagonal[i] = A[i+1][i], for i = 0, ..., n - 2; the i-th component  //
//     of diagonal is diagonal[i] = A[i][i], for i = 0, ..., n - 1; and the   //
//     i-th component of superdiagonal is superdiagonal[i] = A[i][i+1], for   //
//     i = 0, ..., n - 2.                                                     //
//     The algorithm proceeds by decomposing the matrix A into the product    //
//     of a unit lower triangular (bidiagonal) matrix, stored in subdiagonal, //
//     and an upper triangular (bidiagonal) matrix, stored in diagonal and    //
//     and superdiagonal.                                                     //
//     After performing the LU decomposition for A, call Tridiagonal_LU_Solve //
//     to solve the equation Ax = B for x given B.                            //
//                                                                            //
//     This routine can fail if A[0][0] = 0 or if during the LU decomposition //
//     the diagonal element of U becomes 0.  This does not imply that the     //
//     matrix A is singular.  If A is positive definite or if A is diagonally //
//     dominant then the procedure should not fail.                           //
//                                                                            //
//  Arguments:                                                                //
//     double subdiagonal[]                                                   //
//        On input, subdiagonal[i] is the subdiagonal element A[i+1][i].      //
//        On output, subdiagonal[i] is the subdiagonal of the unit lower      //
//        triangular matrix L in the LU decomposition of A.                   //
//     double diagonal[]                                                      //
//        On input, diagonal[i] is the diagonal element A[i][i] of the matrix //
//        A.  On output, diagonal[i] is the diagonal of the upper triangular  //
//        matrix U in the LU decomposition of A.                              //
//     double superdiagonal[]                                                 //
//        On input, superdiagonal[i] is the superdiagonal element A[i][i+1] of//
//        the matrix A.  On output, superdiagonal[i] is the superdiagonal of  //
//        the upper triangular matrix U, which agrees with the input.         //
//     int     n   The number of rows and/or columns of the matrix A.         //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - A zero occurred on the diagonal of U.                     //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double subdiagonal[N], diagonal[N], superdiagonal[N];                  //
//                                                                            //
//     (your code to create subdiagonal, diagonal, and superdiagonal)         //
//     err = Tridiagonal_LU_Decomposition(subdiagonal, diagonal,              //
//                                                         superdiagonal, N); //
//     if (err < 0) printf(" Matrix A failed the LU decomposition\n");        //
//     else { printf(" The Solution is: \n"); ...                             //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Tridiagonal_LU_Decomposition( double subdiagonal[], double diagonal[],
                                                double superdiagonal[], int n )
{
   int i;

   for (i = 0; i < (n-1); i++) {
      if (diagonal[i] == 0.0) return -1;
      subdiagonal[i] /= diagonal[i];
      diagonal[i+1] -= subdiagonal[i] * superdiagonal[i];
   }
   if (diagonal[n-1] == 0.0) return -1;      
   return 0;
}


////////////////////////////////////////////////////////////////////////////////
// int Tridiagonal_LU_Solve(double subdiagonal[], double diagonal[],          //
//                 double superdiagonal[],  double B[], double x[],  int n)   //
//                                                                            //
//  Description:                                                              //
//     This routine uses the LU decomposition from the routine above,         //
//     Tridiagonal_LU_Decomposition, to solve the linear equation Ax = B,     //
//     where A = LU, L is the unit lower triangular (bidiagonal) matrix with  //
//     subdiagonal subdiagonal[] and diagonal all 1's, and U is the upper     //
//     triangular (bidiagonal) matrix with diagonal diagonal[] and            //
//     superdiagonal superdiagonal[].                                         //
//     The solution proceeds by solving the linear equation Ly = B for y and  //
//     subsequently solving the linear equation Ux = y for x.                 //
//                                                                            //
//  Arguments:                                                                //
//     double subdiagonal[]                                                   //
//        The subdiagonal of the unit lower triangular matrix L in the LU     //
//        decomposition of A.                                                 //
//     double diagonal[]                                                      //
//        The diagonal of the upper triangular matrix U in the LU decomposi-  //
//        tion of A.                                                          //
//     double superdiagonal[]                                                 //
//        The superdiagonal of the upper triangular matrix U.                 //
//     double B[]                                                             //
//        Pointer to the column vector, (n x 1) matrix, B.                    //
//     double x[]                                                             //
//        Solution to the equation Ax = B.                                    //
//     int     n   The number of rows and/or columns of the matrix LU.        //
//                                                                            //
//  Return Values:                                                            //
//     0  Success                                                             //
//    -1  Failure - The matrix U is singular.                                 //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double subdiagonal[N], diagonal[N], superdiagonal[N];                  //
//     double B[N], x[N];                                                     //
//                                                                            //
//     (your code to create subdiagonal, diagonal, superdiagonal, and B)      //
//     err = Tridiagonal_LU_Decomposition(subdiagonal, diagonal,              //
//                                                          superdiagonal, N);//
//     if (err < 0) printf(" Matrix A is fails the LU decomposition\n");      //
//     else {                                                                 //
//        err = Tridiagonal_LU_Solve(subdiagona, diagonal, superdiagonal, B,  //
//                                                                      x, n);//
//        if (err < 0) printf(" Matrix A is singular\n");                     //
//        else printf(" The solution is \n");                                 //
//           ...                                                              //
//     }                                                                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
int Tridiagonal_LU_Solve( double subdiagonal[], double diagonal[],
                       double superdiagonal[], double B[], double x[], int n)
{
   int i;

//         Check that all diagonal elements are nonzero.
//         If a diagonal element is zero then U is singular, so return
//         signalling an error.

   for (i = 0; i < n; i++) if (diagonal[i] == 0.0) return -1;

//         Solve the linear equation Ly = B for y, where L is a lower
//         triangular matrix.
   
   x[0] = B[0];
   for (i = 1; i < n; i++) x[i] = B[i] - subdiagonal[i-1] * x[i-1];

//         Solve the linear equation Ux = y, where y is the solution
//         obtained above of Ly = B and U is an upper triangular matrix.

   x[n-1] /= diagonal[n-1];

   for (i = n-2; i >= 0; i--) {
      x[i] -= superdiagonal[i] * x[i+1];
      x[i] /= diagonal[i];
   }
   
   return 0;
} 
