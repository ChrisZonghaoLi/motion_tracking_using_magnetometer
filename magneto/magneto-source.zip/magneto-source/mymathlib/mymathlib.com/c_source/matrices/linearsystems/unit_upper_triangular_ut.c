////////////////////////////////////////////////////////////////////////////////
// File: unit_upper_triangular_ut.c                                           //
// Routines:                                                                  //
//    Unit_Upper_Triangular_Solve_ut                                          //
//    Unit_Upper_Triangular_Inverse_ut                                        //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  void Unit_Upper_Triangular_Solve_ut(double *U, double *B, double x[],     //
//                                                                  int n)    //
//                                                                            //
//  Description:                                                              //
//     This routine solves the linear equation Ux = B, where U is an n x n    //
//     unit upper triangular matrix.  The diagonal is assumed to consist of   //
//     1's and is not addressed.                                              //
//                                                                            //
//     The input matrix U is stored in upper triangular form, i.e. the        //
//     elements of U are stored sequentially starting with the first row which//
//     contains n elements, followed by the second row which consists of n-1  //
//     elements, and so on until the last row which consists of 1 element.    //
//                                                                            //
//     The algorithm follows:                                                 //
//                       x[n-1] = B[n-1], and                                 //
//       x[i] = [B[i] - (U[i][i+1] * x[i+1]  + ... + U[i][n-1] * x[n-1])],    //
//     for i = n-2, ..., 0.                                                   //
//                                                                            //
//  Arguments:                                                                //
//     double *U   Pointer to the first element of the unit upper triangular  //
//                 matrix.                                                    //
//     double *B   Pointer to the column vector, (n x 1) matrix, B.           //
//     double *x   Pointer to the column vector, (n x 1) matrix, x.           //
//     int     n   The number of rows or columns of the matrix U.             //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double A[N * (N + 1) / 2], B[N], x[N];                                 //
//                                                                            //
//     (your code to create matrix A and column vector B)                     //
//     Unit_Upper_Triangular_Solve_ut(A, B, x, n);                            //
//     printf(" The solution is \n");                                         //
//           ...                                                              //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Unit_Upper_Triangular_Solve_ut(double *U, double B[], double x[], int n)
{
   int i, k;

//         Solve the linear equation Ux = B for x, where U is a unit upper
//         triangular matrix stored in upper triangular form.                               
   
   for (k = n-1, U += ((n * (n + 1)) >> 1) - 1; k >= 0; U -= n - --k) {
      x[k] = B[k];
      for (i = k + 1; i < n; i++) x[k] -= x[i] * *(U + i - k);
   }
}


////////////////////////////////////////////////////////////////////////////////
//  void Unit_Upper_Triangular_Inverse_ut(double *U,  int n)                  //
//                                                                            //
//  Description:                                                              //
//     This routine calculates the inverse of the unit upper triangular       //
//      matrix U.  The diagonal is not addressed.                             //
//                                                                            //
//     The matrix U is stored in upper triangular form, i.e. the elements of  //
//     are stored sequentially starting with the first row which contains n   //
//     elements, followed by the second row which consists of n-1 elements,   //
//     and so on until the last row which consists of 1 element.              //
//                                                                            //
//     The algorithm follows:                                                 //
//        Let M be the inverse of U, then U M = I,                            //
//          M[i][j] = -( U[i][i+1] M[i+1][j] + ... + U[i][j] M[j][j] ),       //
//     for i = n-2, ... , 0,  j = n-1, ..., i+1.                              //
//                                                                            //
//                                                                            //
//  Arguments:                                                                //
//     double *U   On input, the pointer to the first element of the matrix   //
//                 whose upper triangular elements form the matrix which is   //
//                 to be inverted. On output, the upper triangular part is    //
//                 replaced by the inverse.  The diagonal elements are not    //
//                 modified.                                                  //
//     int     n   The number of rows and/or columns of the matrix U.         //
//                                                                            //
//  Return Values:                                                            //
//     void                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N                                                              //
//     double U[N * (N + 1) / 2];                                             //
//                                                                            //
//     (your code to create the matrix U)                                     //
//     Unit_Upper_Triangular_Inverse_ut(U, N);                                //
//     printf(" The inverse is \n");                                          //
//           ...                                                              //
//     }                                                                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Unit_Upper_Triangular_Inverse_ut(double *U, int n)
{
   int i, j, k;
   double *p_i, *p_j, *p_k;
   double sum;

//         Invert the superdiagonal part of the matrix U row by row where
//         the diagonal elements are assumed to be 1.0.

   for (i = n - 1, p_i = U + ((n * (n + 1)) >> 1) - 1; i >=0; p_i -= n - --i ) {
      for (j = n - 1; j > i; j--) {
         sum = 0.0;
         for (k = i + 1, p_k = p_i + n - i; k < j; p_k += n - k++ ) {
            sum += *(p_i + k - i) * *(p_k + j - k);
         }
         sum += *(p_i + j - i);
         *(p_i + j - i) = - sum;
      }
   }
}
