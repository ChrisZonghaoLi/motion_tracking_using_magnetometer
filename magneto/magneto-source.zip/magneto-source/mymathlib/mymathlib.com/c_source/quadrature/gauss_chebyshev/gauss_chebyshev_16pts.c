////////////////////////////////////////////////////////////////////////////////
// File: gauss_chebyshev_16pts.c                                              //
// Routines:                                                                  //
//    double Gauss_Chebyshev_Integration_16pts( double (*f)(double) )         //
//    void   Gauss_Chebyshev_Zeros_16pts( double zeros[] )                    //
//    void   Gauss_Chebyshev_Coefs_16pts( double coef[] )                     //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The zeros of the Chebyshev polynomial T16(x) = cos(16 * arccos(x)) are     //
// the positive and negative values of the elements in the array x below.     //
// The coefficient of the Gauss-Chebyshev formula is A = PI / 16.             //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    9.95184726672196886231e-01,    9.56940335732208864931e-01,
    8.81921264348355029715e-01,    7.73010453362736960797e-01,
    6.34393284163645498203e-01,    4.71396736825997648545e-01,
    2.90284677254462367645e-01,    9.80171403295606019957e-02
};

static const double A = 1.96349540849362077407e-01;

#define NUM_OF_POSITIVE_ZEROS  sizeof(x) / sizeof(double)
#define NUM_OF_ZEROS           NUM_OF_POSITIVE_ZEROS+NUM_OF_POSITIVE_ZEROS

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Chebyshev_Integration_16pts( double (*f)(double) )           //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) / sqrt(1 - x^2) from -1 to 1 using    //
//     the 16 point Gauss-Chebyshev integral approximation formula.           //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) / sqrt(1 - x^2) from -1 to 1.                     //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Chebyshev_Integration_16pts( f );                  //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Chebyshev_Integration_16pts( double (*f)(double) ) {
   
   double integral = 0.0;
   const double *px;

   for (px = &x[NUM_OF_POSITIVE_ZEROS - 1]; px >= x; px--) 
      integral +=   (*f)(*px) + (*f)(- *px);

   return A * integral; 
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Zeros_16pts( double zeros[] )                        //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Chebyshev polynomial T16 = cos(16 arccos(x)). //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of T16.  This array   //
//                    should be dimensioned 16 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double z[16];                                                          //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Zeros_16pts( z );                                      //
//     printf("The zeros of the Chebyshev polynomial T16 are:");              //
//     for ( i = 0; i < 16; i++) printf("%12.6le\n",z[i]);                    //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Zeros_16pts( double zeros[] ) {
   
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   double *pz = &zeros[NUM_OF_ZEROS - 1];

   for (; px >= x; px--)  {
      *(zeros++) = - *px;
      *(pz--) = *px;
   }   
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Coefs_16pts( double coef[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 16 point Gauss-Chebyshev formula.     //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Chebyshev formula.  For Gauss-Chebyshev integration     //
//                    the coefficients are the same for each term, therefore  //
//                    the dimension of coef[] is only 1. I.e. the argument    //
//                    is the address of a double.                             //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double a;                                                              //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Coefs_16pts( &a );                                     //
//     printf("The coefficient for the Gauss-Chebyshev formula is :\          //
//                                                              %12.6lf",a);  //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Coefs_16pts( double *coef) {

  *coef = A;
}
