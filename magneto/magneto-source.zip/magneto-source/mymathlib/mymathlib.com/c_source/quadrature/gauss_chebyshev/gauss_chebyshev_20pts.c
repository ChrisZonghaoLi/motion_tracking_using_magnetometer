////////////////////////////////////////////////////////////////////////////////
// File: gauss_chebyshev_20pts.c                                              //
// Routines:                                                                  //
//    double Gauss_Chebyshev_Integration_20pts( double (*f)(double) )         //
//    void   Gauss_Chebyshev_Zeros_20pts( double zeros[] )                    //
//    void   Gauss_Chebyshev_Coefs_20pts( double coef[] )                     //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The zeros of the Chebyshev polynomial T20(x) = cos(20 * arccos(x)) are     //
// the positive and negative values of the elements in the array x below.     //
// The coefficient of the Gauss-Chebyshev formula is A = PI / 20.             //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    9.96917333733127976206e-01,    9.72369920397676601822e-01,
    9.23879532511286756101e-01,    8.52640164354092221514e-01,
    7.60405965600030938169e-01,    6.49448048330183655701e-01,
    5.22498564715948865002e-01,    3.82683432365089771723e-01,
    2.33445363855905411768e-01,    7.84590957278449450322e-02
};

static const double A = 1.57079632679489661926e-01;

#define NUM_OF_POSITIVE_ZEROS sizeof(x) / sizeof(double)
#define NUM_OF_ZEROS NUM_OF_POSITIVE_ZEROS+NUM_OF_POSITIVE_ZEROS

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Chebyshev_Integration_20pts( double (*f)(double) )           //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) / sqrt(1 - x^2) from -1 to 1 using    //
//     the 20 point Gauss-Chebyshev integral approximation formula.           //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) / sqrt(1 - x^2) from -1 to 1.                     //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Chebyshev_Integration_20pts( f );                  //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Chebyshev_Integration_20pts( double (*f)(double) ) {
   
   double integral = 0.0;
   const double *px;

   for (px = &x[NUM_OF_POSITIVE_ZEROS - 1]; px >= x; px--) 
      integral +=   (*f)(*px) + (*f)(- *px);

   return A * integral; 
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Zeros_20pts( double zeros[] )                        //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Chebyshev polynomial T20 = cos(20 arccos(x))  //
//     the 20 point Gauss-Chebyshev integral approximation formula.           //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of T20.  This array   //
//                    should be dimensioned 20 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double z[20];                                                          //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Zeros_20pts( z );                                      //
//     printf("The zeros of the Chebyshev polynomial T20 are:");              //
//     for ( i = 0; i < 20; i++) printf("%12.6le\n",z[i]);                    //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Zeros_20pts( double zeros[] ) {
   
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   double *pz = &zeros[NUM_OF_ZEROS - 1];

   for (; px >= x; px--)  {
      *(zeros++) = - *px;
      *(pz--) = *px;
   }   
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Coefs_20pts( double coef[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 20 point Gauss-Chebyshev formula.     //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Chebyshev formula.  For Gauss-Chebyshev integration     //
//                    the coefficients are the same for each term, therefore  //
//                    the dimension of coef[] is only 1. I.e. the argument    //
//                    is the address of a double.                             //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double a;                                                              //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Coefs_20pts( &a );                                     //
//     printf("The coefficient for the Gauss-Chebyshev formula is :\          //
//                                                              %12.6lf",a);  //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Coefs_20pts( double *coef) {

  *coef = A;
   
}
