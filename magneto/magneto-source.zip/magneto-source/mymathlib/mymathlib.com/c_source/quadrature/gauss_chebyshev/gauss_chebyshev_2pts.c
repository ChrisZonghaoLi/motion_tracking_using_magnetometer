////////////////////////////////////////////////////////////////////////////////
// File: gauss_chebyshev_2pts.c                                               //
// Routines:                                                                  //
//    double Gauss_Chebyshev_Integration_2pts( double (*f)(double) )          //
//    void   Gauss_Chebyshev_Zeros_2pts( double zeros[] )                     //
//    void   Gauss_Chebyshev_Coefs_2pts( double coef[] )                      //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The zeros of the Chebyshev polynomial T2(x) = cos(2 * arccos(x)) are       //
// the positive and negative values of the elements in the array x below.     //
// The coefficient of the Gauss-Chebyshev formula is A = PI / 2.              //
////////////////////////////////////////////////////////////////////////////////

static const double x = 7.07106781186547524382e-01;

static const double A = 1.57079632679489661926e+00;

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Chebyshev_Integration_2pts( double (*f)(double) )            //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) / sqrt(1 - x^2) from -1 to 1 using    //
//     the 2 point Gauss-Chebyshev integral approximation formula.            //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) / sqrt(1 - x^2) from -1 to 1.                     //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Chebyshev_Integration_2pts( f );                   //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Chebyshev_Integration_2pts( double (*f)(double) ) {
   
   return A * ( (*f)(x) + (*f)(-x) );
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Zeros_2pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Chebyshev polynomial T2 = cos(2 arccos(x)).   //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of T2.  This array    //
//                    should be dimensioned 2 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double z[2];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Zeros_2pts( z );                                       //
//     printf("The zeros of the Chebyshev polynomial T2 are:");               //
//     for ( i = 0; i < 2; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Zeros_2pts( double zeros[] ) {
   
   zeros[0] = - x;
   zeros[1] = x;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Coefs_2pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 2 point Gauss-Chebyshev formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Chebyshev formula.  For Gauss-Chebyshev integration     //
//                    the coefficients are the same for each term, therefore  //
//                    the dimension of coef[] is only 1. I.e. the argument    //
//                    is the address of a double.                             //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double a;                                                              //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Coefs_2pts( &a );                                      //
//     printf("The coefficient for the Gauss-Chebyshev formula is :\          //
//                                                              %12.6lf",a);  //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Coefs_2pts( double *coef) {

  *coef = A;
}
