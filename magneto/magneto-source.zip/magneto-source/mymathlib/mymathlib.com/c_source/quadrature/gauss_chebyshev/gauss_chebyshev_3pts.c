////////////////////////////////////////////////////////////////////////////////
// File: gauss_chebyshev_3pts.c                                               //
// Routines:                                                                  //
//    double Gauss_Chebyshev_Integration_3pts( double (*f)(double) )          //
//    void   Gauss_Chebyshev_Zeros_3pts( double zeros[] )                     //
//    void   Gauss_Chebyshev_Coefs_3pts( double coef[] )                      //
//    double Gauss_Chebyshev_Tabular_Int_3pts( double f[] )                   //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The zeros of the Chebyshev polynomial T3(x) = cos(3 * arccos(x)) are       //
// the positive and negative values of the elements in the array x below.     //
// The coefficient of the Gauss-Chebyshev formula is A = PI / 3.              //
////////////////////////////////////////////////////////////////////////////////

static const double x = 8.66025403784438646787e-01;

static const double A = 1.04719755119659774613e+00;

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Chebyshev_Integration_3pts( double (*f)(double) )            //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) / sqrt(1 - x^2) from -1 to 1 using    //
//     the 3 point Gauss-Chebyshev integral approximation formula.            //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) / sqrt(1 - x^2) from -1 to 1.                     //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Chebyshev_Integration_3pts( f );                   //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Chebyshev_Integration_3pts( double (*f)(double) ) {
   
   return A * ( (*f)(x) + (*f)(-x) + (*f)(0.0) );
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Zeros_3pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Chebyshev polynomial T3 = cos(3 arccos(x)).   //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of T3.  This array    //
//                    should be dimensioned 3 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double z[3];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Zeros_3pts( z );                                       //
//     printf("The zeros of the Chebyshev polynomial T3 are:");               //
//     for ( i = 0; i < 3; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Zeros_3pts( double zeros[] ) {
   
   zeros[0] = - x;
   zeros[1] = 0.0;
   zeros[2] = x;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Coefs_3pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 3 point Gauss-Chebyshev formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Chebyshev formula.  For Gauss-Chebyshev integration     //
//                    the coefficients are the same for each term, therefore  //
//                    the dimension of coef[] is only 1. I.e. the argument    //
//                    is the address of a double.                             //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double a;                                                              //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Coefs_3pts( &a );                                      //
//     printf("The coefficient for the Gauss-Chebyshev formula is :\          //
//                                                              %12.6lf",a);  //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Coefs_3pts( double *coef) {

  *coef = A;
}
