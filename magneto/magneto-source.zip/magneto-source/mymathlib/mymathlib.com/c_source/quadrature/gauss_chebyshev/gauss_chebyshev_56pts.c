////////////////////////////////////////////////////////////////////////////////
// File: gauss_chebyshev_56pts.c                                              //
// Routines:                                                                  //
//    double Gauss_Chebyshev_Integration_56pts( double (*f)(double) )         //
//    void   Gauss_Chebyshev_Zeros_56pts( double zeros[] )                    //
//    void   Gauss_Chebyshev_Coefs_56pts( double coef[] )                     //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The zeros of the Chebyshev polynomial T56(x) = cos(56 * arccos(x)) are     //
// the positive and negative values of the elements in the array x below.     //
// The coefficient of the Gauss-Chebyshev formula is A = PI / 56.             //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    9.99606626383052885481e-01,    9.96461494117619146554e-01,
    9.90181125336445590443e-01,    9.80785280403230449119e-01,
    9.68303522122261439372e-01,    9.52775122722896289677e-01,
    9.34248940294599855083e-01,    9.12783265061318908949e-01,
    8.88445635978872300326e-01,    8.61312628232408940992e-01,
    8.31469612302545237081e-01,    7.99010485358249033909e-01,
    7.64037375821607436647e-01,    7.26660322034027047144e-01,
    6.86996926034901633556e-01,    6.45171983542087633292e-01,
    6.01317091298405808221e-01,    5.55570233019602224757e-01,
    5.08075345246529458518e-01,    4.58981864467537681350e-01,
    4.08444256935996135449e-01,    3.56621532662313024366e-01,
    3.03676745109614730804e-01,    2.49776478167226849956e-01,
    1.95090322016128267843e-01,    1.39790339535499477921e-01,
    8.40505249292475450478e-02,    2.80462562758689583761e-02
};

static const double A = 5.60998688141034506853e-02;

#define NUM_OF_POSITIVE_ZEROS  sizeof(x) / sizeof(double)
#define NUM_OF_ZEROS           NUM_OF_POSITIVE_ZEROS+NUM_OF_POSITIVE_ZEROS

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Chebyshev_Integration_56pts( double (*f)(double) )           //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) / sqrt(1 - x^2) from -1 to 1 using    //
//     the 56 point Gauss-Chebyshev integral approximation formula.           //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) / sqrt(1 - x^2) from -1 to 1.                     //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Chebyshev_Integration_56pts( f );                  //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Chebyshev_Integration_56pts( double (*f)(double) ) {

   double integral = 0.0;
   const double *px;

   for (px = &x[NUM_OF_POSITIVE_ZEROS - 1]; px >= x; px--) 
      integral +=   (*f)(*px) + (*f)(- *px);

   return A * integral; 
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Zeros_56pts( double zeros[] )                        //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Chebyshev polynomial T56 = cos(56 arccos(x)). //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of T56.  This array   //
//                    should be dimensioned 56 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double z[56];                                                          //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Zeros_56pts( z );                                      //
//     printf("The zeros of the Chebyshev polynomial T56 are:");              //
//     for ( i = 0; i < 56; i++) printf("%12.6le\n",z[i]);                    //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Zeros_56pts( double zeros[] ) {
   
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   double *pz = &zeros[NUM_OF_ZEROS - 1];

   for (; px >= x; px--)  {
      *(zeros++) = - *px;
      *(pz--) = *px;
   }   
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Coefs_56pts( double coef[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 56 point Gauss-Chebyshev formula.     //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Chebyshev formula.  For Gauss-Chebyshev integration     //
//                    the coefficients are the same for each term, therefore  //
//                    the dimension of coef[] is only 1. I.e. the argument    //
//                    is the address of a double.                             //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double a;                                                              //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Coefs_56pts( &a );                                     //
//     printf("The coefficient for the Gauss-Chebyshev formula is :\          //
//                                                              %12.6lf",a);  //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Coefs_56pts( double *coef) {

  *coef = A;
}
