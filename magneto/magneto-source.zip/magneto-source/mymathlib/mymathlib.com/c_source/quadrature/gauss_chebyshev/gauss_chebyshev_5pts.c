////////////////////////////////////////////////////////////////////////////////
// File: gauss_chebyshev_5pts.c                                               //
// Routines:                                                                  //
//    double Gauss_Chebyshev_Integration_5pts( double (*f)(double) )          //
//    void   Gauss_Chebyshev_Zeros_5pts( double zeros[] )                     //
//    void   Gauss_Chebyshev_Coefs_5pts( double coef[] )                      //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The zeros of the Chebyshev polynomial T5(x) = cos(5 * arccos(x)) are       //
// the positive and negative values of the elements in the array x below.     //
// The coefficient of the Gauss-Chebyshev formula is A = PI / 5.              //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    9.51056516295153572111e-01,    5.87785252292473129189e-01
};

static const double A = 6.28318530717958647703e-01;

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Chebyshev_Integration_5pts( double (*f)(double) )            //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) / sqrt(1 - x^2) from -1 to 1 using    //
//     the 5 point Gauss-Chebyshev integral approximation formula.            //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) / sqrt(1 - x^2) from -1 to 1.                     //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Chebyshev_Integration_5pts( f );                   //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Chebyshev_Integration_5pts( double (*f)(double) ) {
   

   return A * ( (*f)(x[0]) +  (*f)(-x[0]) 
                + (*f)(x[1]) +  (*f)(-x[1]) + (*f)(0.0) );
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Zeros_5pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Chebyshev polynomial T5 = cos(5 arccos(x)).   //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of T5.  This array    //
//                    should be dimensioned 5 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double z[5];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Zeros_5pts( z );                                       //
//     printf("The zeros of the Chebyshev polynomial T5 are:");               //
//     for ( i = 0; i < 5; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Zeros_5pts( double zeros[] ) {
   
   zeros[0] = - x[0];
   zeros[1] = - x[1];
   zeros[2] = 0.0;
   zeros[3] = x[1];
   zeros[4] = x[0];
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Coefs_5pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 5 point Gauss-Chebyshev formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Chebyshev formula.  For Gauss-Chebyshev integration     //
//                    the coefficients are the same for each term, therefore  //
//                    the dimension of coef[] is only 1. I.e. the argument    //
//                    is the address of a double.                             //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double a;                                                              //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Coefs_5pts( &a );                                      //
//     printf("The coefficient for the Gauss-Chebyshev formula is :\          //
//                                                              %12.6lf",a);  //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Coefs_5pts( double *coef) {

  *coef = A;
}
