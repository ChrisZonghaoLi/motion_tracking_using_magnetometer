////////////////////////////////////////////////////////////////////////////////
// File: gauss_chebyshev_64pts.c                                              //
// Routines:                                                                  //
//    double Gauss_Chebyshev_Integration_64pts( double (*f)(double) )         //
//    void   Gauss_Chebyshev_Zeros_64pts( double zeros[] )                    //
//    void   Gauss_Chebyshev_Coefs_64pts( double coef[] )                     //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The zeros of the Chebyshev polynomial T64(x) = cos(64 * arccos(x)) are     //
// the positive and negative values of the elements in the array x below.     //
// The coefficient of the Gauss-Chebyshev formula is A = PI / 64.             //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    9.99698818696204220097e-01,    9.97290456678690216132e-01,
    9.92479534598709998180e-01,    9.85277642388941244766e-01,
    9.75702130038528544446e-01,    9.63776065795439866677e-01,
    9.49528180593036667215e-01,    9.32992798834738887737e-01,
    9.14209755703530654630e-01,    8.93224301195515320339e-01,
    8.70086991108711418636e-01,    8.44853565249707073252e-01,
    8.17584813151583696480e-01,    7.88346427626606262036e-01,
    7.57208846506484547589e-01,    7.24247082951466920962e-01,
    6.89540544737066924622e-01,    6.53172842953776764080e-01,
    6.15231590580626845491e-01,    5.75808191417845300763e-01,
    5.34997619887097210678e-01,    4.92898192229784036869e-01,
    4.49611329654606600042e-01,    4.05241314004989870918e-01,
    3.59895036534988148786e-01,    3.13681740398891476651e-01,
    2.66712757474898386336e-01,    2.19101240156869797227e-01,
    1.70961888760301226360e-01,    1.22410675199216198496e-01,
    7.35645635996674235297e-02,    2.45412285229122880321e-02
};

static const double A = 4.90873852123405193518e-02;

#define NUM_OF_POSITIVE_ZEROS  sizeof(x) / sizeof(double)
#define NUM_OF_ZEROS           NUM_OF_POSITIVE_ZEROS+NUM_OF_POSITIVE_ZEROS

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Chebyshev_Integration_64pts( double (*f)(double) )           //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) / sqrt(1 - x^2) from -1 to 1 using    //
//     the 64 point Gauss-Chebyshev integral approximation formula.           //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) / sqrt(1 - x^2) from -1 to 1.                     //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Chebyshev_Integration_64pts( f );                  //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Chebyshev_Integration_64pts( double (*f)(double) ) {
 
   double integral = 0.0;
   const double *px;

   for (px = &x[NUM_OF_POSITIVE_ZEROS - 1]; px >= x; px--) 
      integral +=   (*f)(*px) + (*f)(- *px);

   return A * integral; 
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Zeros_64pts( double zeros[] )                        //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Chebyshev polynomial T64 = cos(64 arccos(x)). //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of T64.  This array   //
//                    should be dimensioned 64 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double z[64];                                                          //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Zeros_64pts( z );                                      //
//     printf("The zeros of the Chebyshev polynomial T64 are:");              //
//     for ( i = 0; i < 64; i++) printf("%12.6le\n",z[i]);                    //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Zeros_64pts( double zeros[] ) {
   
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   double *pz = &zeros[NUM_OF_ZEROS - 1];

   for (; px >= x; px--)  {
      *(zeros++) = - *px;
      *(pz--) = *px;
   }   
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Coefs_64pts( double coef[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 64 point Gauss-Chebyshev formula.     //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Chebyshev formula.  For Gauss-Chebyshev integration     //
//                    the coefficients are the same for each term, therefore  //
//                    the dimension of coef[] is only 1. I.e. the argument    //
//                    is the address of a double.                             //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double a;                                                              //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Coefs_64pts( &a );                                     //
//     printf("The coefficient for the Gauss-Chebyshev formula is :\          //
//                                                              %12.6lf",a);  //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Coefs_64pts( double *coef) {

  *coef = A;
}
