////////////////////////////////////////////////////////////////////////////////
// File: gauss_chebyshev_6pts.c                                               //
// Routines:                                                                  //
//    double Gauss_Chebyshev_Integration_6pts( double (*f)(double) )          //
//    void   Gauss_Chebyshev_Zeros_6pts( double zeros[] )                     //
//    void   Gauss_Chebyshev_Coefs_6pts( double coef[] )                      //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The zeros of the Chebyshev polynomial T6(x) = cos(6 * arccos(x)) are       //
// the positive and negative values of the elements in the array x below.     //
// The coefficient of the Gauss-Chebyshev formula is A = PI / 6.              //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    9.65925826289068286735e-01,    7.07106781186547524382e-01,
    2.58819045102520762353e-01
};

static const double A = 5.23598775598298873067e-01;

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Chebyshev_Integration_6pts( double (*f)(double) )            //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) / sqrt(1 - x^2) from -1 to 1 using    //
//     the 6 point Gauss-Chebyshev integral approximation formula.            //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) / sqrt(1 - x^2) from -1 to 1.                     //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Chebyshev_Integration_6pts( f );                   //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Chebyshev_Integration_6pts( double (*f)(double) ) {
   

   return A * ( (*f)(x[0]) + (*f)(-x[0]) 
                + (*f)(x[1]) + (*f)(-x[1])
                + (*f)(x[2]) + (*f)(-x[2]) );
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Zeros_6pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Chebyshev polynomial T6 = cos(6 arccos(x)).   //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of T6.  This array    //
//                    should be dimensioned 6 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double z[6];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Zeros_6pts( z );                                       //
//     printf("The zeros of the Chebyshev polynomial T6 are:");               //
//     for ( i = 0; i < 6; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Zeros_6pts( double zeros[] ) {
   
   zeros[0] = - x[0];
   zeros[1] = - x[1];
   zeros[2] = - x[2];
   zeros[3] = x[2];
   zeros[4] = x[1];
   zeros[5] = x[0];
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Coefs_6pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 6 point Gauss-Chebyshev formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Chebyshev formula.  For Gauss-Chebyshev integration     //
//                    the coefficients are the same for each term, therefore  //
//                    the dimension of coef[] is only 1. I.e. the argument    //
//                    is the address of a double.                             //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double a;                                                              //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Coefs_6pts( &a );                                      //
//     printf("The coefficient for the Gauss-Chebyshev formula is :\          //
//                                                              %12.6lf",a);  //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Coefs_6pts( double *coef) {

  *coef = A;
}
