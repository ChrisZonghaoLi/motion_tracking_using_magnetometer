////////////////////////////////////////////////////////////////////////////////
// File: gauss_chebyshev_7pts.c                                               //
// Routines:                                                                  //
//    double Gauss_Chebyshev_Integration_7pts( double (*f)(double) )          //
//    void   Gauss_Chebyshev_Zeros_7pts( double zeros[] )                     //
//    void   Gauss_Chebyshev_Coefs_7pts( double coef[] )                      //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The zeros of the Chebyshev polynomial T7(x) = cos(7 * arccos(x)) are       //
// the positive and negative values of the elements in the array x below.     //
// The coefficient of the Gauss-Chebyshev formula is A = PI / 7.              //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    9.74927912181823607036e-01,    7.81831482468029808730e-01,
    4.33883739117558120483e-01
};

static const double A = 4.48798950512827605482e-01;

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Chebyshev_Integration_7pts( double (*f)(double) )            //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) / sqrt(1 - x^2) from -1 to 1 using    //
//     the 7 point Gauss-Chebyshev integral approximation formula.            //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) / sqrt(1 - x^2) from -1 to 1.                     //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Chebyshev_Integration_7pts( f );                   //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Chebyshev_Integration_7pts( double (*f)(double) ) {
   
   return A * ( (*f)(x[0]) +  (*f)(-x[0]) 
                + (*f)(x[1]) +  (*f)(-x[1]) 
                + (*f)(x[2]) +  (*f)(-x[2]) + (*f)(0.0) );
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Zeros_7pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Chebyshev polynomial T7 = cos(7 arccos(x)).   //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of T7.  This array    //
//                    should be dimensioned 7 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double z[7];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Zeros_7pts( z );                                       //
//     printf("The zeros of the Chebyshev polynomial T7 are:");               //
//     for ( i = 0; i < 7; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Zeros_7pts( double zeros[] ) {
   
   zeros[0] = - x[0];
   zeros[1] = - x[1];
   zeros[2] = - x[2];
   zeros[3] = 0.0;
   zeros[4] = x[2];
   zeros[5] = x[1];
   zeros[6] = x[0];
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Chebyshev_Coefs_7pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 7 point Gauss-Chebyshev formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Chebyshev formula.  For Gauss-Chebyshev integration     //
//                    the coefficients are the same for each term, therefore  //
//                    the dimension of coef[] is only 1. I.e. the argument    //
//                    is the address of a double.                             //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     double a;                                                              //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Chebyshev_Coefs_7pts( &a );                                      //
//     printf("The coefficient for the Gauss-Chebyshev formula is :\          //
//                                                              %12.6lf",a);  //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Chebyshev_Coefs_7pts( double *coef) {

  *coef = A;
}
