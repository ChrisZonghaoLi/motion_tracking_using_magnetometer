////////////////////////////////////////////////////////////////////////////////
// File: gauss_hermite_2pts.c                                                 //
// Routines:                                                                  //
//    Gauss_Hermite_Integration_2pts                                          //
//    Gauss_Hermite_Zeros_2pts                                                //
//    Gauss_Hermite_Coefs_2pts                                                //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Hermite polynomial is                                             //
//              Hn(x) = (-1)^n exp(x^2) (d/dx)^n (exp(-x^2)).                 //
// For the n point Gauss-Hermite integral approximation formula the           //
// coefficients are:                                                          //
//              A[i] = 2^(n+1) (n!) sqrt(PI) /  (Hn'(x[i]))^2                 //
// where x[i] is a zero of the n-th Hermite polynomial Hn(x).                 //
// Note that if x is a zero of Hn(x) then -x is also a zero of Hn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x = 7.07106781186547524382e-01;

static const double A = 8.86226925452758013655e-01;


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Hermite_Integration_2pts( double (*f)(double) )              //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x^2) from -infinity to infinity  //
//     using the 2 point Gauss-Hermite integral approximation formula.        //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x^2) from -infinity to infinity.             //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Hermite_Integration_2pts( f );                     //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Hermite_Integration_2pts( double (*f)(double) ) {
   
   return A * ( (*f)(x) + (*f)(-x) );
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Zeros_2pts( double zeros[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the 2th Hermite polynomial H2.                    //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of H2.  This array    //
//                    should be dimensioned 2 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 2                                                            //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Zeros_2pts( z );                                         //
//     printf("The zeros of the Hermite polynomial H2 are:");                 //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Zeros_2pts( double zeros[] ) {
   
   zeros[0] = -x;
   zeros[1] = x;

}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Coefs_2pts( double coef[] )                            //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 2 point Gauss-Hermite formula.        //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Hermite formula.  This array should be dimensioned      //
//                    2 in the caller function.                               //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 2                                                            //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Coefs_2pts( a );                                         //
//     printf("The coefficients for the Gauss-Hermite formula are:\n");       //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Coefs_2pts( double coef[]) {

   coef[0] = A;
   coef[1] = A;

}
