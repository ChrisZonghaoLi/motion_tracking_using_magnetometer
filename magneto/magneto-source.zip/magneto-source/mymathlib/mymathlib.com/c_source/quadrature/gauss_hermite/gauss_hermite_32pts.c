////////////////////////////////////////////////////////////////////////////////
// File: gauss_hermite_32pts.c                                                //
// Routines:                                                                  //
//    Gauss_Hermite_Integration_32pts                                         //
//    Gauss_Hermite_Zeros_32pts                                               //
//    Gauss_Hermite_Coefs_32pts                                               //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Hermite polynomial is                                             //
//              Hn(x) = (-1)^n exp(x^2) (d/dx)^n (exp(-x^2)).                 //
// For the n point Gauss-Hermite integral approximation formula the           //
// coefficients are:                                                          //
//              A[i] = 2^(n+1) (n!) sqrt(PI) /  (Hn'(x[i]))^2                 //
// where x[i] is a zero of the n-th Hermite polynomial Hn(x).                 //
// Note that if x is a zero of Hn(x) then -x is also a zero of Hn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    1.94840741569399326713e-01,    5.84978765435932448449e-01,
    9.76500463589682838499e-01,    1.37037641095287183817e+00,
    1.76765410946320160465e+00,    2.16949918360611217335e+00,
    2.57724953773231745414e+00,    2.99249082500237420621e+00,
    3.41716749281857073593e+00,    3.85375548547144464390e+00,
    4.30554795335119844506e+00,    4.77716450350259639289e+00,
    5.27555098651588012760e+00,    5.81222594951591383294e+00,
    6.40949814926966041214e+00,    7.12581390983072757292e+00
};

static const double A[] = {
    3.75238352592802392864e-01,    2.77458142302529898131e-01,
    1.51269734076642482578e-01,    6.04581309559126141860e-02,
    1.75534288315734303030e-02,    3.65489032665442807915e-03,
    5.36268365527972045989e-04,    5.41658406181998255789e-05,
    3.65058512956237605727e-06,    1.57416779254559402923e-07,
    4.09883216477089661816e-09,    5.93329146339663861478e-11,
    4.21501021132644757306e-13,    1.19734401709284866582e-15,
    9.23173653651829223381e-19,    7.31067642738416239302e-23
};

#define NUM_OF_POSITIVE_ZEROS  sizeof(x) / sizeof(double)
#define NUM_OF_ZEROS           NUM_OF_POSITIVE_ZEROS+NUM_OF_POSITIVE_ZEROS


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Hermite_Integration_32pts( double (*f)(double) )             //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x^2) from -infinity to infinity  //
//     using the 32 point Gauss-Hermite integral approximation formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x^2) from -infinity to infinity.             //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Hermite_Integration_32pts( f );                    //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Hermite_Integration_32pts( double (*f)(double) ) {

   double integral = 0.0;
   const double *pA = &A[NUM_OF_POSITIVE_ZEROS];
   const double *px;

   for (px = &x[NUM_OF_POSITIVE_ZEROS - 1]; px >= x; px--) 
      integral += *(--pA) * ( (*f)(*px) + (*f)(- *px) );

   return integral;
};


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Zeros_32pts( double zeros[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Hermite polynomial H32.                       //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of H32.  This array   //
//                    should be dimensioned 32 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 32                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Zeros_32pts( z );                                        //
//     printf("The zeros of the Hermite polynomial H32 are:");                //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Zeros_32pts( double zeros[] ) {
   
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   double *pz = &zeros[NUM_OF_ZEROS - 1];

   for (; px >= x; px--)  {
      *(zeros++) = - *px;
      *(pz--) = *px;
   }   
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Coefs_32pts( double coef[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 32 point Gauss-Hermite formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Hermite formula.  This array should be dimensioned      //
//                    32 in the caller function.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 32                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Coefs_32pts( a );                                        //
//     printf("The coefficients for the Gauss-Hermite formula are:\n");       //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Coefs_32pts( double coef[]) {

   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];
   double *pc = &coef[NUM_OF_ZEROS - 1];

   for (; pA >= A; pA--)  {
      *(coef++) =  *pA;
      *(pc--) = *pA;
   }   
}
