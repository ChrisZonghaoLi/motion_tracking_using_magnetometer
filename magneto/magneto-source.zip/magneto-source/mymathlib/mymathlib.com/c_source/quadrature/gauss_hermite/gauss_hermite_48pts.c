////////////////////////////////////////////////////////////////////////////////
// File: gauss_hermite_48pts.c                                                //
// Routines:                                                                  //
//    Gauss_Hermite_Integration_48pts                                         //
//    Gauss_Hermite_Zeros_48pts                                               //
//    Gauss_Hermite_Coefs_48pts                                               //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Hermite polynomial is                                             //
//              Hn(x) = (-1)^n exp(x^2) (d/dx)^n (exp(-x^2)).                 //
// For the n point Gauss-Hermite integral approximation formula the           //
// coefficients are:                                                          //
//              A[i] = 2^(n+1) (n!) sqrt(PI) /  (Hn'(x[i]))^2                 //
// where x[i] is a zero of the n-th Hermite polynomial Hn(x).                 //
// Note that if x is a zero of Hn(x) then -x is also a zero of Hn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    1.59492935848862470508e-01,    4.78646337594496098242e-01,
    7.98304627778562231224e-01,    1.11881215240215656334e+00,
    1.44052522013756518647e+00,    1.76381757989530000620e+00,
    2.08908666094427643593e+00,    2.41676090487321645894e+00,
    2.74730862482238321958e+00,    3.08124898864510584967e+00,
    3.41916596936388461126e+00,    3.76172649022835778754e+00,
    4.10970460356059023648e+00,    4.46401454693445890387e+00,
    4.82575722813320948405e+00,    5.19628771879236454109e+00,
    5.57731698122372862624e+00,    5.97107222501354540766e+00,
    6.38056409618641062406e+00,    6.81006457807414138659e+00,
    7.26604655416435040284e+00,    7.75929551976577463936e+00,
    8.31075219070478413055e+00,    8.97531508193168706209e+00
};

static const double A[] = {
    3.11001030377963078889e-01,    2.53961542664759097647e-01,
    1.69204471945641106716e-01,    9.18222970792851793213e-02,
    4.04796769846038489857e-02,    1.44449615749810994174e-02,
    4.15300491197755245160e-03,    9.56392319819415276727e-04,
    1.75150431801172828783e-04,    2.52859902774848890262e-05,
    2.84725869173484808304e-06,    2.46865899366975047785e-07,
    1.62251413589576983694e-08,    7.93046749516538231080e-10,
    2.81529653783816910885e-11,    7.04693258154588908422e-13,
    1.19758986547917935294e-14,    1.31515962265840851188e-16,
    8.73015960118667654513e-19,    3.18838732350513844266e-21,
    5.56457746890228483629e-24,    3.68503608015066987942e-27,
    5.98461269331387842586e-31,    7.93555146077399683864e-36
};

#define NUM_OF_POSITIVE_ZEROS  sizeof(x) / sizeof(double)
#define NUM_OF_ZEROS           NUM_OF_POSITIVE_ZEROS+NUM_OF_POSITIVE_ZEROS


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Hermite_Integration_48pts( double (*f)(double) )             //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x^2) from -infinity to infinity  //
//     using the 48 point Gauss-Hermite integral approximation formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x^2) from -infinity to infinity.             //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Hermite_Integration_48pts( f );                    //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Hermite_Integration_48pts( double (*f)(double) ) {

   double integral = 0.0;
   const double *pA = &A[NUM_OF_POSITIVE_ZEROS];
   const double *px;

   for (px = &x[NUM_OF_POSITIVE_ZEROS - 1]; px >= x; px--) 
      integral += *(--pA) * ( (*f)(*px) + (*f)(- *px) );

   return integral;
};


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Zeros_48pts( double zeros[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Hermite polynomial H48.                       //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of H48.  This array   //
//                    should be dimensioned 48 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 48                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Zeros_48pts( z );                                        //
//     printf("The zeros of the Hermite polynomial H48 are:");                //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Zeros_48pts( double zeros[] ) {
   
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   double *pz = &zeros[NUM_OF_ZEROS - 1];

   for (; px >= x; px--)  {
      *(zeros++) = - *px;
      *(pz--) = *px;
   }   
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Coefs_48pts( double coef[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 48 point Gauss-Hermite formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Hermite formula.  This array should be dimensioned      //
//                    48 in the caller function.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 48                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Coefs_48pts( a );                                        //
//     printf("The coefficients for the Gauss-Hermite formula are:\n");       //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Coefs_48pts( double coef[]) {

   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];
   double *pc = &coef[NUM_OF_ZEROS - 1];

   for (; pA >= A; pA--)  {
      *(coef++) =  *pA;
      *(pc--) = *pA;
   }   
}
