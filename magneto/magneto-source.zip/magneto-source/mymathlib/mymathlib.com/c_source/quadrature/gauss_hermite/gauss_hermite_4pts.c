////////////////////////////////////////////////////////////////////////////////
// File: gauss_hermite_4pts.c                                                 //
// Routines:                                                                  //
//    Gauss_Hermite_Integration_4pts                                          //
//    Gauss_Hermite_Zeros_4pts                                                //
//    Gauss_Hermite_Coefs_4pts                                                //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Hermite polynomial is                                             //
//              Hn(x) = (-1)^n exp(x^2) (d/dx)^n (exp(-x^2)).                 //
// For the n point Gauss-Hermite integral approximation formula the           //
// coefficients are:                                                          //
//              A[i] = 2^(n+1) (n!) sqrt(PI) /  (Hn'(x[i]))^2                 //
// where x[i] is a zero of the n-th Hermite polynomial Hn(x).                 //
// Note that if x is a zero of Hn(x) then -x is also a zero of Hn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    5.24647623275290317900e-01,    1.65068012388578455585e+00
};

static const double A[] = {
    8.04914090005512836482e-01,    8.13128354472451771398e-02
};


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Hermite_Integration_4pts( double (*f)(double) )              //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x^2) from -infinity to infinity  //
//     using the 4 point Gauss-Hermite integral approximation formula.        //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x^2) from -infinity to infinity.             //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Hermite_Integration_4pts( f );                     //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Hermite_Integration_4pts( double (*f)(double) ) {

   return A[1] * ( (*f)(x[1]) + (*f)(-x[1]) ) 
          + A[0] * ( (*f)(x[0]) + (*f)(-x[0]) );
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Zeros_4pts( double zeros[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Hermite polynomial H4.                        //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of H4.  This array    //
//                    should be dimensioned 4 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 4                                                            //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Zeros_4pts( z );                                         //
//     printf("The zeros of the Hermite polynomial H4 are:");                 //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Zeros_4pts( double zeros[] ) {
   
   zeros[0] = -x[1];
   zeros[1] = -x[0];
   zeros[2] = x[0];
   zeros[3] = x[1];

}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Coefs_4pts( double coef[] )                            //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 4 point Gauss-Hermite formula.        //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Hermite formula.  This array should be dimensioned      //
//                    4 in the caller function.                               //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 4                                                            //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Coefs_4pts( a );                                         //
//     printf("The coefficients for the Gauss-Hermite formula are:\n");       //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Coefs_4pts( double coef[]) {

   coef[0] = A[1];
   coef[1] = A[0];
   coef[2] = A[0];
   coef[3] = A[1];

}
