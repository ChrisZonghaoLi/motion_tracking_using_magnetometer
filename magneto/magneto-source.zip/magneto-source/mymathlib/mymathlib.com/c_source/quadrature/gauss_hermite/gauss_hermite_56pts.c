////////////////////////////////////////////////////////////////////////////////
// File: gauss_hermite_56pts.c                                                //
// Routines:                                                                  //
//    Gauss_Hermite_Integration_56pts                                         //
//    Gauss_Hermite_Zeros_56pts                                               //
//    Gauss_Hermite_Coefs_56pts                                               //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Hermite polynomial is                                             //
//              Hn(x) = (-1)^n exp(x^2) (d/dx)^n (exp(-x^2)).                 //
// For the n point Gauss-Hermite integral approximation formula the           //
// coefficients are:                                                          //
//              A[i] = 2^(n+1) (n!) sqrt(PI) /  (Hn'(x[i]))^2                 //
// where x[i] is a zero of the n-th Hermite polynomial Hn(x).                 //
// Note that if x is a zero of Hn(x) then -x is also a zero of Hn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    1.47769954394201150297e-01,    4.43424195050353528550e-01,
    7.39422585234301153235e-01,    1.03599843855700323402e+00,
    1.33339101117920970461e+00,    1.63184812970594450186e+00,
    1.93162908836400707064e+00,    2.23300792084524080149e+00,
    2.53627717765977419499e+00,    2.84175237638099228489e+00,
    3.14977734441996864100e+00,    3.46073074914779841454e+00,
    3.77503421964112432477e+00,    4.09316262629979849127e+00,
    4.41565732910021671934e+00,    4.74314358311812965009e+00,
    5.07635388996399282728e+00,    5.41616006679004734214e+00,
    5.76361847447157764303e+00,    6.12003580614199287676e+00,
    6.48706835174462581681e+00,    6.86687856662528763605e+00,
    7.26239602128679036805e+00,    7.67778417532815005619e+00,
    8.11935800874746926858e+00,    8.59764614143621365080e+00,
    9.13309507061210121715e+00,    9.77930216634031032868e+00
};

static const double A[] = {
    2.89175084335148387062e-01,    2.42989270992723589235e-01,
    1.71477247621271479034e-01,    1.01519392717986805134e-01,
    5.03383974248159080641e-02,    2.08585741401578199162e-02,
    7.20205223204104954801e-03,    2.06474756360313846494e-03,
    4.89372935657049151971e-04,    9.53959910477731192670e-05,
    1.52010814922844868778e-05,    1.96575340040097260371e-06,
    2.04544645364606870285e-07,    1.69543242559918904805e-08,
    1.10620069768821835849e-09,    5.60139785046845940722e-11,
    2.16419258850120925084e-12,    6.25044562975245003100e-14,
    1.31585612513969868999e-15,    1.95692617856474883283e-17,
    1.97566681153905711666e-19,    1.28553638970491260184e-21,
    5.02709991872949700559e-24,    1.07067135896435940544e-26,
    1.07179938832108715666e-29,    3.96215408989599727864e-33,
    3.42498408438829483194e-37,    2.18394737962036649101e-42
};

#define NUM_OF_POSITIVE_ZEROS  sizeof(x) / sizeof(double)
#define NUM_OF_ZEROS           NUM_OF_POSITIVE_ZEROS+NUM_OF_POSITIVE_ZEROS


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Hermite_Integration_56pts( double (*f)(double) )             //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x^2) from -infinity to infinity  //
//     using the 56 point Gauss-Hermite integral approximation formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x^2) from -infinity to infinity.             //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Hermite_Integration_56pts( f );                    //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Hermite_Integration_56pts( double (*f)(double) ) {

   double integral = 0.0;
   const double *pA = &A[NUM_OF_POSITIVE_ZEROS];
   const double *px;

   for (px = &x[NUM_OF_POSITIVE_ZEROS - 1]; px >= x; px--) 
      integral += *(--pA) * ( (*f)(*px) + (*f)(- *px) );

   return integral;
};


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Zeros_56pts( double zeros[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Hermite polynomial H56.                       //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of H56.  This array   //
//                    should be dimensioned 56 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 56                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Zeros_56pts( z );                                        //
//     printf("The zeros of the Hermite polynomial H56 are:");                //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Zeros_56pts( double zeros[] ) {
   
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   double *pz = &zeros[NUM_OF_ZEROS - 1];

   for (; px >= x; px--)  {
      *(zeros++) = - *px;
      *(pz--) = *px;
   }   
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Coefs_56pts( double coef[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 56 point Gauss-Hermite formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Hermite formula.  This array should be dimensioned      //
//                    56 in the caller function.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 56                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Coefs_56pts( a );                                        //
//     printf("The coefficients for the Gauss-Hermite formula are:\n");       //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Coefs_56pts( double coef[]) {

   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];
   double *pc = &coef[NUM_OF_ZEROS - 1];

   for (; pA >= A; pA--)  {
      *(coef++) =  *pA;
      *(pc--) = *pA;
   }   
}
