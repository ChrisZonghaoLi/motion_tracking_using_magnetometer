////////////////////////////////////////////////////////////////////////////////
// File: gauss_hermite_64pts.c                                                //
// Routines:                                                                  //
//    Gauss_Hermite_Integration_64pts                                         //
//    Gauss_Hermite_Zeros_64pts                                               //
//    Gauss_Hermite_Coefs_64pts                                               //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Hermite polynomial is                                             //
//              Hn(x) = (-1)^n exp(x^2) (d/dx)^n (exp(-x^2)).                 //
// For the n point Gauss-Hermite integral approximation formula the           //
// coefficients are:                                                          //
//              A[i] = 2^(n+1) (n!) sqrt(PI) /  (Hn'(x[i]))^2                 //
// where x[i] is a zero of the n-th Hermite polynomial Hn(x).                 //
// Note that if x is a zero of Hn(x) then -x is also a zero of Hn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    1.38302244987009724116e-01,    4.14988824121078684584e-01,
    6.91922305810044577278e-01,    9.69269423071178016745e-01,
    1.24720015694311794072e+00,    1.52588914020986366295e+00,
    1.80551717146554491895e+00,    2.08627287988176202084e+00,
    2.36835458863240140418e+00,    2.65197243543063501106e+00,
    2.93735082300462180976e+00,    3.22473129199203572583e+00,
    3.51437593574090621144e+00,    3.80657151394536046127e+00,
    4.10163447456665671486e+00,    4.39991716822813764762e+00,
    4.70181564740749981593e+00,    5.00777960219876819639e+00,
    5.31832522463327085713e+00,    5.63405216434997214731e+00,
    5.95566632679948604551e+00,    6.28401122877482823555e+00,
    6.62011226263602737922e+00,    6.96524112055110752916e+00,
    7.32101303278094920138e+00,    7.68954016404049682824e+00,
    8.07368728501022522599e+00,    8.47752908337986309066e+00,
    8.90724909996476975696e+00,    9.37315954964672116284e+00,
    9.89528758682953902149e+00,    1.05261231679605458834e+01
};

static const double A[] = {
    2.71377424941303977947e-01,    2.32994786062678046649e-01,
    1.71685842349083702001e-01,    1.08498349306186840632e-01,
    5.87399819640994345496e-02,    2.72031289536889184544e-02,
    1.07560405098791370492e-02,    3.62258697853445876057e-03,
    1.03632909950757766343e-03,    2.50983698513062486093e-04,
    5.12592913578627466080e-05,    8.78849923085035918142e-06,
    1.25834025103118457615e-06,    1.49553293672724706114e-07,
    1.46512531647610935494e-08,    1.17361674232154934349e-09,
    7.61521725014545135318e-11,    3.95917776694772392711e-12,
    1.62834073070972036212e-13,    5.21862372659084752279e-15,
    1.28009339132243804163e-16,    2.35188471067581911698e-18,
    3.15225456650378141599e-20,    2.98286278427985115448e-22,
    1.91170688330064282993e-24,    7.86179778892591036891e-27,
    1.92910359546496685035e-29,    2.54966089911299925654e-32,
    1.55739062462976380226e-35,    3.42113801125574050436e-39,
    1.67974799010815921869e-43,    5.53570653585694282057e-49
};

#define NUM_OF_POSITIVE_ZEROS  sizeof(x) / sizeof(double)
#define NUM_OF_ZEROS           NUM_OF_POSITIVE_ZEROS+NUM_OF_POSITIVE_ZEROS


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Hermite_Integration_64pts( double (*f)(double) )             //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x^2) from -infinity to infinity  //
//     using the 64 point Gauss-Hermite integral approximation formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x^2) from -infinity to infinity.             //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Hermite_Integration_64pts( f );                    //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Hermite_Integration_64pts( double (*f)(double) ) {

   double integral = 0.0;
   const double *pA = &A[NUM_OF_POSITIVE_ZEROS];
   const double *px;

   for (px = &x[NUM_OF_POSITIVE_ZEROS - 1]; px >= x; px--) 
      integral += *(--pA) * ( (*f)(*px) + (*f)(- *px) );

   return integral;
};


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Zeros_64pts( double zeros[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Hermite polynomial H64.                       //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of H64.  This array   //
//                    should be dimensioned 64 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 64                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Zeros_64pts( z );                                        //
//     printf("The zeros of the Hermite polynomial H64 are:");                //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Zeros_64pts( double zeros[] ) {
   
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   double *pz = &zeros[NUM_OF_ZEROS - 1];

   for (; px >= x; px--)  {
      *(zeros++) = - *px;
      *(pz--) = *px;
   }   
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Coefs_64pts( double coef[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 64 point Gauss-Hermite formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Hermite formula.  This array should be dimensioned      //
//                    64 in the caller function.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 64                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Coefs_64pts( a );                                        //
//     printf("The coefficients for the Gauss-Hermite formula are:\n");       //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Coefs_64pts( double coef[]) {

   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];
   double *pc = &coef[NUM_OF_ZEROS - 1];

   for (; pA >= A; pA--)  {
      *(coef++) =  *pA;
      *(pc--) = *pA;
   }   
}
