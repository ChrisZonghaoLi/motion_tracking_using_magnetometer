////////////////////////////////////////////////////////////////////////////////
// File: gauss_hermite_6pts.c                                                 //
// Routines:                                                                  //
//    Gauss_Hermite_Integration_6pts                                          //
//    Gauss_Hermite_Zeros_6pts                                                //
//    Gauss_Hermite_Coefs_6pts                                                //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Hermite polynomial is                                             //
//              Hn(x) = (-1)^n exp(x^2) (d/dx)^n (exp(-x^2)).                 //
// For the n point Gauss-Hermite integral approximation formula the           //
// coefficients are:                                                          //
//              A[i] = 2^(n+1) (n!) sqrt(PI) /  (Hn'(x[i]))^2                 //
// where x[i] is a zero of the n-th Hermite polynomial Hn(x).                 //
// Note that if x is a zero of Hn(x) then -x is also a zero of Hn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    2.35060497367449222281e+00,    4.36077411927616508688e-01,
    1.33584907401369694976e+00
};

static const double A[] = {
    4.53000990550884564102e-03,    7.24629595224392524086e-01,
    1.57067320322856643914e-01
};

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Hermite_Integration_6pts( double (*f)(double) )              //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x^2) from -infinity to infinity  //
//     using the 6 point Gauss-Hermite integral approximation formula.        //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x^2) from -infinity to infinity.             //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Hermite_Integration_6pts( f );                     //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Hermite_Integration_6pts( double (*f)(double) ) {

   return A[2] * ( (*f)(x[2]) + (*f)(-x[2]) ) 
          + A[1] * ( (*f)(x[1]) + (*f)(-x[1]) )
          + A[0] * ( (*f)(x[0]) + (*f)(-x[0]) );
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Zeros_6pts( double zeros[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Hermite polynomial H6.                        //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of H6.  This array    //
//                    should be dimensioned 6 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 6                                                            //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Zeros_6pts( z );                                         //
//     printf("The zeros of the Hermite polynomial H6 are:");                 //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Zeros_6pts( double zeros[] ) {
   
   zeros[0] = -x[2];
   zeros[1] = -x[1];
   zeros[2] = -x[0];
   zeros[3] = x[0];
   zeros[4] = x[1];
   zeros[5] = x[2];

}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Coefs_6pts( double coef[] )                            //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 6 point Gauss-Hermite formula.        //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Hermite formula.  This array should be dimensioned      //
//                    6 in the caller function.                               //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 6                                                            //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Coefs_6pts( a );                                         //
//     printf("The coefficients for the Gauss-Hermite formula are:\n");       //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Coefs_6pts( double coef[]) {

   coef[0] = A[2];
   coef[1] = A[1];
   coef[2] = A[0];
   coef[3] = A[0];
   coef[4] = A[1];
   coef[5] = A[2];

}
