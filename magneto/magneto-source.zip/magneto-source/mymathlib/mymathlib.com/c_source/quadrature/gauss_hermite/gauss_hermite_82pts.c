////////////////////////////////////////////////////////////////////////////////
// File: gauss_hermite_82pts.c                                                //
// Routines:                                                                  //
//    Gauss_Hermite_Integration_82pts                                         //
//    Gauss_Hermite_Zeros_82pts                                               //
//    Gauss_Hermite_Coefs_82pts                                               //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Hermite polynomial is                                             //
//              Hn(x) = (-1)^n exp(x^2) (d/dx)^n (exp(-x^2)).                 //
// For the n point Gauss-Hermite integral approximation formula the           //
// coefficients are:                                                          //
//              A[i] = 2^(n+1) (n!) sqrt(PI) /  (Hn'(x[i]))^2                 //
// where x[i] is a zero of the n-th Hermite polynomial Hn(x).                 //
// Note that if x is a zero of Hn(x) then -x is also a zero of Hn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    1.22287052415183502338e-01,    3.66905509716544322773e-01,
    6.11657233887522951339e-01,    8.56631770590263170117e-01,
    1.10191972731836266175e+00,    1.34761321883768813584e+00,
    1.59380633403193116442e+00,    1.84059563130044817603e+00,
    2.08808067049728017430e+00,    2.33636459050951514251e+00,
    2.58555474300807424737e+00,    2.83576339474243220421e+00,
    3.08710851309726045993e+00,    3.33971465262399087566e+00,
    3.59371396409343349387e+00,    3.84924735254442742507e+00,
    4.10646581718094181527e+00,    4.36553201428424800766e+00,
    4.62662209524052595987e+00,    4.88992788630411521480e+00,
    5.15565949620915743362e+00,    5.42404846422571687917e+00,
    5.69535159771464492970e+00,    5.96985569915758935208e+00,
    6.24788345490697080578e+00,    6.52980086228887084132e+00,
    6.81602672545663811933e+00,    7.10704498189334518427e+00,
    7.40342097865113584615e+00,    7.70582338403797861056e+00,
    8.01505434820269320201e+00,    8.33209210142812257451e+00,
    8.65815296996017457528e+00,    8.99478498813142028807e+00,
    9.34401557074905216634e+00,    9.70859761697327883819e+00,
    1.00924496315566458258e+01,    1.05015206795032711813e+01,
    1.09457333485541227196e+01,    1.14443558512575136689e+01,
    1.20478703494694530281e+01
};

static const double A[] = {
    2.40951203198095223143e-01,    2.13853598983303619990e-01,
    1.68428879088137049795e-01,    1.17673485893413465593e-01,
    7.28912739247410517156e-02,    4.00038267230072289355e-02,
    1.94343371386422320448e-02,    8.34850909644662234132e-03,
    3.16708392713625997217e-03,    1.05942178985499535732e-03,
    3.11950032822506995878e-04,    8.06956297470312047444e-05,
    1.82974905313239979082e-05,    3.62754808874359256261e-06,
    6.27022268368288686471e-07,    9.41932450019690790983e-08,
    1.22539830471113735416e-08,    1.37507091164967957536e-09,
    1.32503112154254838828e-10,    1.09096131830447657017e-11,
    7.63199025102107315861e-13,    4.50784247187565999436e-14,
    2.23205938373381254198e-15,    9.19050965201856816419e-17,
    3.11798842540748020178e-18,    8.62453036093801258131e-20,
    1.92154314328891897297e-21,    3.40013527684468340304e-23,
    4.70002914989150542543e-25,    4.97703481347574391667e-27,
    3.94390875408377250565e-29,    2.27293036164592088382e-31,
    9.19636605056892148391e-34,    2.49814761148042486159e-36,
    4.29909710756091351874e-39,    4.33487612336982142192e-42,
    2.29448714341206829997e-45,    5.40793416076859581009e-49,
    4.33316281566699248824e-53,    7.06830406546372604269e-58,
    6.39008461793571129082e-64
};

#define NUM_OF_POSITIVE_ZEROS  sizeof(x) / sizeof(double)
#define NUM_OF_ZEROS           NUM_OF_POSITIVE_ZEROS+NUM_OF_POSITIVE_ZEROS


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Hermite_Integration_82pts( double (*f)(double) )             //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x^2) from -infinity to infinity  //
//     using the 82 point Gauss-Hermite integral approximation formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x^2) from -infinity to infinity.             //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Hermite_Integration_82pts( f );                    //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Hermite_Integration_82pts( double (*f)(double) ) {

   double integral = 0.0;
   const double *pA = &A[NUM_OF_POSITIVE_ZEROS];
   const double *px;

   for (px = &x[NUM_OF_POSITIVE_ZEROS - 1]; px >= x; px--) 
      integral += *(--pA) * ( (*f)(*px) + (*f)(- *px) );

   return integral;
};


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Zeros_82pts( double zeros[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Hermite polynomial H82.                       //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of H82.  This array   //
//                    should be dimensioned 82 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 82                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Zeros_82pts( z );                                        //
//     printf("The zeros of the Hermite polynomial H82 are:");                //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Zeros_82pts( double zeros[] ) {
   
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   double *pz = &zeros[NUM_OF_ZEROS - 1];

   for (; px >= x; px--)  {
      *(zeros++) = - *px;
      *(pz--) = *px;
   }   
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Coefs_82pts( double coef[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 82 point Gauss-Hermite formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Hermite formula.  This array should be dimensioned      //
//                    82 in the caller function.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 82                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Coefs_82pts( a );                                        //
//     printf("The coefficients for the Gauss-Hermite formula are:\n");       //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Coefs_82pts( double coef[]) {

   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];
   double *pc = &coef[NUM_OF_ZEROS - 1];

   for (; pA >= A; pA--)  {
      *(coef++) =  *pA;
      *(pc--) = *pA;
   }   
}
