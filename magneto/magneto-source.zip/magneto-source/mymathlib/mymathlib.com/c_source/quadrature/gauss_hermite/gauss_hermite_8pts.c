////////////////////////////////////////////////////////////////////////////////
// File: gauss_hermite_8pts.c                                                 //
// Routines:                                                                  //
//    Gauss_Hermite_Integration_8pts                                          //
//    Gauss_Hermite_Zeros_8pts                                                //
//    Gauss_Hermite_Coefs_8pts                                                //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Hermite polynomial is                                             //
//              Hn(x) = (-1)^n exp(x^2) (d/dx)^n (exp(-x^2)).                 //
// For the n point Gauss-Hermite integral approximation formula the           //
// coefficients are:                                                          //
//              A[i] = 2^(n+1) (n!) sqrt(PI) /  (Hn'(x[i]))^2                 //
// where x[i] is a zero of the n-th Hermite polynomial Hn(x).                 //
// Note that if x is a zero of Hn(x) then -x is also a zero of Hn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    3.81186990207322116844e-01,    1.15719371244678019474e+00,
    1.98165675669584292584e+00,    2.93063742025724401920e+00
};

static const double A[] = {
    6.61147012558241291042e-01,    2.07802325814891879546e-01,
    1.70779830074134754563e-02,    1.99604072211367619211e-04
};


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Hermite_Integration_8pts( double (*f)(double) )              //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x^2) from -infinitey to infinity //
//     using the 8 point Gauss-Hermite integral approximation formula.        //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x^2) from -infinity to infinity.             //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Hermite_Integration_8pts( f );                     //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Hermite_Integration_8pts( double (*f)(double) ) {

   return A[3] * ( (*f)(x[3]) + (*f)(-x[3]) ) 
          + A[2] * ( (*f)(x[2]) + (*f)(-x[2]) )
          + A[1] * ( (*f)(x[1]) + (*f)(-x[1]) )
          + A[0] * ( (*f)(x[0]) + (*f)(-x[0]) );
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Zeros_8pts( double zeros[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Hermite polynomial H8.                        //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of H8.  This array    //
//                    should be dimensioned 8 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 8                                                            //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Zeros_8pts( z );                                         //
//     printf("The zeros of the Hermite polynomial H8 are:");                 //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Zeros_8pts( double zeros[] ) {
   
   zeros[0] = -x[3];
   zeros[1] = -x[2];
   zeros[2] = -x[1];
   zeros[3] = -x[0];
   zeros[4] = x[0];
   zeros[5] = x[1];
   zeros[6] = x[2];
   zeros[7] = x[3];

}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Coefs_8pts( double coef[] )                            //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 8 point Gauss-Hermite formula.        //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Hermite formula.  This array should be dimensioned      //
//                    8 in the caller function.                               //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 8                                                            //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Coefs_8pts( a );                                         //
//     printf("The coefficients for the Gauss-Hermite formula are:\n");       //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Coefs_8pts( double coef[]) {

   coef[0] = A[3];
   coef[1] = A[2];
   coef[2] = A[1];
   coef[3] = A[0];
   coef[4] = A[0];
   coef[5] = A[1];
   coef[6] = A[2];
   coef[7] = A[3];

}
