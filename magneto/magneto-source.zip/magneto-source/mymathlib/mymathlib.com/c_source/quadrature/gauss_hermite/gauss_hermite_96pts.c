////////////////////////////////////////////////////////////////////////////////
// File: gauss_hermite_96pts.c                                                //
// Routines:                                                                  //
//    Gauss_Hermite_Integration_96pts                                         //
//    Gauss_Hermite_Zeros_96pts                                               //
//    Gauss_Hermite_Coefs_96pts                                               //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Hermite polynomial is                                             //
//              Hn(x) = (-1)^n exp(x^2) (d/dx)^n (exp(-x^2)).                 //
// For the n point Gauss-Hermite integral approximation formula the           //
// coefficients are:                                                          //
//              A[i] = 2^(n+1) (n!) sqrt(PI) /  (Hn'(x[i]))^2                 //
// where x[i] is a zero of the n-th Hermite polynomial Hn(x).                 //
// Note that if x is a zero of Hn(x) then -x is also a zero of Hn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    1.13068883151451946421e-01,    3.39236618878885243120e-01,
    5.65494366266748885608e-01,    7.91902478754016734359e-01,
    1.01852183194767990145e+00,    1.24541403990650804523e+00,
    1.47264167902270954171e+00,    1.70026852193835056025e+00,
    1.92835978414550247189e+00,    2.15698238619312850301e+00,
    2.38620523476977988491e+00,    2.61609952636238882401e+00,
    2.84673907772478276758e+00,    3.07820068804681866740e+00,
    3.31056453852430518977e+00,    3.54391463602731191483e+00,
    3.77833930879686283257e+00,    4.01393176362826890804e+00,
    4.25079071590318645444e+00,    4.48902110621699493341e+00,
    4.72873492035293060270e+00,    4.97005213316677252767e+00,
    5.21310180181896043027e+00,    5.45802334007078606814e+00,
    5.70496801352553525822e+00,    5.95410070641172624751e+00,
    6.20560202471831016740e+00,    6.45967081955512168129e+00,
    6.71652724049651896239e+00,    6.97641646428518134512e+00,
    7.23961329400835287970e+00,    7.50642789442775659184e+00,
    7.77721303106123821279e+00,    8.05237333071971172951e+00,
    8.33237730717005955095e+00,    8.61777324421474645502e+00,
    8.90921058145959803964e+00,    9.20746935337176082396e+00,
    9.51350176941242479684e+00,    9.82849274619171266437e+00,
    1.01539512747136877920e+01,    1.04918545392765389691e+01,
    1.08448880738535873916e+01,    1.12168751942021619047e+01,
    1.16136208288429136166e+01,    1.20448067411349224219e+01,
    1.25292307466835425196e+01,    1.31161300216628771654e+01
};

static const double A[] = {
    2.23270023497534760007e-01,    2.01613013479234257804e-01,
    1.64379630598497016616e-01,    1.20983116862515326862e-01,
    8.03539500806420774437e-02,    4.81399067310900534542e-02,
    2.60003402712444490590e-02,    1.26513751128001583598e-02,
    5.54163128943897673232e-03,    2.18313197609671826845e-03,
    7.72695821681651913569e-04,    2.45418092730526616094e-04,
    6.98543244454154097411e-05,    1.77918059182202897248e-05,
    4.04823317877725996959e-06,    8.21354454783280818544e-07,
    1.48296940500500707616e-07,    2.37736621475742852607e-08,
    3.37558473112770428999e-09,    4.23359378351102244001e-10,
    4.67601038598507062136e-11,    4.53330337458388819326e-12,
    3.84368172487662769128e-13,    2.83876739516933866536e-14,
    1.81816913049323348967e-15,    1.00490514915748563269e-16,
    4.76683117118660672753e-18,    1.92887932683713863579e-19,
    6.61295117648106714505e-21,    1.90626018868755028910e-22,
    4.58060109854991496536e-24,    9.08596564704883382254e-26,
    1.47124155497418206516e-27,    1.91997070679487862172e-29,
    1.98954689426952732129e-31,    1.60887320793845683419e-33,
    9.94680005922125919492e-36,    4.58740166585819497141e-38,
    1.53179896471119580945e-40,    3.56893856178100653724e-43,
    5.53706481978252549498e-46,    5.38322250697009700531e-49,
    3.02229393150211223153e-52,    8.73373283591902675773e-56,
    1.09338247375177853319e-59,    4.46870242168131830147e-64,
    3.48084138771818240130e-69,    1.31533714770105263645e-75
};

#define NUM_OF_POSITIVE_ZEROS  sizeof(x) / sizeof(double)
#define NUM_OF_ZEROS           NUM_OF_POSITIVE_ZEROS+NUM_OF_POSITIVE_ZEROS


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Hermite_Integration_96pts( double (*f)(double) )             //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x^2) from -infinity to infinity  //
//     using the 96 point Gauss-Hermite integral approximation formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x^2) from -infinity to infinity.             //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Hermite_Integration_96pts( f );                    //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Hermite_Integration_96pts( double (*f)(double) ) {

   double integral = 0.0;
   const double *pA = &A[NUM_OF_POSITIVE_ZEROS];
   const double *px;

   for (px = &x[NUM_OF_POSITIVE_ZEROS - 1]; px >= x; px--) 
      integral += *(--pA) * ( (*f)(*px) + (*f)(- *px) );

   return integral;
};


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Zeros_96pts( double zeros[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Hermite polynomial H96.                       //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of H96.  This array   //
//                    should be dimensioned 96 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 96                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Zeros_96pts( z );                                        //
//     printf("The zeros of the Hermite polynomial H96 are:");                //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Zeros_96pts( double zeros[] ) {
   
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   double *pz = &zeros[NUM_OF_ZEROS - 1];

   for (; px >= x; px--)  {
      *(zeros++) = - *px;
      *(pz--) = *px;
   }   
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Coefs_96pts( double coef[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 96 point Gauss-Hermite formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Hermite formula.  This array should be dimensioned      //
//                    96 in the caller function.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 96                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Coefs_96pts( a );                                        //
//     printf("The coefficients for the Gauss-Hermite formula are:\n");       //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Coefs_96pts( double coef[]) {

   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];
   double *pc = &coef[NUM_OF_ZEROS - 1];

   for (; pA >= A; pA--)  {
      *(coef++) =  *pA;
      *(pc--) = *pA;
   }   
}
