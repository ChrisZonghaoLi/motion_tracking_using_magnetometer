////////////////////////////////////////////////////////////////////////////////
// File: gauss_hermite_9pts.c                                                 //
// Routines:                                                                  //
//    Gauss_Hermite_Integration_9pts                                          //
//    Gauss_Hermite_Zeros_9pts                                                //
//    Gauss_Hermite_Coefs_9pts                                                //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Hermite polynomial is                                             //
//              Hn(x) = (-1)^n exp(x^2) (d/dx)^n (exp(-x^2)).                 //
// For the n point Gauss-Hermite integral approximation formula the           //
// coefficients are:                                                          //
//              A[i] = 2^(n+1) (n!) sqrt(PI) /  (Hn'(x[i]))^2                 //
// where x[i] is a zero of the n-th Hermite polynomial Hn(x).                 //
// Note that if x is a zero of Hn(x) then -x is also a zero of Hn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    0.00000000000000000000e+00,    7.23551018752837573310e-01,
    1.46855328921666793162e+00,    2.26658058453184311186e+00,
    3.19099320178152760720e+00
};

static const double A[] = {
    7.20235215606050957103e-01,    4.32651559002555750189e-01,
    8.84745273943765732897e-02,    4.94362427553694721706e-03,
    3.96069772632643819050e-05
};


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Hermite_Integration_9pts( double (*f)(double) )              //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x^2) from -infinity to infinity  //
//     using the 9 point Gauss-Hermite integral approximation formula.        //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x^2) from -infinity to infinity.             //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Hermite_Integration_9pts( f );                     //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Hermite_Integration_9pts( double (*f)(double) ) {

   return A[4] * ( (*f)(x[4]) + (*f)(-x[4]) ) 
          + A[3] * ( (*f)(x[3]) + (*f)(-x[3]) )
          + A[2] * ( (*f)(x[2]) + (*f)(-x[2]) )
          + A[1] * ( (*f)(x[1]) + (*f)(-x[1]) )
          + A[0] *  (*f)(x[0]);
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Zeros_9pts( double zeros[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Hermite polynomial H9.                        //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of H9.  This array    //
//                    should be dimensioned 9 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 9                                                            //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Zeros_9pts( z );                                         //
//     printf("The zeros of the Hermite polynomial H9 are:");                 //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Zeros_9pts( double zeros[] ) {
   
   zeros[0] = -x[4];
   zeros[1] = -x[3];
   zeros[2] = -x[2];
   zeros[3] = -x[1];
   zeros[4] = x[0];
   zeros[5] = x[1];
   zeros[6] = x[2];
   zeros[7] = x[3];
   zeros[8] = x[4];

}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Hermite_Coefs_9pts( double coef[] )                            //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 9 point Gauss-Hermite formula.        //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Hermite formula.  This array should be dimensioned      //
//                    9 in the caller function.                               //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 9                                                            //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Hermite_Coefs_9pts( a );                                         //
//     printf("The coefficients for the Gauss-Hermite formula are:\n");       //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Hermite_Coefs_9pts( double coef[]) {

   coef[0] = A[4];
   coef[1] = A[3];
   coef[2] = A[2];
   coef[3] = A[1];
   coef[4] = A[0];
   coef[5] = A[1];
   coef[6] = A[2];
   coef[7] = A[3];
   coef[8] = A[4];

}
