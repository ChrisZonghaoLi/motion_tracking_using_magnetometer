////////////////////////////////////////////////////////////////////////////////
// File: gauss_laguerre_12pts.c                                               //
// Routines:                                                                  //
//    Gauss_Laguerre_Integration_12pts                                        //
//    Gauss_Laguerre_Zeros_12pts                                              //
//    Gauss_Laguerre_Coefs_12pts                                              //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// For n = 12 the zeros of the Laguerre polynomial                            //
//                 Ln(x) = exp(x) (d/dx)^n (x^n exp(-x))                      //
// are given in the array x below and the coefficients                        //
//                 A[i] = (n!)^2 / ( x[i] (Ln'(x[i]))^2 )                     //
// are given in the array A.                                                  //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    1.15722117358020675267e-01,    6.11757484515130665371e-01,
    1.51261026977641878681e+00,    2.83375133774350722858e+00,
    4.59922763941834848462e+00,    6.84452545311517734786e+00,
    9.62131684245686704358e+00,    1.30060549933063477205e+01,
    1.71168551874622557277e+01,    2.21510903793970056700e+01,
    2.84879672509840003117e+01,    3.70991210444669203376e+01
};

static const double A[] = {
    2.64731371055443190344e-01,    3.77759275873137982026e-01,
    2.44082011319877564251e-01,    9.04492222116809307247e-02,
    2.01023811546340965218e-02,    2.66397354186531588103e-03,
    2.03231592662999392117e-04,    8.36505585681979874511e-06,
    1.66849387654091026123e-07,    1.34239103051500414548e-09,
    3.06160163503502078133e-12,    8.14807746742624168225e-16
};

#define NUM_OF_ZEROS  sizeof(x)/sizeof(double)

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Laguerre_Integration_12pts( double (*f)(double) )            //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x) from 0 to infinity using the  //
//     12 point Gauss-Laguerre integral approximation formula.                //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x) from 0 to infinity.                       //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Laguerre_Integration_12pts( f );                   //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Laguerre_Integration_12pts( double (*f)(double) ) {

   double integral = 0.0;
   const double *px = &x[NUM_OF_ZEROS - 1];
   const double *pA = &A[NUM_OF_ZEROS - 1];

   for (; px >= x; pA--, px--) integral += *pA * (*f)(*px);

   return integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Zeros_12pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the 12th Laguerre polynomial L12.                 //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of L12.  This array   //
//                    should be dimensioned 12 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 12                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Zeros_12pts( z );                                       //
//     printf("The zeros of the Laguerre polynomial L12 are:");               //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Zeros_12pts( double zeros[] ) {
   
   const double *pz = x;

   for (; pz < x + NUM_OF_ZEROS; pz++) *(zeros++) = *pz;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Coefs_12pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 12 point Gauss-Laguerre formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Laguerre formula.  This array should be dimensioned     //
//                    12 in the caller function.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 12                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Coefs_12pts( a );                                       //
//     printf("The coefficients for the Gauss-Laguerre formula are:\n");      //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Coefs_12pts( double coef[]) {

   const double *pA = A;

   for (; pA < A + NUM_OF_ZEROS; pA++) *(coef++) = *pA;
}
