////////////////////////////////////////////////////////////////////////////////
// File: gauss_laguerre_16pts.c                                               //
// Routines:                                                                  //
//    Gauss_Laguerre_Integration_16pts                                        //
//    Gauss_Laguerre_Zeros_16pts                                              //
//    Gauss_Laguerre_Coefs_16pts                                              //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// For n = 16 the zeros of the Laguerre polynomial                            //
//                 Ln(x) = exp(x) (d/dx)^n (x^n exp(-x))                      //
// are given in the array x below and the coefficients                        //
//                 A[i] = (n!)^2 / ( x[i] (Ln'(x[i]))^2 )                     //
// are given in the array A.                                                  //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    8.76494104789278403585e-02,    4.62696328915080831869e-01,
    1.14105777483122685690e+00,    2.12928364509838061636e+00,
    3.43708663389320664516e+00,    5.07801861454976791307e+00,
    7.07033853504823413044e+00,    9.43831433639193878408e+00,
    1.22142233688661587367e+01,    1.54415273687816170765e+01,
    1.91801568567531348555e+01,    2.35159056939919085313e+01,
    2.85787297428821403678e+01,    3.45833987022866258150e+01,
    4.19404526476883326366e+01,    5.17011603395433183630e+01
};

static const double A[] = {
    2.06151714957800994329e-01,    3.31057854950884165987e-01,
    2.65795777644214152612e-01,    1.36296934296377539981e-01,
    4.73289286941252189778e-02,    1.12999000803394532309e-02,
    1.84907094352631086430e-03,    2.04271915308278460131e-04,
    1.48445868739812987713e-05,    6.82831933087119956441e-07,
    1.88102484107967321393e-08,    2.86235024297388161972e-10,
    2.12707903322410296738e-12,    6.29796700251786778703e-15,
    5.05047370003551282048e-18,    4.16146237037285519041e-22
};

#define NUM_OF_ZEROS  sizeof(x)/sizeof(double)

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Laguerre_Integration_16pts( double (*f)(double) )            //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x) from 0 to infinity using the  //
//     16 point Gauss-Laguerre integral approximation formula.                //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x) from 0 to infinity.                       //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Laguerre_Integration_16pts( f );                   //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Laguerre_Integration_16pts( double (*f)(double) ) {

   double integral = 0.0;
   const double *px = &x[NUM_OF_ZEROS - 1];
   const double *pA = &A[NUM_OF_ZEROS - 1];

   for (; px >= x; pA--, px--) integral += *pA * (*f)(*px);

   return integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Zeros_16pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the 16th Laguerre polynomial L16.                 //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of L16.  This array   //
//                    should be dimensioned 16 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 16                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Zeros_16pts( z );                                       //
//     printf("The zeros of the Laguerre polynomial L16 are:");               //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Zeros_16pts( double zeros[] ) {
   
   const double *pz = x;

   for (; pz < x + NUM_OF_ZEROS; pz++) *(zeros++) = *pz;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Coefs_16pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 16 point Gauss-Laguerre formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Laguerre formula.  This array should be dimensioned     //
//                    16 in the caller function.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 16                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Coefs_16pts( a );                                       //
//     printf("The coefficients for the Gauss-Laguerre formula are:\n");      //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Coefs_16pts( double coef[]) {

   const double *pA = A;

   for (; pA < A + NUM_OF_ZEROS; pA++) *(coef++) = *pA;
}
