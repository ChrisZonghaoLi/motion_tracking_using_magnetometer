////////////////////////////////////////////////////////////////////////////////
// File: gauss_laguerre_20pts.c                                               //
// Routines:                                                                  //
//    Gauss_Laguerre_Integration_20pts                                        //
//    Gauss_Laguerre_Zeros_20pts                                              //
//    Gauss_Laguerre_Coefs_20pts                                              //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// For n = 20 the zeros of the Laguerre polynomial                            //
//                 Ln(x) = exp(x) (d/dx)^n (x^n exp(-x))                      //
// are given in the array x below and the coefficients                        //
//                 A[i] = (n!)^2 / ( x[i] (Ln'(x[i]))^2 )                     //
// are given in the array A.                                                  //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    7.05398896919887533682e-02,    3.72126818001611443803e-01,
    9.16582102483273564685e-01,    1.70730653102834388068e+00,
    2.74919925530943212960e+00,    4.04892531385088692234e+00,
    5.61517497086161651403e+00,    7.45901745367106330971e+00,
    9.59439286958109677217e+00,    1.20388025469643163094e+01,
    1.48142934426307399786e+01,    1.79488955205193760171e+01,
    2.14787882402850109752e+01,    2.54517027931869055032e+01,
    2.99325546317006120061e+01,    3.50134342404790000064e+01,
    4.08330570567285710618e+01,    4.76199940473465021390e+01,
    5.58107957500638988922e+01,    6.65244165256157538174e+01
};

static const double A[] = {
    1.68746801851113862149e-01,    2.91254362006068281716e-01,
    2.66686102867001288545e-01,    1.66002453269506840034e-01,
    7.48260646687923705370e-02,    2.49644173092832210726e-02,
    6.20255084457223684727e-03,    1.14496238647690824205e-03,
    1.55741773027811974783e-04,    1.54014408652249156900e-05,
    1.08648636651798235146e-06,    5.33012090955671475102e-08,
    1.75798117905058200358e-09,    3.72550240251232087264e-11,
    4.76752925157819052460e-13,    3.37284424336243841240e-15,
    1.15501433950039883097e-17,    1.53952214058234355342e-20,
    5.28644272556915782871e-24,    1.65645661249902329595e-28
};

#define NUM_OF_ZEROS  sizeof(x)/sizeof(double)

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Laguerre_Integration_20pts( double (*f)(double) )            //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x) from 0 to infinity using the  //
//     20 point Gauss-Laguerre integral approximation formula.                //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x) from 0 to infinity.                       //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Laguerre_Integration_20pts( f );                   //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Laguerre_Integration_20pts( double (*f)(double) ) {

   double integral = 0.0;
   const double *px = &x[NUM_OF_ZEROS - 1];
   const double *pA = &A[NUM_OF_ZEROS - 1];

   for (; px >= x; pA--, px--) integral += *pA * (*f)(*px);

   return integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Zeros_20pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the 20th Laguerre polynomial L20.                 //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of L20.  This array   //
//                    should be dimensioned 20 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 20                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Zeros_20pts( z );                                       //
//     printf("The zeros of the Laguerre polynomial L20 are:");               //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Zeros_20pts( double zeros[] ) {
   
   const double *pz = x;

   for (; pz < x + NUM_OF_ZEROS; pz++) *(zeros++) = *pz;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Coefs_20pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 20 point Gauss-Laguerre formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Laguerre formula.  This array should be dimensioned     //
//                    20 in the caller function.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 20                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Coefs_20pts( a );                                       //
//     printf("The coefficients for the Gauss-Laguerre formula are:\n");      //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Coefs_20pts( double coef[]) {

   const double *pA = A;

   for (; pA < A + NUM_OF_ZEROS; pA++) *(coef++) = *pA;
}
