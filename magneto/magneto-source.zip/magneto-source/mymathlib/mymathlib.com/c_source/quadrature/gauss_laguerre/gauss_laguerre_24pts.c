////////////////////////////////////////////////////////////////////////////////
// File: gauss_laguerre_24pts.c                                               //
// Routines:                                                                  //
//    Gauss_Laguerre_Integration_24pts                                        //
//    Gauss_Laguerre_Zeros_24pts                                              //
//    Gauss_Laguerre_Coefs_24pts                                              //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// For n = 24 the zeros of the Laguerre polynomial                            //
//                 Ln(x) = exp(x) (d/dx)^n (x^n exp(-x))                      //
// are given in the array x below and the coefficients                        //
//                 A[i] = (n!)^2 / ( x[i] (Ln'(x[i]))^2 )                     //
// are given in the array A.                                                  //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    5.90198521815079769739e-02,    3.11239146198483726850e-01,
    7.66096905545936646261e-01,    1.42559759080361308635e+00,
    2.29256205863219029496e+00,    3.37077426420899771615e+00,
    4.66508370346717079211e+00,    6.18153511873676541179e+00,
    7.92753924717215217952e+00,    9.91209801507770601851e+00,
    1.21461027117297655498e+01,    1.46427322895966743419e+01,
    1.74179926465089787262e+01,    2.04914600826164247076e+01,
    2.38873298481697331746e+01,    2.76359371743327174205e+01,
    3.17760413523747232891e+01,    3.63584058016516216520e+01,
    4.14517204848707670507e+01,    4.71531064451563230421e+01,
    5.36085745446950698231e+01,    6.10585314472187615648e+01,
    6.99622400351050304293e+01,    8.14982792339488853750e+01
};

static const double A[] = {
    1.42811973334781851087e-01,    2.58774107517423902671e-01,
    2.58806707272869802021e-01,    1.83322688977778024900e-01,
    9.81662726299188921909e-02,    4.07324781514086460259e-02,
    1.32260194051201566876e-02,    3.36934905847830355197e-03,
    6.72162564093547889971e-04,    1.04461214659275180474e-04,
    1.25447219779933332069e-05,    1.15131581273727991985e-06,
    7.96081295913363025727e-08,    4.07285898754999966522e-09,
    1.50700822629258491643e-10,    3.91773651505845138514e-12,
    6.89418105295808568594e-14,    7.81980038245944846907e-16,
    5.35018881301003760279e-18,    2.01051746455550347083e-20,
    3.60576586455295903895e-23,    2.45181884587840268905e-26,
    4.08830159368065782307e-30,    5.57534578832835675306e-35
};

#define NUM_OF_ZEROS  sizeof(x)/sizeof(double)

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Laguerre_Integration_24pts( double (*f)(double) )            //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x) from 0 to infinity using the  //
//     24 point Gauss-Laguerre integral approximation formula.                //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x) from 0 to infinity.                       //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Laguerre_Integration_24pts( f );                   //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Laguerre_Integration_24pts( double (*f)(double) ) {

   double integral = 0.0;
   const double *px = &x[NUM_OF_ZEROS - 1];
   const double *pA = &A[NUM_OF_ZEROS - 1];

   for (; px >= x; pA--, px--) integral += *pA * (*f)(*px);

   return integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Zeros_24pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the 24th Laguerre polynomial L24.                 //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of L24.  This array   //
//                    should be dimensioned 24 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 24                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Zeros_24pts( z );                                       //
//     printf("The zeros of the Laguerre polynomial L24 are:");               //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Zeros_24pts( double zeros[] ) {
   
   const double *pz = x;

   for (; pz < x + NUM_OF_ZEROS; pz++) *(zeros++) = *pz;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Coefs_24pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 24 point Gauss-Laguerre formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Laguerre formula.  This array should be dimensioned     //
//                    24 in the caller function.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 24                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Coefs_24pts( a );                                       //
//     printf("The coefficients for the Gauss-Laguerre formula are:\n");      //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Coefs_24pts( double coef[]) {

   const double *pA = A;

   for (; pA < A + NUM_OF_ZEROS; pA++) *(coef++) = *pA;
}
