////////////////////////////////////////////////////////////////////////////////
// File: gauss_laguerre_28pts.c                                               //
// Routines:                                                                  //
//    Gauss_Laguerre_Integration_28pts                                        //
//    Gauss_Laguerre_Zeros_28pts                                              //
//    Gauss_Laguerre_Coefs_28pts                                              //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// For n = 28 the zeros of the Laguerre polynomial                            //
//                 Ln(x) = exp(x) (d/dx)^n (x^n exp(-x))                      //
// are given in the array x below and the coefficients                        //
//                 A[i] = (n!)^2 / ( x[i] (Ln'(x[i]))^2 )                     //
// are given in the array A.                                                  //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    5.07346248498738875935e-02,    2.67487268640741084280e-01,
    6.58136628354791519354e-01,    1.22397180838490771864e+00,
    1.96676761247377769983e+00,    2.88888332603032189287e+00,
    3.99331165925011413623e+00,    5.28373606284344256301e+00,
    6.76460340424350515523e+00,    8.44121632827132448856e+00,
    1.03198504629932601038e+01,    1.24079034144606717384e+01,
    1.47140851641357488129e+01,    1.72486634156080562673e+01,
    2.00237833299517127509e+01,    2.30538901350302959711e+01,
    2.63562973744013176198e+01,    2.99519668335961821090e+01,
    3.38666055165844592130e+01,    3.81322544101946467772e+01,
    4.27896723707725762688e+01,    4.78920716336227436719e+01,
    5.35112979596642942062e+01,    5.97487960846412408215e+01,
    6.67569772839064695530e+01,    7.47867781523391618320e+01,
    8.43178371072270430586e+01,    9.65824206275273190805e+01
};

static const double A[] = {
    1.23778843954286426616e-01,    2.32279276900901161443e-01,
    2.47511896036477211861e-01,    1.92307113132382826676e-01,
    1.16405361721130006457e-01,    5.63459053644773065168e-02,
    2.20663643262588078584e-02,    7.02588763558386773332e-03,
    1.82060789269585486750e-03,    3.83344303857123176591e-04,
    6.53508708069439830812e-05,    8.97136205341076834436e-06,
    9.84701225624928886962e-07,    8.56407585267304244588e-08,
    5.83683876313834429079e-09,    3.07563887784230228349e-10,
    1.23259095272442282019e-11,    3.68217367410831200295e-13,
    7.99879057596890965227e-15,    1.22492250032408341097e-16,
    1.27112429503067373632e-18,    8.48859336768654319938e-21,
    3.40245537942551184729e-23,    7.42015658886748513242e-26,
    7.60041320580173769388e-29,    2.87391031794039581418e-32,
    2.54182290388931800438e-36,    1.66137587802903396104e-41
};

#define NUM_OF_ZEROS  sizeof(x)/sizeof(double)

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Laguerre_Integration_28pts( double (*f)(double) )            //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x) from 0 to infinity using the  //
//     28 point Gauss-Laguerre integral approximation formula.                //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x) from 0 to infinity.                       //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Laguerre_Integration_28pts( f );                   //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Laguerre_Integration_28pts( double (*f)(double) ) {

   double integral = 0.0;
   const double *px = &x[NUM_OF_ZEROS - 1];
   const double *pA = &A[NUM_OF_ZEROS - 1];

   for (; px >= x; pA--, px--) integral += *pA * (*f)(*px);

   return integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Zeros_28pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the 28th Laguerre polynomial L28.                 //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of L28.  This array   //
//                    should be dimensioned 28 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 28                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Zeros_28pts( z );                                       //
//     printf("The zeros of the Laguerre polynomial L28 are:");               //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Zeros_28pts( double zeros[] ) {
   
   const double *pz = x;

   for (; pz < x + NUM_OF_ZEROS; pz++) *(zeros++) = *pz;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Coefs_28pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 28 point Gauss-Laguerre formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Laguerre formula.  This array should be dimensioned     //
//                    28 in the caller function.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 28                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Coefs_28pts( a );                                       //
//     printf("The coefficients for the Gauss-Laguerre formula are:\n");      //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Coefs_28pts( double coef[]) {

   const double *pA = A;

   for (; pA < A + NUM_OF_ZEROS; pA++) *(coef++) = *pA;
}
