////////////////////////////////////////////////////////////////////////////////
// File: gauss_laguerre_32pts.c                                               //
// Routines:                                                                  //
//    Gauss_Laguerre_Integration_32pts                                        //
//    Gauss_Laguerre_Zeros_32pts                                              //
//    Gauss_Laguerre_Coefs_32pts                                              //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// For n = 32 the zeros of the Laguerre polynomial                            //
//                 Ln(x) = exp(x) (d/dx)^n (x^n exp(-x))                      //
// are given in the array x below and the coefficients                        //
//                 A[i] = (n!)^2 / ( x[i] (Ln'(x[i]))^2 )                     //
// are given in the array A.                                                  //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    4.44893658332670184200e-02,    2.34526109519618537454e-01,
    5.76884629301886426515e-01,    1.07244875381781763302e+00,
    1.72240877644464544110e+00,    2.52833670642579488104e+00,
    3.49221327302199448955e+00,    4.61645676974976738784e+00,
    5.90395850417424394646e+00,    7.35812673318624111329e+00,
    8.98294092421259610364e+00,    1.07830186325399720671e+01,
    1.27636979867427251146e+01,    1.49311397555225573199e+01,
    1.72924543367153147888e+01,    1.98558609403360547402e+01,
    2.26308890131967744893e+01,    2.56286360224592477675e+01,
    2.88621018163234747435e+01,    3.23466291539647370044e+01,
    3.61004948057519738057e+01,    4.01457197715394415345e+01,
    4.45092079957549379768e+01,    4.92243949873086391773e+01,
    5.43337213333969073319e+01,    5.98925091621340181976e+01,
    6.59753772879350527947e+01,    7.26876280906627086353e+01,
    8.01874469779135230704e+01,    8.87353404178923986928e+01,
    9.88295428682839725565e+01,    1.11751398097937695214e+02
};

static const double A[] = {
    1.09218341952384971133e-01,    2.10443107938813232942e-01,
    2.35213229669848005392e-01,    1.95903335972881043417e-01,
    1.29983786286071760605e-01,    7.05786238657174415609e-02,
    3.17609125091750703049e-02,    1.19182148348385570565e-02,
    3.73881629461152478964e-03,    9.80803306614955132219e-04,
    2.14864918801364188024e-04,    3.92034196798794720427e-05,
    5.93454161286863287823e-06,    7.41640457866755221906e-07,
    7.60456787912078148089e-08,    6.35060222662580674256e-09,
    4.28138297104092887872e-10,    2.30589949189133607924e-11,
    9.79937928872709406373e-13,    3.23780165772926646240e-14,
    8.17182344342071943308e-16,    1.54213383339382337221e-17,
    2.11979229016361861207e-19,    2.05442967378804542667e-21,
    1.34698258663739515582e-23,    5.66129413039735937094e-26,
    1.41856054546303690591e-28,    1.91337549445422430932e-31,
    1.19224876009822235656e-34,    2.67151121924013698611e-38,
    1.33861694210625628269e-42,    4.51053619389897423234e-48
};

#define NUM_OF_ZEROS  sizeof(x)/sizeof(double)


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Laguerre_Integration_32pts( double (*f)(double) )            //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x) from 0 to infinity using the  //
//     32 point Gauss-Laguerre integral approximation formula.                //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x) from 0 to infinity.                       //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Laguerre_Integration_32pts( f );                   //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Laguerre_Integration_32pts( double (*f)(double) ) {

   double integral = 0.0;
   const double *px = &x[NUM_OF_ZEROS - 1];
   const double *pA = &A[NUM_OF_ZEROS - 1];

   for (; px >= x; pA--, px--) integral += *pA * (*f)(*px);

   return integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Zeros_32pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the 32th Laguerre polynomial L32.                 //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of L32.  This array   //
//                    should be dimensioned 32 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 32                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Zeros_32pts( z );                                       //
//     printf("The zeros of the Laguerre polynomial L32 are:");               //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Zeros_32pts( double zeros[] ) {
   
   const double *pz = x;

   for (; pz < x + NUM_OF_ZEROS; pz++) *(zeros++) = *pz;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Coefs_32pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 32 point Gauss-Laguerre formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Laguerre formula.  This array should be dimensioned     //
//                    32 in the caller function.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 32                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Coefs_32pts( a );                                       //
//     printf("The coefficients for the Gauss-Laguerre formula are:\n");      //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Coefs_32pts( double coef[]) {

   const double *pA = A;

   for (; pA < A + NUM_OF_ZEROS; pA++) *(coef++) = *pA;
}
