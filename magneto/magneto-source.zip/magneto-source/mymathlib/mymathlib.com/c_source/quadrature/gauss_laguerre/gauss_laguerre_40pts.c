////////////////////////////////////////////////////////////////////////////////
// File: gauss_laguerre_40pts.c                                               //
// Routines:                                                                  //
//    Gauss_Laguerre_Integration_40pts                                        //
//    Gauss_Laguerre_Zeros_40pts                                              //
//    Gauss_Laguerre_Coefs_40pts                                              //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// For n = 40 the zeros of the Laguerre polynomial                            //
//                 Ln(x) = exp(x) (d/dx)^n (x^n exp(-x))                      //
// are given in the array x below and the coefficients                        //
//                 A[i] = (n!)^2 / ( x[i] (Ln'(x[i]))^2 )                     //
// are given in the array A.                                                  //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    3.57003943088883851218e-02,    1.88162283158698516000e-01,
    4.62694281314576453574e-01,    8.59772963972934922282e-01,
    1.38001082052733718654e+00,    2.02420913592282673355e+00,
    2.79336935350681645775e+00,    3.68870267790827020956e+00,
    4.71164114655497269371e+00,    5.86385087834371811428e+00,
    7.14724790810228825062e+00,    8.56401701758616376234e+00,
    1.01166340484519394066e+01,    1.18078922940045848424e+01,
    1.36409337125370872280e+01,    1.56192858933390738372e+01,
    1.77469059500956630425e+01,    2.00282328345748905293e+01,
    2.24682499834984183516e+01,    2.50725607724262037936e+01,
    2.78474800091688627201e+01,    3.08001457394454627014e+01,
    3.39386570849137196096e+01,    3.72722458804760043288e+01,
    4.08114928238869204662e+01,    4.45686031753344627064e+01,
    4.85577635330599922808e+01,    5.27956111872169329691e+01,
    5.73018633233936274946e+01,    6.21001790727751116113e+01,
    6.72193709271269988006e+01,    7.26951588476124621191e+01,
    7.85728029115713092825e+01,    8.49112311357049845406e+01,
    9.17898746712363769948e+01,    9.93208087174468082503e+01,
    1.07672440639388272518e+02,    1.17122309512690688807e+02,
    1.28201841988255651195e+02,    1.42280044469159997894e+02
};

static const double A[] = {
    8.84121061903424409429e-02,    1.76814739095722295607e-01,
    2.11363117015962431031e-01,    1.94081195318601799657e-01,
    1.46434282424125114414e-01,    9.33267984357708805097e-02,
    5.09322043610442370268e-02,    2.39761930156848418401e-02,
    9.77462524671445961921e-03,    3.45793999301848686123e-03,
    1.06224689389687193499e-03,    2.83271685324324715827e-04,
    6.55094050032462927979e-05,    1.31160690732677841246e-05,
    2.26845287877936505445e-06,    3.37962648220067921077e-07,
    4.32282132228208856884e-08,    4.72849377099077932786e-09,
    4.40317410423284881300e-10,    3.47244148480382248562e-11,
    2.30538154491682216163e-12,    1.27977259767663560723e-13,
    5.89417717235115294457e-15,    2.23221757990457741835e-16,
    6.88033648428430234090e-18,    1.70560373681808674851e-19,
    3.35371194066618293545e-21,    5.14619956013667914094e-23,
    6.04476251158766328891e-25,    5.31058477732133075276e-27,
    3.39252805328052189618e-29,    1.52173549318145699750e-31,
    4.58529161450268691755e-34,    8.76215865748624856084e-37,
    9.82741572514793330586e-40,    5.80115201916977910847e-43,
    1.53090868460668685356e-46,    1.38198630564932809972e-50,
    2.56663360501237218388e-55,    2.70036094021703364053e-61
};

#define NUM_OF_ZEROS  sizeof(x)/sizeof(double)


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Laguerre_Integration_40pts( double (*f)(double) )            //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x) from 0 to infinity using the  //
//     40 point Gauss-Laguerre integral approximation formula.                //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x) from 0 to infinity.                       //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Laguerre_Integration_40pts( f );                   //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Laguerre_Integration_40pts( double (*f)(double) ) {

   double integral = 0.0;
   const double *px = &x[NUM_OF_ZEROS - 1];
   const double *pA = &A[NUM_OF_ZEROS - 1];

   for (; px >= x; pA--, px--) integral += *pA * (*f)(*px);

   return integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Zeros_40pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the 40th Laguerre polynomial L40.                 //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of L40.  This array   //
//                    should be dimensioned 40 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 40                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Zeros_40pts( z );                                       //
//     printf("The zeros of the Laguerre polynomial L40 are:");               //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Zeros_40pts( double zeros[] ) {
   
   const double *pz = x;

   for (; pz < x + NUM_OF_ZEROS; pz++) *(zeros++) = *pz;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Coefs_40pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 40 point Gauss-Laguerre formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Laguerre formula.  This array should be dimensioned     //
//                    40 in the caller function.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 40                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Coefs_40pts( a );                                       //
//     printf("The coefficients for the Gauss-Laguerre formula are:\n");      //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Coefs_40pts( double coef[]) {

   const double *pA = A;

   for (; pA < A + NUM_OF_ZEROS; pA++) *(coef++) = *pA;
}
