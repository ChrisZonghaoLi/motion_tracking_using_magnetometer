////////////////////////////////////////////////////////////////////////////////
// File: gauss_laguerre_48pts.c                                               //
// Routines:                                                                  //
//    Gauss_Laguerre_Integration_48pts                                        //
//    Gauss_Laguerre_Zeros_48pts                                              //
//    Gauss_Laguerre_Coefs_48pts                                              //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// For n = 48 the zeros of the Laguerre polynomial                            //
//                 Ln(x) = exp(x) (d/dx)^n (x^n exp(-x))                      //
// are given in the array x below and the coefficients                        //
//                 A[i] = (n!)^2 / ( x[i] (Ln'(x[i]))^2 )                     //
// are given in the array A.                                                  //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    2.98112358299601106829e-02,    1.57107990617876302223e-01,
    3.86265037576455586433e-01,    7.17574694116972254597e-01,
    1.15139383402643463977e+00,    1.68818582341904720591e+00,
    2.32852700665322873337e+00,    3.07311086165263883585e+00,
    3.92275241304648049400e+00,    4.87839335592134610902e+00,
    5.94110805462455896864e+00,    7.11211053589074335395e+00,
    8.39276259909122462552e+00,    9.78458318468732328281e+00,
    1.12892591680095271461e+01,    1.29086577782855308951e+01,
    1.46448408832097058214e+01,    1.65000814289645861329e+01,
    1.84768823868741128170e+01,    2.05779986340222095040e+01,
    2.28064622905213716612e+01,    2.51656121564391080069e+01,
    2.76591280444805295950e+01,    3.02910710010085672383e+01,
    3.30659306624987441685e+01,    3.59886813274789357821e+01,
    3.90648487641977701819e+01,    4.23005903629030935824e+01,
    4.57027920385114703669e+01,    4.92791863828367928610e+01,
    5.30384980878166647257e+01,    5.69906248148044758256e+01,
    6.11468647861402287494e+01,    6.55202069290186065245e+01,
    7.01257062361131915523e+01,    7.49809775189113105892e+01,
    8.01068573503243938003e+01,    8.55283111160341678880e+01,
    9.12757079936680894502e+01,    9.73866677135815318328e+01,
    1.03908833357176254672e+02,    1.10904220884976275494e+02,
    1.18456425046283632022e+02,    1.26683425768885830932e+02,
    1.35762589577864301968e+02,    1.45986432709463454696e+02,
    1.57915612022977989520e+02,    1.72996328148563253496e+02
};

static const double A[] = {
    7.42620058280262437743e-02,    1.52271949809352811497e-01,
    1.90409088263911427700e-01,    1.86633059484805941425e-01,
    1.53424200157578299744e-01,    1.08779692807490252554e-01,
    6.74607386092194627033e-02,    3.68811941158212102755e-02,
    1.78568442691567195571e-02,    7.67761651449760892394e-03,
    2.93578590373947346710e-03,    9.99065537815885804089e-04,
    3.02598016992258427096e-04,    8.15387118035541307614e-05,
    1.95315871572807240978e-05,    4.15418294505217467227e-06,
    7.83370038027758703541e-07,    1.30739477492060251972e-07,
    1.92707140801702843786e-08,    2.50263893712634123804e-09,
    2.85578550877162254480e-10,    2.85462241205915581328e-11,
    2.49101068493722470668e-12,    1.89033660697154423659e-13,
    1.24216268594915285424e-14,    7.03423152021261791028e-16,
    3.41454914859188710697e-17,    1.41231541489573967918e-18,
    4.94421800809748465571e-20,    1.45395248136789987603e-21,
    3.56106836500408575092e-23,    7.19405599649472423055e-25,
    1.18553722835058604438e-26,    1.57349135707560219236e-28,
    1.65728544091948287589e-30,    1.36143416271634202704e-32,
    8.54615581396313680606e-35,    4.00009053248134628372e-37,
    1.35501999110299739348e-39,    3.20163679535491390027e-42,
    5.03586916606109586657e-45,    4.96248754070273290099e-48,
    2.82351071612011276695e-51,    8.26844606950506397550e-55,
    1.04906484782127192629e-58,    4.34657442273885662821e-63,
    3.43473643839657802339e-68,    1.31906608839801659210e-74
};

#define NUM_OF_ZEROS  sizeof(x)/sizeof(double)


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Laguerre_Integration_48pts( double (*f)(double) )            //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x) from 0 to infinity using the  //
//     48 point Gauss-Laguerre integral approximation formula.                //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x) from 0 to infinity.                       //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Laguerre_Integration_48pts( f );                   //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Laguerre_Integration_48pts( double (*f)(double) ) {

   double integral = 0.0;
   const double *px = &x[NUM_OF_ZEROS - 1];
   const double *pA = &A[NUM_OF_ZEROS - 1];

   for (; px >= x; pA--, px--) integral += *pA * (*f)(*px);

   return integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Zeros_48pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the 48th Laguerre polynomial L48.                 //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of L48.  This array   //
//                    should be dimensioned 48 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 48                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Zeros_48pts( z );                                       //
//     printf("The zeros of the Laguerre polynomial L48 are:");               //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Zeros_48pts( double zeros[] ) {
   
   const double *pz = x;

   for (; pz < x + NUM_OF_ZEROS; pz++) *(zeros++) = *pz;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Coefs_48pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 48 point Gauss-Laguerre formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Laguerre formula.  This array should be dimensioned     //
//                    48 in the caller function.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 48                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Coefs_48pts( a );                                       //
//     printf("The coefficients for the Gauss-Laguerre formula are:\n");      //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Coefs_48pts( double coef[]) {

   const double *pA = A;

   for (; pA < A + NUM_OF_ZEROS; pA++) *(coef++) = *pA;
}
