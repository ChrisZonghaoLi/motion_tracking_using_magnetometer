////////////////////////////////////////////////////////////////////////////////
// File: gauss_laguerre_4pts.c                                                //
// Routines:                                                                  //
//    Gauss_Laguerre_Integration_4pts                                         //
//    Gauss_Laguerre_Zeros_4pts                                               //
//    Gauss_Laguerre_Coefs_4pts                                               //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// For n = 4 the zeros of the Laguerre polynomial                             //
//                 Ln(x) = exp(x) (d/dx)^n (x^n exp(-x))                      //
// are given in the array x below and the coefficients                        //
//                 A[i] = (n!)^2 / ( x[i] (Ln'(x[i]))^2 )                     //
// are given in the array A.                                                  //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    3.22547689619392311802e-01,    1.74576110115834657569e+00,
    4.53662029692112798345e+00,    9.39507091230113312950e+00
};

static const double A[] = {
    6.03154104341633601660e-01,    3.57418692437799686640e-01,
    3.88879085150053842740e-02,    5.39294705561327450102e-04
};


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Laguerre_Integration_4pts( double (*f)(double) )             //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x) from 0 to infinity using the  //
//     4 point Gauss-Laguerre integral approximation formula.                 //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x) from 0 to infinity.                       //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Laguerre_Integration_4pts( f );                    //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double 
  Gauss_Laguerre_Integration_4pts( double (*f)(double) )
{
   double integral; 

   integral = A[3] * (*f)(x[3]);
   integral += A[2] * (*f)(x[2]);
   integral += A[1] * (*f)(x[1]);
   integral += A[0] * (*f)(x[0]);

   return integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Zeros_4pts( double zeros[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the 4th Laguerre polynomial L4.                   //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of L4.  This array    //
//                    should be dimensioned 4 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 4                                                            //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Zeros_4pts( z );                                        //
//     printf("The zeros of the Laguerre polynomial L4 are:");                //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Zeros_4pts( double zeros[] ) {
   
   zeros[0] = x[0];
   zeros[1] = x[1];
   zeros[2] = x[2];
   zeros[3] = x[3];

}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Coefs_4pts( double coef[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 4 point Gauss-Laguerre formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Laguerre formula.  This array should be dimensioned     //
//                    4 in the caller function.                               //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 4                                                            //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Coefs_4pts( a );                                        //
//     printf("The coefficients for the Gauss-Laguerre formula are:\n");      //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Coefs_4pts( double coef[]) {

   coef[0] = A[0];
   coef[1] = A[1];
   coef[2] = A[2];
   coef[3] = A[3];

}
