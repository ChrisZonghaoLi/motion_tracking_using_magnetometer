////////////////////////////////////////////////////////////////////////////////
// File: gauss_laguerre_6pts.c                                                //
// Routines:                                                                  //
//    Gauss_Laguerre_Integration_6pts                                         //
//    Gauss_Laguerre_Zeros_6pts                                               //
//    Gauss_Laguerre_Coefs_6pts                                               //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// For n = 6 the zeros of the Laguerre polynomial                             //
//                 Ln(x) = exp(x) (d/dx)^n (x^n exp(-x))                      //
// are given in the array x below and the coefficients                        //
//                 A[i] = (n!)^2 / ( x[i] (Ln'(x[i]))^2 )                     //
// are given in the array A.                                                  //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    2.22846604179260689464e-01,    1.18893210167262303070e+00,
    2.99273632605931407761e+00,    5.77514356910451050198e+00,
    9.83746741838258991798e+00,    1.59828739806017017825e+01
};

static const double A[] = {
    4.58964673949963593579e-01,    4.17000830772120994105e-01,
    1.13373382074044975736e-01,    1.03991974531490748991e-02,
    2.61017202814932059471e-04,    8.98547906429621238840e-07
};


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Laguerre_Integration_6pts( double (*f)(double) )             //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x) from 0 to infinity using the  //
//     6 point Gauss-Laguerre integral approximation formula.                 //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x) from 0 to infinity.                       //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Laguerre_Integration_6pts( f );                    //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Laguerre_Integration_6pts( double (*f)(double) ) {

   double integral; 

   integral = A[5] * (*f)(x[5]);
   integral += A[4] * (*f)(x[4]);
   integral += A[3] * (*f)(x[3]);
   integral += A[2] * (*f)(x[2]);
   integral += A[1] * (*f)(x[1]);
   integral += A[0] * (*f)(x[0]);

   return integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Zeros_6pts( double zeros[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the 6th Laguerre polynomial L6.                   //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of L6.  This array    //
//                    should be dimensioned 6 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 6                                                            //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Zeros_6pts( z );                                        //
//     printf("The zeros of the Laguerre polynomial L6 are:");                //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Zeros_6pts( double zeros[] ) {
   
   zeros[0] = x[0];
   zeros[1] = x[1];
   zeros[2] = x[2];
   zeros[3] = x[3];
   zeros[4] = x[4];
   zeros[5] = x[5];

}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Coefs_6pts( double coef[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 6 point Gauss-Laguerre formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Laguerre formula.  This array should be dimensioned     //
//                    6 in the caller function.                               //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 6                                                            //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Coefs_6pts( a );                                        //
//     printf("The coefficients for the Gauss-Laguerre formula are:\n");      //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Coefs_6pts( double coef[]) {

   coef[0] = A[0];
   coef[1] = A[1];
   coef[2] = A[2];
   coef[3] = A[3];
   coef[4] = A[4];
   coef[5] = A[5];

}
