////////////////////////////////////////////////////////////////////////////////
// File: gauss_laguerre_7pts.c                                                //
// Routines:                                                                  //
//    Gauss_Laguerre_Integration_7pts                                         //
//    Gauss_Laguerre_Zeros_7pts                                               //
//    Gauss_Laguerre_Coefs_7pts                                               //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// For n = 7 the zeros of the Laguerre polynomial                             //
//                 Ln(x) = exp(x) (d/dx)^n (x^n exp(-x))                      //
// are given in the array x below and the coefficients                        //
//                 A[i] = (n!)^2 / ( x[i] (Ln'(x[i]))^2 )                     //
// are given in the array A.                                                  //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    1.93043676560362413832e-01,    1.02666489533919195033e+00,
    2.56787674495074620695e+00,    4.90035308452648456830e+00,
    8.18215344456286079126e+00,    1.27341802917978137583e+01,
    1.93957278622625403121e+01
};

static const double A[] = {
    4.09318951701273902141e-01,    4.21831277861719779936e-01,
    1.47126348657505278401e-01,    2.06335144687169398651e-02,
    1.07401014328074552218e-03,    1.58654643485642012689e-05,
    3.17031547899558056211e-08
};


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Laguerre_Integration_7pts( double (*f)(double) )             //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x) from 0 to infinity using the  //
//     7 point Gauss-Laguerre integral approximation formula.                 //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x) from 0 to infinity.                       //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Laguerre_Integration_6pts( f );                    //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Laguerre_Integration_7pts( double (*f)(double) ) {

   double integral; 

   integral = A[6] * (*f)(x[6]);
   integral += A[5] * (*f)(x[5]);
   integral += A[4] * (*f)(x[4]);
   integral += A[3] * (*f)(x[3]);
   integral += A[2] * (*f)(x[2]);
   integral += A[1] * (*f)(x[1]);
   integral += A[0] * (*f)(x[0]);

   return integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Zeros_7pts( double zeros[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the 7th Laguerre polynomial L7.                   //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of L7.  This array    //
//                    should be dimensioned 7 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 7                                                            //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Zeros_7pts( z );                                        //
//     printf("The zeros of the Laguerre polynomial L7 are:");                //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Zeros_7pts( double zeros[] ) {
   
   zeros[0] = x[0];
   zeros[1] = x[1];
   zeros[2] = x[2];
   zeros[3] = x[3];
   zeros[4] = x[4];
   zeros[5] = x[5];
   zeros[6] = x[6];

}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Coefs_7pts( double coef[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 7 point Gauss-Laguerre formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Laguerre formula.  This array should be dimensioned     //
//                    7 in the caller function.                               //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 7                                                            //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Coefs_7pts( a );                                        //
//     printf("The coefficients for the Gauss-Laguerre formula are:\n");      //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Coefs_7pts( double coef[]) {

   coef[0] = A[0];
   coef[1] = A[1];
   coef[2] = A[2];
   coef[3] = A[3];
   coef[4] = A[4];
   coef[5] = A[5];
   coef[6] = A[6];

}
