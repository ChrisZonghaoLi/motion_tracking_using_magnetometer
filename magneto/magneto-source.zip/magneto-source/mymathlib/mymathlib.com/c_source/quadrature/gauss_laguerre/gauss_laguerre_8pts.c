////////////////////////////////////////////////////////////////////////////////
// File: gauss_laguerre_8pts.c                                                //
// Routines:                                                                  //
//    Gauss_Laguerre_Integration_8pts                                         //
//    Gauss_Laguerre_Zeros_8pts                                               //
//    Gauss_Laguerre_Coefs_8pts                                               //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// For n = 8 the zeros of the Laguerre polynomial                             //
//                 Ln(x) = exp(x) (d/dx)^n (x^n exp(-x))                      //
// are given in the array x below and the coefficients                        //
//                 A[i] = (n!)^2 / ( x[i] (Ln'(x[i]))^2 )                     //
// are given in the array A.                                                  //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    1.70279632305100999786e-01,    9.03701776799379912170e-01,
    2.25108662986613068929e+00,    4.26670017028765879378e+00,
    7.04590540239346569719e+00,    1.07585160101809952241e+01,
    1.57406786412780045781e+01,    2.28631317368892641052e+01
};

static const double A[] = {
    3.69188589341637529929e-01,    4.18786780814342956078e-01,
    1.75794986637171805706e-01,    3.33434922612156515224e-02,
    2.79453623522567252491e-03,    9.07650877335821310457e-05,
    8.48574671627253154502e-07,    1.04800117487151038157e-09
};


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Laguerre_Integration_8pts( double (*f)(double) )             //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x) from 0 to infinity using the  //
//     8 point Gauss-Laguerre integral approximation formula.                 //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x) from 0 to infinity.                       //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Laguerre_Integration_8pts( f );                    //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Laguerre_Integration_8pts( double (*f)(double) ) {

   double integral;

   integral = A[7] * (*f)(x[7]);
   integral += A[6] * (*f)(x[6]);
   integral += A[5] * (*f)(x[5]);
   integral += A[4] * (*f)(x[4]);
   integral += A[3] * (*f)(x[3]);
   integral += A[2] * (*f)(x[2]);
   integral += A[1] * (*f)(x[1]);
   integral += A[0] * (*f)(x[0]);

   return integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Zeros_8pts( double zeros[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the 8th Laguerre polynomial L8.                   //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of L8.  This array    //
//                    should be dimensioned 8 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 8                                                            //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Zeros_8pts( z );                                        //
//     printf("The zeros of the Laguerre polynomial L8 are:");                //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Zeros_8pts( double zeros[] ) {
   
   zeros[0] = x[0];
   zeros[1] = x[1];
   zeros[2] = x[2];
   zeros[3] = x[3];
   zeros[4] = x[4];
   zeros[5] = x[5];
   zeros[6] = x[6];
   zeros[7] = x[7];

}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Coefs_8pts( double coef[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 8 point Gauss-Laguerre formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Laguerre formula.  This array should be dimensioned     //
//                    8 in the caller function.                               //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 8                                                            //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Coefs_8pts( a );                                        //
//     printf("The coefficients for the Gauss-Laguerre formula are:\n");      //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Coefs_8pts( double coef[]) {

   coef[0] = A[0];
   coef[1] = A[1];
   coef[2] = A[2];
   coef[3] = A[3];
   coef[4] = A[4];
   coef[5] = A[5];
   coef[6] = A[6];
   coef[7] = A[7];

}
