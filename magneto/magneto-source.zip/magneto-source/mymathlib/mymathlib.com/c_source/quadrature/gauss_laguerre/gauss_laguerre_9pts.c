////////////////////////////////////////////////////////////////////////////////
// File: gauss_laguerre_9pts.c                                                //
// Routines:                                                                  //
//    Gauss_Laguerre_Integration_9pts                                         //
//    Gauss_Laguerre_Zeros_9pts                                               //
//    Gauss_Laguerre_Coefs_9pts                                               //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// For n = 9 the zeros of the Laguerre polynomial                             //
//                 Ln(x) = exp(x) (d/dx)^n (x^n exp(-x))                      //
// are given in the array x below and the coefficients                        //
//                 A[i] = (n!)^2 / ( x[i] (Ln'(x[i]))^2 )                     //
// are given in the array A.                                                  //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    1.52322227731808247433e-01,    8.07220022742255847764e-01,
    2.00513515561934712304e+00,    3.78347397333123299174e+00,
    6.20495677787661260687e+00,    9.37298525168757620200e+00,
    1.34662369110920935710e+01,    1.88335977889916966147e+01,
    2.63740718909273767958e+01
};

static const double A[] = {
    3.36126421797962519672e-01,    4.11213980423984387311e-01,
    1.99287525370885580865e-01,    4.74605627656515992626e-02,
    5.59962661079458317683e-03,    3.05249767093210566300e-04,
    6.59212302607535239217e-06,    4.11076933034954844276e-08,
    3.29087403035070757640e-11
};

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Laguerre_Integration_9pts( double (*f)(double) )             //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) exp(-x) from 0 to infinity using the  //
//     9 point Gauss-Laguerre integral approximation formula.                 //
//                                                                            //
//  Arguments:                                                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) exp(-x) from 0 to infinity.                       //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral;                                                    //
//                                                                            //
//        integral = Gauss_Laguerre_Integration_9pts( f );                    //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Gauss_Laguerre_Integration_9pts( double (*f)(double) ) {

   double integral;

   integral = A[8] * (*f)(x[8]);
   integral += A[7] * (*f)(x[7]);
   integral += A[6] * (*f)(x[6]);
   integral += A[5] * (*f)(x[5]);
   integral += A[4] * (*f)(x[4]);
   integral += A[3] * (*f)(x[3]);
   integral += A[2] * (*f)(x[2]);
   integral += A[1] * (*f)(x[1]);
   integral += A[0] * (*f)(x[0]);

   return integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Zeros_9pts( double zeros[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the 9th Laguerre polynomial L9.                   //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of L9.  This array    //
//                    should be dimensioned 9 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 9                                                            //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Zeros_9pts( z );                                        //
//     printf("The zeros of the Laguerre polynomial L9 are:");                //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Zeros_9pts( double zeros[] ) {
   
   zeros[0] = x[0];
   zeros[1] = x[1];
   zeros[2] = x[2];
   zeros[3] = x[3];
   zeros[4] = x[4];
   zeros[5] = x[5];
   zeros[6] = x[6];
   zeros[7] = x[7];
   zeros[8] = x[8];

}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Laguerre_Coefs_9pts( double coef[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 9 point Gauss-Laguerre formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficient of the Gauss-   //
//                    Laguerre formula.  This array should be dimensioned     //
//                    9 in the caller function.                               //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 9                                                            //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Laguerre_Coefs_9pts( a );                                        //
//     printf("The coefficients for the Gauss-Laguerre formula are:\n");      //
//     for (i = 0; i < N; i++) printf("%12.6lf",a[i]);                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Laguerre_Coefs_9pts( double coef[]) {

   coef[0] = A[0];
   coef[1] = A[1];
   coef[2] = A[2];
   coef[3] = A[3];
   coef[4] = A[4];
   coef[5] = A[5];
   coef[6] = A[6];
   coef[7] = A[7];
   coef[8] = A[8];

}
