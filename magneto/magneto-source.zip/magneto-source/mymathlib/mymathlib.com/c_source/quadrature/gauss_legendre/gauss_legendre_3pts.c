////////////////////////////////////////////////////////////////////////////////
// File: gauss_legendre_3pts.c                                                //
// Routines:                                                                  //
//    double Gauss_Legendre_Integration_3pts( double a, double b,             //
//                                                     double (*f)(double) )  //
//    void   Gauss_Legendre_Zeros_3pts( double zeros[] )                      //
//    void   Gauss_Legendre_Coefs_3pts( double wght[] )                       //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Legendre polynomial is                                            //
//                 Pn(x) = 1/(2^n n!) (d/dx)^n (x^2-1)^n.                     //
// For the n point Gauss-Legendre integral approximation formula the          //
// coefficients are A[i] = 2 (1 - x[i]^2) / (n P(n-1)(x[i])^2 where x[i] is   //
// a zero of the n-th Legendre polynomial Pn(x).                              //
// Note that if x is a zero of Pn(x) then -x is also a zero of Pn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    0.00000000000000000000e+00,    7.74596669241483377010e-01
};

static const double A[] = {
    8.88888888888888888877e-01,    5.55555555555555555562e-01
};

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Legendre_Integration_3pts( double a, double b,               //
//                                                      double (*f)(double))  //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) from a to b using the 3 point Gauss-  //
//     Legendre integral approximation formula.                               //
//                                                                            //
//  Arguments:                                                                //
//     double  a   Lower limit of integration.                                //
//     double  b   Upper limit of integration.                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f from a to b.                                         //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral, lower_limit, upper_limit;                          //
//                                                                            //
//        (determine lower and upper limits of integration)                   //
//        integral = Gauss_Legendre_Integration_3pts(lower_limit,             //
//                                                          upper_limit, f);  //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double 
  Gauss_Legendre_Integration_3pts(double a, double b, double (*f)(double))
{
   double c = 0.5 * (b - a);
   double d = 0.5 * (b + a);
   double dum;

   dum = c * x[1];
   return  c * ( A[1] * ( (*f)(d - dum) + (*f)(d + dum) )
                                                     + A[0] * (*f)(d) );
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Zeros_3pts( double zeros[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Legendre polynomial P3.                       //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of P3.  This array    //
//                    should be dimensioned 3 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 3                                                            //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Zeros_3pts( z );                                        //
//     printf("The zeros of the Legendre polynomial P3 are:");                //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                    //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Zeros_3pts( double zeros[] ) {
   
  zeros[0] = -x[1];
  zeros[1] = x[0];
  zeros[2] = x[1];
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Coefs_3pts( double wght[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 3 point Gauss-Legendre formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double wght[]  Array in which to store the coefficients of the Gauss-  //
//                    Legendre formula.  The coefficient A[i] is associated   //
//                    with the i-th zero as returned in the function above    //
//                    Gauss_Legendre_Nodes_3pts.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 3                                                            //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Coefs_3pts( a );                                        //
//     printf("The coefficients for the Gauss-Legendre formula are :\n");     //
//     for (i = 0; i < N; i++) printf("%12.6lf\n",a[i]);                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Coefs_3pts( double wghts[]) {

   wghts[0] = A[1];
   wghts[1] = A[0];
   wghts[2] = A[1];
}
