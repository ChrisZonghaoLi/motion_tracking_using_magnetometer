////////////////////////////////////////////////////////////////////////////////
// File: gauss_legendre_48pts.c                                               //
// Routines:                                                                  //
//    double Gauss_Legendre_Integration_48pts( double a, double b,            //
//                                                     double (*f)(double) )  //
//    void   Gauss_Legendre_Zeros_48pts( double zeros[] )                     //
//    void   Gauss_Legendre_Coefs_48pts( double coef[] )                      //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Legendre polynomial is                                            //
//                 Pn(x) = 1/(2^n n!) (d/dx)^n (x^2-1)^n.                     //
// For the n point Gauss-Legendre integral approximation formula the          //
// coefficients are A[i] = 2 (1 - x[i]^2) / (n P(n-1)(x[i])^2 where x[i] is   //
// a zero of the n-th Legendre polynomial Pn(x).                              //
// Note that if x is a zero of Pn(x) then -x is also a zero of Pn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    3.23801709628693620343e-02,    9.70046992094626989322e-02,
    1.61222356068891718055e-01,    2.24763790394689061224e-01,
    2.87362487355455576728e-01,    3.48755886292160738148e-01,
    4.08686481990716729925e-01,    4.66902904750958404535e-01,
    5.23160974722233033658e-01,    5.77224726083972703838e-01,
    6.28867396776513624013e-01,    6.77872379632663905208e-01,
    7.24034130923814654658e-01,    7.67159032515740339276e-01,
    8.07066204029442627087e-01,    8.43588261624393530704e-01,
    8.76572020274247885885e-01,    9.05879136715569672805e-01,
    9.31386690706554333107e-01,    9.52987703160430860724e-01,
    9.70591592546247250472e-01,    9.84124583722826857765e-01,
    9.93530172266350757526e-01,    9.98771007252426118580e-01
};

static const double A[] = {
    6.47376968126839225006e-02,    6.44661644359500822082e-02,
    6.39242385846481866207e-02,    6.31141922862540256548e-02,
    6.20394231598926639029e-02,    6.07044391658938800517e-02,
    5.91148396983956357477e-02,    5.72772921004032157044e-02,
    5.51995036999841628676e-02,    5.28901894851936670964e-02,
    5.03590355538544749590e-02,    4.76166584924904748267e-02,
    4.46745608566942804201e-02,    4.15450829434647492133e-02,
    3.82413510658307063158e-02,    3.47772225647704388909e-02,
    3.11672278327980889025e-02,    2.74265097083569482001e-02,
    2.35707608393243791410e-02,    1.96161604573555278142e-02,
    1.55793157229438487279e-02,    1.14772345792345394895e-02,
    7.32755390127626210220e-03,    3.15334605230583863260e-03
};

#define NUM_OF_POSITIVE_ZEROS  sizeof(x) / sizeof(double)
#define NUM_OF_ZEROS           NUM_OF_POSITIVE_ZEROS+NUM_OF_POSITIVE_ZEROS

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Legendre_Integration_48pts( double a, double b,              //
//                                                      double (*f)(double))  //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) from a to b using the 48 point Gauss- //
//     Legendre integral approximation formula.                               //
//                                                                            //
//  Arguments:                                                                //
//     double  a   Lower limit of integration.                                //
//     double  b   Upper limit of integration.                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f from a to b.                                         //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral, lower_limit, upper_limit;                          //
//                                                                            //
//        (determine lower and upper limits of integration)                   //
//        integral = Gauss_Legendre_Integration_48pts(lower_limit,            //
//                                                          upper_limit, f);  //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double 
  Gauss_Legendre_Integration_48pts(double a, double b, double (*f)(double))
{
   double integral = 0.0; 
   double c = 0.5 * (b - a);
   double d = 0.5 * (b + a);
   double dum;
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];

   for (; px >= x; pA--, px--) {
      dum = c * *px;
      integral += *pA * ( (*f)(d - dum) + (*f)(d + dum) );
   }

   return c * integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Zeros_48pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Legendre polynomial P48.                      //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of P48.  This array   //
//                    should be dimensioned 48 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 48                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Zeros_48pts( z );                                       //
//     printf("The zeros of the Legendre polynomial P48 are:");               //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Zeros_48pts( double zeros[] ) {
   
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   double *pz = &zeros[NUM_OF_ZEROS - 1];

   for (; px >= x; px--)  {
      *(zeros++) = - *px;
      *(pz--) = *px;
   }   
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Coefs_48pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 48 point Gauss-Legendre formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Legendre formula.  The coefficient A[i] is associated   //
//                    with the i-th zero as returned in the function above    //
//                    Gauss_Legendre_Zeros_48pts.                             //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 48                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Coefs_48pts( a );                                       //
//     printf("The coefficients for the Gauss-Legendre formula are :\n");     //
//     for (i = 0; i < N; i++) printf("%12.6lf\n",a[i]);                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Coefs_48pts( double coefs[] ) {

   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];
   double *pc = &coefs[NUM_OF_ZEROS - 1];

   for (; pA >= A; pA--)  {
      *(coefs++) =  *pA;
      *(pc--) = *pA;
   }   
}
