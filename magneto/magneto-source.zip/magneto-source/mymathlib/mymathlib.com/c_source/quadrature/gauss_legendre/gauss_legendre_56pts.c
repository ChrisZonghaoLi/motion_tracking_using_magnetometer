////////////////////////////////////////////////////////////////////////////////
// File: gauss_legendre_56pts.c                                               //
// Routines:                                                                  //
//    double Gauss_Legendre_Integration_56pts( double a, double b,            //
//                                                     double (*f)(double) )  //
//    void   Gauss_Legendre_Zeros_56pts( double zeros[] )                     //
//    void   Gauss_Legendre_Coefs_56pts( double coef[] )                      //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Legendre polynomial is                                            //
//                 Pn(x) = 1/(2^n n!) (d/dx)^n (x^2-1)^n.                     //
// For the n point Gauss-Legendre integral approximation formula the          //
// coefficients are A[i] = 2 (1 - x[i]^2) / (n P(n-1)(x[i])^2 where x[i] is   //
// a zero of the n-th Legendre polynomial Pn(x).                              //
// Note that if x is a zero of Pn(x) then -x is also a zero of Pn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    2.77970352872754370942e-02,    8.33051868224353744437e-02,
    1.38555846810376242012e-01,    1.93378238635275258246e-01,
    2.47602909434337203968e-01,    3.01062253867220669048e-01,
    3.53591032174954520968e-01,    4.05026880927091278110e-01,
    4.55210814878459578940e-01,    5.03987718384381714188e-01,
    5.51206824855534618750e-01,    5.96722182770663320077e-01,
    6.40393106807006894294e-01,    6.82084612694470455497e-01,
    7.21667834450188083544e-01,    7.59020422705128902207e-01,
    7.94026922893866498037e-01,    8.26579132142881651667e-01,
    8.56576433762748635397e-01,    8.83926108327827540810e-01,
    9.08543620420655490867e-01,    9.30352880247496300556e-01,
    9.49286479561962635648e-01,    9.65285901905490183650e-01,
    9.78301709140256383354e-01,    9.88293715540161511084e-01,
    9.95231226081069747231e-01,    9.99094343801465584350e-01
};

static const double A[] = {
    5.55797463065143958469e-02,    5.54079525032451232193e-02,
    5.50648959017624257965e-02,    5.45516368708894210621e-02,
    5.38697618657144857091e-02,    5.30213785240107639691e-02,
    5.20091091517413998428e-02,    5.08360826177984805586e-02,
    4.95059246830475789197e-02,    4.80227467936002581221e-02,
    4.63911333730018967605e-02,    4.46161276526922832122e-02,
    4.27032160846670865107e-02,    4.06583113847445178803e-02,
    3.84877342592476624857e-02,    3.61981938723151860357e-02,
    3.37967671156117612965e-02,    3.12908767473104478680e-02,
    2.86882684738227417295e-02,    2.59969870583919521920e-02,
    2.32253515625653169375e-02,    2.03819298824025726345e-02,
    1.74755129114009465053e-02,    1.45150892780214718081e-02,
    1.15098243403833821739e-02,    8.46906316330788766164e-03,
    5.40252224601533776151e-03,    2.32385537577321550118e-03
};

#define NUM_OF_POSITIVE_ZEROS  sizeof(x) / sizeof(double)
#define NUM_OF_ZEROS           NUM_OF_POSITIVE_ZEROS+NUM_OF_POSITIVE_ZEROS

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Legendre_Integration_56pts( double a, double b,              //
//                                                      double (*f)(double))  //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) from a to b using the 56 point Gauss- //
//     Legendre integral approximation formula.                               //
//                                                                            //
//  Arguments:                                                                //
//     double  a   Lower limit of integration.                                //
//     double  b   Upper limit of integration.                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f from a to b.                                         //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral, lower_limit, upper_limit;                          //
//                                                                            //
//        (determine lower and upper limits of integration)                   //
//        integral = Gauss_Legendre_Integration_56pts(lower_limit,            //
//                                                          upper_limit, f);  //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double 
  Gauss_Legendre_Integration_56pts(double a, double b, double (*f)(double))
{
   double integral = 0.0; 
   double c = 0.5 * (b - a);
   double d = 0.5 * (b + a);
   double dum;
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];

   for (; px >= x; pA--, px--) {
      dum = c * *px;
      integral += *pA * ( (*f)(d - dum) + (*f)(d + dum) );
   }

   return c * integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Zeros_56pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Legendre polynomial P56.                      //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of P56.  This array   //
//                    should be dimensioned 56 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 56                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Zeros_56pts( z );                                       //
//     printf("The zeros of the Legendre polynomial P56 are:");               //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Zeros_56pts( double zeros[] ) {
   
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   double *pz = &zeros[NUM_OF_ZEROS - 1];

   for (; px >= x; px--)  {
      *(zeros++) = - *px;
      *(pz--) = *px;
   }   
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Coefs_56pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 56 point Gauss-Legendre formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Legendre formula.  The coefficient A[i] is associated   //
//                    with the i-th zero as returned in the function above    //
//                    Gauss_Legendre_Zeros_56pts.                             //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 56                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Coefs_56pts( a );                                       //
//     printf("The coefficients for the Gauss-Legendre formula are :\n");     //
//     for (i = 0; i < N; i++) printf("%12.6lf\n",a[i]);                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Coefs_56pts( double coefs[] ) {

   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];
   double *pc = &coefs[NUM_OF_ZEROS - 1];

   for (; pA >= A; pA--)  {
      *(coefs++) =  *pA;
      *(pc--) = *pA;
   }   
}
