////////////////////////////////////////////////////////////////////////////////
// File: gauss_legendre_64pts.c                                               //
// Routines:                                                                  //
//    double Gauss_Legendre_Integration_64pts( double a, double b,            //
//                                                     double (*f)(double) )  //
//    void   Gauss_Legendre_Zeros_64pts( double zeros[] )                     //
//    void   Gauss_Legendre_Coefs_64pts( double coef[] )                      //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Legendre polynomial is                                            //
//                 Pn(x) = 1/(2^n n!) (d/dx)^n (x^2-1)^n.                     //
// For the n point Gauss-Legendre integral approximation formula the          //
// coefficients are A[i] = 2 (1 - x[i]^2) / (n P(n-1)(x[i])^2 where x[i] is   //
// a zero of the n-th Legendre polynomial Pn(x).                              //
// Note that if x is a zero of Pn(x) then -x is also a zero of Pn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    2.43502926634244325092e-02,    7.29931217877990394521e-02,
    1.21462819296120554468e-01,    1.69644420423992818036e-01,
    2.17423643740007084148e-01,    2.64687162208767416384e-01,
    3.11322871990210956161e-01,    3.57220158337668115941e-01,
    4.02270157963991603693e-01,    4.46366017253464087978e-01,
    4.89403145707052957474e-01,    5.31279464019894545634e-01,
    5.71895646202634034291e-01,    6.11155355172393250241e-01,
    6.48965471254657339884e-01,    6.85236313054233242559e-01,
    7.19881850171610826840e-01,    7.52819907260531896590e-01,
    7.83972358943341407619e-01,    8.13265315122797559746e-01,
    8.40629296252580362743e-01,    8.65999398154092819759e-01,
    8.89315445995114105856e-01,    9.10522137078502805780e-01,
    9.29569172131939575846e-01,    9.46411374858402816069e-01,
    9.61008799652053718944e-01,    9.73326827789910963733e-01,
    9.83336253884625956939e-01,    9.91013371476744320732e-01,
    9.96340116771955279355e-01,    9.99305041735772139465e-01
};

static const double A[] = {
    4.86909570091397203845e-02,    4.85754674415034269347e-02,
    4.83447622348029571711e-02,    4.79993885964583077283e-02,
    4.75401657148303086630e-02,    4.69681828162100173254e-02,
    4.62847965813144172952e-02,    4.54916279274181444806e-02,
    4.45905581637565630589e-02,    4.35837245293234533762e-02,
    4.24735151236535890083e-02,    4.12625632426235286114e-02,
    3.99537411327203413872e-02,    3.85501531786156291275e-02,
    3.70551285402400460401e-02,    3.54722132568823838103e-02,
    3.38051618371416093907e-02,    3.20579283548515535845e-02,
    3.02346570724024788683e-02,    2.83396726142594832269e-02,
    2.63774697150546586725e-02,    2.43527025687108733385e-02,
    2.22701738083832541592e-02,    2.01348231535302093718e-02,
    1.79517157756973430852e-02,    1.57260304760247193221e-02,
    1.34630478967186425983e-02,    1.11681394601311288184e-02,
    8.84675982636394772300e-03,    6.50445796897836285625e-03,
    4.14703326056246763525e-03,    1.78328072169643294728e-03
};

#define NUM_OF_POSITIVE_ZEROS  sizeof(x) / sizeof(double)
#define NUM_OF_ZEROS           NUM_OF_POSITIVE_ZEROS+NUM_OF_POSITIVE_ZEROS


////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Legendre_Integration_64pts( double a, double b,              //
//                                                      double (*f)(double))  //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) from a to b using the 64 point Gauss- //
//     Legendre integral approximation formula.                               //
//                                                                            //
//  Arguments:                                                                //
//     double  a   Lower limit of integration.                                //
//     double  b   Upper limit of integration.                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f from a to b.                                         //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral, lower_limit, upper_limit;                          //
//                                                                            //
//        (determine lower and upper limits of integration)                   //
//        integral = Gauss_Legendre_Integration_64pts(lower_limit,            //
//                                                          upper_limit, f);  //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double 
  Gauss_Legendre_Integration_64pts(double a, double b, double (*f)(double))
{

   double integral = 0.0; 
   double c = 0.5 * (b - a);
   double d = 0.5 * (b + a);
   double dum;
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];

   for (; px >= x; pA--, px--) {
      dum = c * *px;
      integral += *pA * ( (*f)(d - dum) + (*f)(d + dum) );
   }

   return c * integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Zeros_64pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Legendre polynomial P64.                      //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of P64.  This array   //
//                    should be dimensioned 64 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 64                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Zeros_64pts( z );                                       //
//     printf("The zeros of the Legendre polynomial P64 are:");               //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Zeros_64pts( double zeros[] ) {
   
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   double *pz = &zeros[NUM_OF_ZEROS - 1];

   for (; px >= x; px--)  {
      *(zeros++) = - *px;
      *(pz--) = *px;
   }   
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Coefs_64pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 64 point Gauss-Legendre formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Legendre formula.  The coefficient A[i] is associated   //
//                    with the i-th zero as returned in the function above    //
//                    Gauss_Legendre_Zeros_64pts.                             //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 64                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Coefs_64pts( a );                                       //
//     printf("The coefficients for the Gauss-Legendre formula are :\n");     //
//     for (i = 0; i < N; i++) printf("%12.6lf\n",a[i]);                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Coefs_64pts( double coefs[] ) {

   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];
   double *pc = &coefs[NUM_OF_ZEROS - 1];

   for (; pA >= A; pA--)  {
      *(coefs++) =  *pA;
      *(pc--) = *pA;
   }   
}
