////////////////////////////////////////////////////////////////////////////////
// File: gauss_legendre_7pts.c                                                //
// Routines:                                                                  //
//    double Gauss_Legendre_Integration_7pts( double a, double b,             //
//                                                     double (*f)(double) )  //
//    void   Gauss_Legendre_Zeros_7pts( double zeros[] )                      //
//    void   Gauss_Legendre_Coefs_7pts( double coef[] )                       //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Legendre polynomial is                                            //
//                 Pn(x) = 1/(2^n n!) (d/dx)^n (x^2-1)^n.                     //
// For the n point Gauss-Legendre integral approximation formula the          //
// coefficients are A[i] = 2 (1 - x[i]^2) / (n P(n-1)(x[i])^2 where x[i] is   //
// a zero of the n-th Legendre polynomial Pn(x).                              //
// Note that if x is a zero of Pn(x) then -x is also a zero of Pn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    0.00000000000000000000e+00,    4.05845151377397166917e-01,
    7.41531185599394439864e-01,    9.49107912342758524541e-01
};

static const double A[] = {
    4.17959183673469387749e-01,    3.81830050505118944961e-01,
    2.79705391489276667890e-01,    1.29484966168869693274e-01
};

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Legendre_Integration_7pts( double a, double b,               //
//                                                      double (*f)(double))  //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) from a to b using the 7 point Gauss-  //
//     Legendre integral approximation formula.                               //
//                                                                            //
//  Arguments:                                                                //
//     double  a   Lower limit of integration.                                //
//     double  b   Upper limit of integration.                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f from a to b.                                         //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral, lower_limit, upper_limit;                          //
//                                                                            //
//        (determine lower and upper limits of integration)                   //
//        integral = Gauss_Legendre_Integration_7pts(lower_limit,             //
//                                                          upper_limit, f);  //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double 
  Gauss_Legendre_Integration_7pts(double a, double b, double (*f)(double))
{
   double integral; 
   double c = 0.5 * (b - a);
   double d = 0.5 * (b + a);
   double dum;

   dum = c * x[3];
   integral = A[3] * ((*f)(d - dum) + (*f)(d + dum));
   dum = c * x[2];
   integral += A[2] * ((*f)(d - dum) + (*f)(d + dum));
   dum = c * x[1];
   integral += A[1] * ((*f)(d - dum) + (*f)(d + dum));
   integral += A[0] * (*f)(d);

   return c * integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Zeros_7pts( double zeros[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Legendre polynomial P7.                       //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of P7.  This array    //
//                    should be dimensioned 7 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 7                                                            //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Zeros_7pts( z );                                        //
//     printf("The zeros of the Legendre polynomial P7 are:");                //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                    //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Zeros_7pts( double zeros[] ) {
   
  zeros[0] = -x[3];
  zeros[1] = -x[2];
  zeros[2] = -x[1];
  zeros[3] = x[0];
  zeros[4] = x[1];
  zeros[5] = x[2];
  zeros[6] = x[3];
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Coefs_7pts( double coef[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 7 point Gauss-Legendre formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Legendre formula.  The coefficient A[i] is associated   //
//                    with the i-th zero as returned in the function above    //
//                    Gauss_Legendre_Zeros_7pts.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 7                                                            //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Coefs_7pts( a );                                        //
//     printf("The coefficients for the Gauss-Legendre formula are :\n");     //
//     for (i = 0; i < N; i++) printf("%12.6lf\n",a[i]);                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Coefs_7pts( double coefs[]) {

   coefs[0] = A[3];
   coefs[1] = A[2];
   coefs[2] = A[1];
   coefs[3] = A[0];
   coefs[4] = A[1];
   coefs[5] = A[2];
   coefs[6] = A[3];
}
