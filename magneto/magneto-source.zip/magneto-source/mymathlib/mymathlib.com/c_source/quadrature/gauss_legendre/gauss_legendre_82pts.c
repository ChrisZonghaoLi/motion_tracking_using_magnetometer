////////////////////////////////////////////////////////////////////////////////
// File: gauss_legendre_82pts.c                                               //
// Routines:                                                                  //
//    double Gauss_Legendre_Integration_82pts( double a, double b,            //
//                                                     double (*f)(double) )  //
//    void   Gauss_Legendre_Zeros_82pts( double zeros[] )                     //
//    void   Gauss_Legendre_Coefs_82pts( double coef[] )                      //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Legendre polynomial is                                            //
//                 Pn(x) = 1/(2^n n!) (d/dx)^n (x^2-1)^n.                     //
// For the n point Gauss-Legendre integral approximation formula the          //
// coefficients are A[i] = 2 (1 - x[i]^2) / (n P(n-1)(x[i])^2 where x[i] is   //
// a zero of the n-th Legendre polynomial Pn(x).                              //
// Note that if x is a zero of Pn(x) then -x is also a zero of Pn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    1.90384554820068137613e-02,    5.70877625059269319014e-02,
    9.50542977326448739519e-02,    1.32883013316257525763e-01,
    1.70519061236190159767e-01,    2.07907872821592350966e-01,
    2.44995237870704537844e-01,    2.81727383250480102378e-01,
    3.18051050862501505004e-01,    3.53913574862147936411e-01,
    3.89262958019054815918e-01,    4.24047947108150722153e-01,
    4.58218107221963197832e-01,    4.91723894896449322455e-01,
    5.24516729944327767963e-01,    5.56549065891763812346e-01,
    5.87774458916284867180e-01,    6.18147635185978682035e-01,
    6.47624556502346598549e-01,    6.76162484151647024571e-01,
    7.03720040872166678473e-01,    7.30257270847596245034e-01,
    7.55735697639560417317e-01,    7.80118379975358245207e-01,
    8.03369965310108299287e-01,    8.25456741085767656024e-01,
    8.46346683612913701800e-01,    8.66009504504765448567e-01,
    8.84416694596724708250e-01,    9.01541565288841258185e-01,
    9.17359287253280107145e-01,    9.31846926454622887881e-01,
    9.44983477438960489203e-01,    9.56749893861610903139e-01,
    9.67129116252590696019e-01,    9.76106097094498828710e-01,
    9.83667823522007603353e-01,    9.89803338839908949953e-01,
    9.94503768378075628926e-01,    9.97762385826385862536e-01,
    9.99575191501652648887e-01
};

static const double A[] = {
    3.80723096401418712092e-02,    3.80171084314352699063e-02,
    3.79067860505057847784e-02,    3.77415024542758696721e-02,
    3.75214972881850208729e-02,    3.72470895387276641869e-02,
    3.69186770709544569983e-02,    3.65367360516076528430e-02,
    3.61018202587270230770e-02,    3.56145602787274726798e-02,
    3.50756625921126903860e-02,    3.44859085491507055064e-02,
    3.38461532369968587430e-02,    3.31573242399072113277e-02,
    3.24204202943406050765e-02,    3.16365098409002455390e-02,
    3.08067294752156298136e-02,    2.99322823000127246344e-02,
    2.90144361807644039617e-02,    2.80545219074542304725e-02,
    2.70539312651247715195e-02,    2.60141150160170237537e-02,
    2.49365807962407551563e-02,    2.38228909300478263420e-02,
    2.26746601649141031023e-02,    2.14935533307748440428e-02,
    2.02812829269121589024e-02,    1.90396066401789250728e-02,
    1.77703247984984071478e-02,    1.64752777639837088909e-02,
    1.51563432707625617883e-02,    1.38154337141264593880e-02,
    1.24544934011421046793e-02,    1.10754957817598963206e-02,
    9.68044070437107373722e-03,    8.27135181838368560408e-03,
    6.85027453418352618420e-03,    5.41927623244676509051e-03,
    3.98045793785607461882e-03,    2.53605469685610610985e-03,
    1.09011859527583086610e-03
};

#define NUM_OF_POSITIVE_ZEROS  sizeof(x) / sizeof(double)
#define NUM_OF_ZEROS           NUM_OF_POSITIVE_ZEROS+NUM_OF_POSITIVE_ZEROS

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Legendre_Integration_82pts( double a, double b,              //
//                                                      double (*f)(double))  //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) from a to b using the 82 point Gauss- //
//     Legendre integral approximation formula.                               //
//                                                                            //
//  Arguments:                                                                //
//     double  a   Lower limit of integration.                                //
//     double  b   Upper limit of integration.                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f from a to b.                                         //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral, lower_limit, upper_limit;                          //
//                                                                            //
//        (determine lower and upper limits of integration)                   //
//        integral = Gauss_Legendre_Integration_82pts(lower_limit,            //
//                                                          upper_limit, f);  //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double 
  Gauss_Legendre_Integration_82pts(double a, double b, double (*f)(double))
{
   double integral = 0.0; 
   double c = 0.5 * (b - a);
   double d = 0.5 * (b + a);
   double dum;
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];

   for (; px >= x; pA--, px--) {
      dum = c * *px;
      integral += *pA * ( (*f)(d - dum) + (*f)(d + dum) );
   }

   return c * integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Zeros_82pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Legendre polynomial P82.                      //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of P82.  This array   //
//                    should be dimensioned 82 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 82                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Zeros_82pts( z );                                       //
//     printf("The zeros of the Legendre polynomial P82 are:");               //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Zeros_82pts( double zeros[] ) {
   
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   double *pz = &zeros[NUM_OF_ZEROS - 1];

   for (; px >= x; px--)  {
      *(zeros++) = - *px;
      *(pz--) = *px;
   }   
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Coefs_82pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 82 point Gauss-Legendre formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Legendre formula.  The coefficient A[i] is associated   //
//                    with the i-th zero as returned in the function above    //
//                    Gauss_Legendre_Zeros_82pts.                             //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 82                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Coefs_82pts( a );                                       //
//     printf("The coefficients for the Gauss-Legendre formula are :\n");     //
//     for (i = 0; i < N; i++) printf("%12.6lf\n",a[i]);                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Coefs_82pts( double coefs[] ) {

   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];
   double *pc = &coefs[NUM_OF_ZEROS - 1];

   for (; pA >= A; pA--)  {
      *(coefs++) =  *pA;
      *(pc--) = *pA;
   }   
}
