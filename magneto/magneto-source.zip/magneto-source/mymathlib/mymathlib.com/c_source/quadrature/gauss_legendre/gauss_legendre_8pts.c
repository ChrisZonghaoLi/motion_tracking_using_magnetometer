////////////////////////////////////////////////////////////////////////////////
// File: gauss_legendre_8pts.c                                                //
// Routines:                                                                  //
//    double Gauss_Legendre_Integration_8pts( double a, double b,             //
//                                                     double (*f)(double) )  //
//    void   Gauss_Legendre_Zeros_8pts( double zeros[] )                      //
//    void   Gauss_Legendre_Coefs_8pts( double coef[] )                       //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Legendre polynomial is                                            //
//                 Pn(x) = 1/(2^n n!) (d/dx)^n (x^2-1)^n.                     //
// For the n point Gauss-Legendre integral approximation formula the          //
// coefficients are A[i] = 2 (1 - x[i]^2) / (n P(n-1)(x[i])^2 where x[i] is   //
// a zero of the n-th Legendre polynomial Pn(x).                              //
// Note that if x is a zero of Pn(x) then -x is also a zero of Pn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    1.83434642495649804936e-01,    5.25532409916328985830e-01,
    7.96666477413626739567e-01,    9.60289856497536231661e-01
};

static const double A[] = {
    3.62683783378361982976e-01,    3.13706645877887287338e-01,
    2.22381034453374470546e-01,    1.01228536290376259154e-01
};

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Legendre_Integration_8pts( double a, double b,               //
//                                                      double (*f)(double))  //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) from a to b using the 8 point Gauss-  //
//     Legendre integral approximation formula.                               //
//                                                                            //
//  Arguments:                                                                //
//     double  a   Lower limit of integration.                                //
//     double  b   Upper limit of integration.                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f from a to b.                                         //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral, lower_limit, upper_limit;                          //
//                                                                            //
//        (determine lower and upper limits of integration)                   //
//        integral = Gauss_Legendre_Integration_8pts(lower_limit,             //
//                                                          upper_limit, f);  //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double 
  Gauss_Legendre_Integration_8pts(double a, double b, double (*f)(double))
{
   double integral; 
   double c = 0.5 * (b - a);
   double d = 0.5 * (b + a);
   double dum;

   dum = c * x[3];
   integral = A[3] * ((*f)(d - dum) + (*f)(d + dum));
   dum = c * x[2];
   integral += A[2] * ((*f)(d - dum) + (*f)(d + dum));
   dum = c * x[1];
   integral += A[1] * ((*f)(d - dum) + (*f)(d + dum));
   dum = c * x[0];
   integral += A[0] * ((*f)(d - dum) + (*f)(d + dum));

   return c * integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Zeros_8pts( double zeros[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Legendre polynomial P8.                       //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of P8.  This array    //
//                    should be dimensioned 8 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 8                                                            //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Zeros_8pts( z );                                        //
//     printf("The zeros of the Legendre polynomial P8 are:");                //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                    //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Zeros_8pts( double zeros[] ) {
   
  zeros[0] = -x[3];
  zeros[1] = -x[2];
  zeros[2] = -x[1];
  zeros[3] = -x[0];
  zeros[4] = x[0];
  zeros[5] = x[1];
  zeros[6] = x[2];
  zeros[7] = x[3];
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Coefs_8pts( double coef[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 8 point Gauss-Legendre formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Legendre formula.  The coefficient A[i] is associated   //
//                    with the i-th zero as returned in the function above    //
//                    Gauss_Legendre_Zeros_8pts.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 8                                                            //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Coefs_8pts( a );                                        //
//     printf("The coefficients for the Gauss-Legendre formula are :\n");     //
//     for (i = 0; i < N; i++) printf("%12.6lf\n",a[i]);                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Coefs_8pts( double coefs[]) {

   coefs[0] = A[3];
   coefs[1] = A[2];
   coefs[2] = A[1];
   coefs[3] = A[0];
   coefs[4] = A[0];
   coefs[5] = A[1];
   coefs[6] = A[2];
   coefs[7] = A[3];
}
