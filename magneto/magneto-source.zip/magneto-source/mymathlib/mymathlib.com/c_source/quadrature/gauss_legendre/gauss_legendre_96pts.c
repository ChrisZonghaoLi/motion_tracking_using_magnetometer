////////////////////////////////////////////////////////////////////////////////
// File: gauss_legendre_96pts.c                                               //
// Routines:                                                                  //
//    double Gauss_Legendre_Integration_96pts( double a, double b,            //
//                                                     double (*f)(double) )  //
//    void   Gauss_Legendre_Zeros_96pts( double zeros[] )                     //
//    void   Gauss_Legendre_Coefs_96pts( double coef[] )                      //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Legendre polynomial is                                            //
//                 Pn(x) = 1/(2^n n!) (d/dx)^n (x^2-1)^n.                     //
// For the n point Gauss-Legendre integral approximation formula the          //
// coefficients are A[i] = 2 (1 - x[i]^2) / (n P(n-1)(x[i])^2 where x[i] is   //
// a zero of the n-th Legendre polynomial Pn(x).                              //
// Note that if x is a zero of Pn(x) then -x is also a zero of Pn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    1.62767448496029695789e-02,    4.88129851360497311115e-02,
    8.12974954644255589937e-02,    1.13695850110665920914e-01,
    1.45973714654896941992e-01,    1.78096882367618602759e-01,
    2.10031310460567203601e-01,    2.41743156163840012331e-01,
    2.73198812591049141485e-01,    3.04364944354496353015e-01,
    3.35208522892625422607e-01,    3.65696861472313635024e-01,
    3.95797649828908603298e-01,    4.25478988407300545368e-01,
    4.54709422167743008628e-01,    4.83457973920596359777e-01,
    5.11694177154667673569e-01,    5.39388108324357436218e-01,
    5.66510418561397168413e-01,    5.93032364777572080659e-01,
    6.18925840125468570377e-01,    6.44163403784967106801e-01,
    6.68718310043916153943e-01,    6.92564536642171561332e-01,
    7.15676812348967626199e-01,    7.38030643744400132876e-01,
    7.59602341176647498681e-01,    7.80369043867433217620e-01,
    8.00308744139140817216e-01,    8.19400310737931675557e-01,
    8.37623511228187121497e-01,    8.54959033434601455438e-01,
    8.71388505909296502900e-01,    8.86894517402420416068e-01,
    9.01460635315852341334e-01,    9.15071423120898074215e-01,
    9.27712456722308690977e-01,    9.39370339752755216934e-01,
    9.50032717784437635746e-01,    9.59688291448742539290e-01,
    9.68326828463264212168e-01,    9.75939174585136466459e-01,
    9.82517263563014677430e-01,    9.88054126329623799458e-01,
    9.92543900323762624555e-01,    9.95981842987209290633e-01,
    9.98364375863181677739e-01,    9.99689503883230766825e-01
};

static const double A[] = {
    3.25506144923631662418e-02,    3.25161187138688359885e-02,
    3.24471637140642693631e-02,    3.23438225685759284293e-02,
    3.22062047940302506674e-02,    3.20344562319926632176e-02,
    3.18287588944110065352e-02,    3.15893307707271685576e-02,
    3.13164255968613558124e-02,    3.10103325863138374230e-02,
    3.06713761236691490147e-02,    3.02999154208275937943e-02,
    2.98963441363283859846e-02,    2.94610899581679059697e-02,
    2.89946141505552365432e-02,    2.84974110650853856455e-02,
    2.79700076168483344400e-02,    2.74129627260292428232e-02,
    2.68268667255917621977e-02,    2.62123407356724139131e-02,
    2.55700360053493614996e-02,    2.49006332224836102884e-02,
    2.42048417923646912830e-02,    2.34833990859262198430e-02,
    2.27370696583293740018e-02,    2.19666444387443491945e-02,
    2.11729398921912989884e-02,    2.03567971543333245953e-02,
    1.95190811401450224097e-02,    1.86606796274114673859e-02,
    1.77825023160452608374e-02,    1.68854798642451724498e-02,
    1.59705629025622913804e-02,    1.50387210269949380059e-02,
    1.40909417723148609158e-02,    1.31282295669615726374e-02,
    1.21516046710883196352e-02,    1.11621020998384985916e-02,
    1.01607705350084157574e-02,    9.14867123078338663265e-03,
    8.12687692569875921698e-03,    7.09647079115386526927e-03,
    6.05854550423596168331e-03,    5.01420274292751769241e-03,
    3.96455433844468667376e-03,    2.91073181793494640833e-03,
    1.85396078894692173237e-03,    7.96792065552012429429e-04
};

#define NUM_OF_POSITIVE_ZEROS  sizeof(x) / sizeof(double)
#define NUM_OF_ZEROS           NUM_OF_POSITIVE_ZEROS+NUM_OF_POSITIVE_ZEROS

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Legendre_Integration_96pts( double a, double b,              //
//                                                      double (*f)(double))  //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) from a to b using the 96 point Gauss- //
//     Legendre integral approximation formula.                               //
//                                                                            //
//  Arguments:                                                                //
//     double  a   Lower limit of integration.                                //
//     double  b   Upper limit of integration.                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f from a to b.                                         //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral, lower_limit, upper_limit;                          //
//                                                                            //
//        (determine lower and upper limits of integration)                   //
//        integral = Gauss_Legendre_Integration_96pts(lower_limit,            //
//                                                          upper_limit, f);  //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double 
  Gauss_Legendre_Integration_96pts(double a, double b, double (*f)(double))
{
   double integral = 0.0; 
   double c = 0.5 * (b - a);
   double d = 0.5 * (b + a);
   double dum;
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];

   for (; px >= x; pA--, px--) {
      dum = c * *px;
      integral += *pA * ( (*f)(d - dum) + (*f)(d + dum) );
   }

   return c * integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Zeros_96pts( double zeros[] )                         //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Legendre polynomial P96.                      //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of P96.  This array   //
//                    should be dimensioned 96 in the caller function.        //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 96                                                           //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Zeros_96pts( z );                                       //
//     printf("The zeros of the Legendre polynomial P96 are:");               //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                     //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Zeros_96pts( double zeros[] ) {
   
   const double *px = &x[NUM_OF_POSITIVE_ZEROS - 1];
   double *pz = &zeros[NUM_OF_ZEROS - 1];

   for (; px >= x; px--)  {
      *(zeros++) = - *px;
      *(pz--) = *px;
   }   
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Coefs_96pts( double coef[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 96 point Gauss-Legendre formula.      //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Legendre formula.  The coefficient A[i] is associated   //
//                    with the i-th zero as returned in the function above    //
//                    Gauss_Legendre_Zeros_96pts.                             //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 96                                                           //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Coefs_96pts( a );                                       //
//     printf("The coefficients for the Gauss-Legendre formula are :\n");     //
//     for (i = 0; i < N; i++) printf("%12.6lf\n",a[i]);                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Coefs_96pts( double coefs[] ) {

   const double *pA = &A[NUM_OF_POSITIVE_ZEROS - 1];
   double *pc = &coefs[NUM_OF_ZEROS - 1];

   for (; pA >= A; pA--)  {
      *(coefs++) =  *pA;
      *(pc--) = *pA;
   }   
}
