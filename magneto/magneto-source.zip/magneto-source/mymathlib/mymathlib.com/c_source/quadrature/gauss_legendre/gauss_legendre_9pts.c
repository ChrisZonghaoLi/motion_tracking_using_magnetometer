////////////////////////////////////////////////////////////////////////////////
// File: gauss_legendre_9pts.c                                                //
// Routines:                                                                  //
//    double Gauss_Legendre_Integration_9pts( double a, double b,             //
//                                                     double (*f)(double) )  //
//    void   Gauss_Legendre_Zeros_9pts( double zeros[] )                      //
//    void   Gauss_Legendre_Coefs_9pts( double coef[] )                       //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// The n-th Legendre polynomial is                                            //
//                 Pn(x) = 1/(2^n n!) (d/dx)^n (x^2-1)^n.                     //
// For the n point Gauss-Legendre integral approximation formula the          //
// coefficients are A[i] = 2 (1 - x[i]^2) / (n P(n-1)(x[i])^2 where x[i] is   //
// a zero of the n-th Legendre polynomial Pn(x).                              //
// Note that if x is a zero of Pn(x) then -x is also a zero of Pn(x) and the  //
// coefficients associated with x and -x are equal.                           //
////////////////////////////////////////////////////////////////////////////////

static const double x[] = {
    0.00000000000000000000e+00,    8.36031107326635794313e-01,
    9.68160239507626089810e-01,    3.24253423403808929042e-01,
    6.13371432700590397285e-01
};

static const double A[] = {
    3.30239355001259763154e-01,    1.80648160694857404059e-01,
    8.12743883615744119737e-02,    3.12347077040002840057e-01,
    2.60610696402935462313e-01
};

////////////////////////////////////////////////////////////////////////////////
//  double Gauss_Legendre_Integration_9pts( double a, double b,               //
//                                                      double (*f)(double))  //
//                                                                            //
//  Description:                                                              //
//     Approximate the integral of f(x) from a to b using the 9 point Gauss-  //
//     Legendre integral approximation formula.                               //
//                                                                            //
//  Arguments:                                                                //
//     double  a   Lower limit of integration.                                //
//     double  b   Upper limit of integration.                                //
//     double *f   Pointer to function of a single variable of type double.   //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f from a to b.                                         //
//                                                                            //
//  Example:                                                                  //
//     {                                                                      //
//        double f(double);                                                   //
//        double integral, lower_limit, upper_limit;                          //
//                                                                            //
//        (determine lower and upper limits of integration)                   //
//        integral = Gauss_Legendre_Integration_9pts(lower_limit,             //
//                                                          upper_limit, f);  //
//        ...                                                                 //
//     }                                                                      //
//     double f(double x) { define f }                                        //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double 
  Gauss_Legendre_Integration_9pts(double a, double b, double (*f)(double))
{
   double integral; 
   double c = 0.5 * (b - a);
   double d = 0.5 * (b + a);
   double dum;

   dum = c * x[4];
   integral = A[4] * ((*f)(d - dum) + (*f)(d + dum));
   dum = c * x[3];
   integral += A[3] * ((*f)(d - dum) + (*f)(d + dum));
   dum = c * x[2];
   integral += A[2] * ((*f)(d - dum) + (*f)(d + dum));
   dum = c * x[1];
   integral += A[1] * ((*f)(d - dum) + (*f)(d + dum));
   integral += A[0] * (*f)(d);

   return c * integral;
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Zeros_9pts( double zeros[] )                          //
//                                                                            //
//  Description:                                                              //
//     Returns the zeros of the Legendre polynomial P9.                       //
//                                                                            //
//  Arguments:                                                                //
//     double zeros[] Array in which to store the zeros of P9.  This array    //
//                    should be dimensioned 9 in the caller function.         //
//                    The order is from the minimum zero to the maximum.      //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 9                                                            //
//     double z[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Zeros_9pts( z );                                        //
//     printf("The zeros of the Legendre polynomial P9 are:");                //
//     for ( i = 0; i < N; i++) printf("%12.6le\n",z[i]);                    //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Zeros_9pts( double zeros[] ) {
   
  zeros[0] = -x[4];
  zeros[1] = -x[3];
  zeros[2] = -x[2];
  zeros[3] = -x[1];
  zeros[4] = x[0];
  zeros[5] = x[1];
  zeros[6] = x[2];
  zeros[7] = x[3];
  zeros[8] = x[4];
}


////////////////////////////////////////////////////////////////////////////////
//  void Gauss_Legendre_Coefs_9pts( double coef[] )                           //
//                                                                            //
//  Description:                                                              //
//     Returns the coefficients for the 9 point Gauss-Legendre formula.       //
//                                                                            //
//  Arguments:                                                                //
//     double coef[]  Array in which to store the coefficients of the Gauss-  //
//                    Legendre formula.  The coefficient A[i] is associated   //
//                    with the i-th zero as returned in the function above    //
//                    Gauss_Legendre_Zeros_9pts.                              //
//                                                                            //
//  Return Values:                                                            //
//     none                                                                   //
//                                                                            //
//  Example:                                                                  //
//     #define N 9                                                            //
//     double a[N];                                                           //
//     int i;                                                                 //
//                                                                            //
//     Gauss_Legendre_Coefs_9pts( a );                                        //
//     printf("The coefficients for the Gauss-Legendre formula are :\n");     //
//     for (i = 0; i < N; i++) printf("%12.6lf\n",a[i]);                      //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
void Gauss_Legendre_Coefs_9pts( double coefs[]) {

   coefs[0] = A[4];
   coefs[1] = A[3];
   coefs[2] = A[2];
   coefs[3] = A[1];
   coefs[4] = A[0];
   coefs[5] = A[1];
   coefs[6] = A[2];
   coefs[7] = A[3];
   coefs[8] = A[4];
}
