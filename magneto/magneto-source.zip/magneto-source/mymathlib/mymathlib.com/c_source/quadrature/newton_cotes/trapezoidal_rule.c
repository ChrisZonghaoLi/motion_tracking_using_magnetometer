////////////////////////////////////////////////////////////////////////////////
// File: trapezoidal_rule.c                                                   //
// Routines:                                                                  //
//    Trapezoidal_Rule_Sum_LR                                                 //
//    Trapezoidal_Rule_Sum_RL                                                 //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  Description:                                                              //
//     A Newton-Cotes formula is an interpolatory quadrature formula using    //
//     the values of the integrand (function being integrated) at equally     //
//     spaced nodes to approximate the integral of the function over a        //
//     closed and bounded interval.                                           //
//                                                                            //
//     The trapezoidal rule is a (closed) Newton-Cotes formula for which the  //
//     interpolating polynomial is a line, the line joining the points        //
//     (x,f(x)) at the endpoints of the interval.                             //
//     The estimation of the integral then is simply the area of the trapezoid//
//     formed by the line segment joining the points (x, f(x)) at the         //
//     endpoints, the line segments joining (x,0) to (x,f(x)) at the endpoints//
//     and the interval of integration.                                       //
//                                                                            //
//     In order to integrate a function using the trapezoidal rule over a     //
//     closed and bounded interval [a,b], divide the interval [a,b] into N    //
//     subintervals of length h = (b-a) / N.  The integral of the function    //
//     over the interval [a,b] is the sum of the integrals of the function    //
//     over the subintervals [a,a+h], [a+h, a+2h],...,[b-h,b].  The integral  //
//     is approximated then by applying the trapezoidal rule to each          //
//     subinterval.  By abuse of language, this composite trapezoidal rule    //
//     is simply also called the trapezoidal rule.                            //
//                                                                            //
//     Let I(f) be the approximation of the integral of f(x) over [a,b] then  //
//     the trapezoidal rule is:                                               //
//       I(f) = h { f(x[0]) / 2 + f(x[1]) + ... + f(x[n-1]) + f(x[n]) / 2) }  //
//     where h is the step size, h = x[i] - x[i-1]; n is the number of        //
//     steps, n = abs(b - a) / h and x[0] = a, x[i] = x[i-1] + h for          //
//     i = 1,...,n-1 so that x[n] = b.                                        //
//                                                                            //
//     The truncation error estimate for the trapezoidal rule is              //
//                           n * h^3   f''(xm) / 12                           //
//     where f''(xm) is the value of the second derivative evaluated at some  //
//     (unknown) point a <= xm <= b.                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  double Trapezoidal_Rule_Sum_LR( double a, double h, int n,                //
//                                                    double (*f)(double) );  //
//                                                                            //
//  Description:                                                              //
//     This function integrates f(x) from a to a+nh using the trapezoidal     //
//     rule by summing from the left end of the interval to the right end.    //
//                                                                            //
//  Arguments:                                                                //
//     double a   The lower limit of the integration interval.                //
//     double h   The length of each subinterval, h > 0.                      //
//     int    n   The number of subintervals, the upper limit of integration  //
//                is a + n * h.                                               //
//     double *f  Pointer to the integrand, a function of a single variable   //
//                of type double.                                             //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) from a to (a + n * h).                            //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Trapezoidal_Rule_Sum_LR( double a, double h, int n,
                                                       double (*f)(double) ) { 
   double bound = a + (n - .5) * h;
   double integral = 0.5 * (*f)(a);

   for (a += h; a < bound; a += h) integral += (*f)(a);

   return h * ( integral + 0.5 * (*f)(a) );
}


////////////////////////////////////////////////////////////////////////////////
//  double Trapezoidal_Rule_Sum_RL( double a, double h, int n,                //
//                                                    double (*f)(double) );  //
//                                                                            //
//  Description:                                                              //
//     This function integrates f(x) from a to a+nh using the trapezoidal     //
//     rule by summing from the right end of the interval to the left end.    //
//                                                                            //
//  Arguments:                                                                //
//     double a   The lower limit of the integration interval.                //
//     double h   The length of each subinterval, h > 0.                      //
//     int    n   The number of subintervals, the upper limit of integration  //
//                is a + n * h.                                               //
//     double *f  Pointer to the integrand, a function of a single variable   //
//                of type double.                                             //
//                                                                            //
//  Return Values:                                                            //
//     The integral of f(x) from a to (a + n * h).                            //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
double Trapezoidal_Rule_Sum_RL( double a, double h, int n,
                                                       double (*f)(double) ) { 
   double x = a + n * h;
   double bound = a + 0.5 * h;
   double integral = 0.5 * (*f)(x);

   for (x -= h; x > bound; x -= h) integral += (*f)(x);

   return h * ( integral + 0.5 * (*f)(a) );
}
